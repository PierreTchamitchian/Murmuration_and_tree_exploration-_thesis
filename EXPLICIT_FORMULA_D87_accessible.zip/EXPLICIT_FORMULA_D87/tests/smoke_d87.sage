"""Contrôle natif Sage facultatif, à lancer depuis la racine du projet."""
from pathlib import Path
import sys
ROOT=next(p for p in [Path.cwd(),*Path.cwd().parents] if (p/'sage/d87_core.py').is_file())
sys.path.insert(0,str(ROOT/'sage'))
import d87_core as d87
R=PolynomialRing(QQ,'x'); x=R.gen()
K=NumberField(x**3-x**2+2*x+1,'a')
assert K.discriminant()==-87
assert sorted(int(p.norm()) for p in K.primes_of_bounded_norm(54)) == [i['norm'] for i in d87.verify_field()]
load(str(ROOT/'sage/mestre_formula.sage'))
for t in [1.97,3.13,4.0]:
    for kind in ['O','G']:
        value=float(archimedean_term(t,test_function=lambda u:d87.F(float(u),kind)))
        assert abs(value-d87.arch(float(t),kind))<1e-7
print('Arithmétique Sage et termes archimédiens concordants.')
