"""Core analytic routines for the exact-formula conductor MILP.

This file contains test functions, experiment configuration, stable numerical
integrals, Newton sums, local contributions, and lambda-grid constructors.

Load order: first this file, then exact_formula_local_factors.sage, then
exact_formula_milp.sage.
"""

# Imports and numerical parameters

from sage.all import *

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from datetime import datetime
import csv
import gzip
import json
import math
import os
import shutil
import time

RR = RealField(160)
CHI = PolynomialRing(ZZ, "X")
X = CHI.gen()
EULER = PolynomialRing(ZZ, "T")
T = EULER.gen()


# coerce a value to the working real field. Input: numeric value. Output: Sage real.
#
def rr(x):
    return RR(x)


# serialize a JSON-compatible object deterministically. Input: Python object. Output: JSON string.
#
def json_text(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


# format a real value for text output. Input: numeric value and digits. Output: string.
#
def rr_text(value, digits=40):
    return str(RR(value).n(digits=digits))


# convert Sage integers to native Python integers. Input: iterable. Output: Python list.
#
def integer_list(values):
    return [int(ZZ(v)) for v in values]


# Test-function objects

# Container for a Mestre test function and its certified metadata.
#
@dataclass
class MestreTestFunction:
    name: str
    value: object
    support_radius: object = 1
    F0: object = 1
    phi_center: object = None
    right_derivative_at_zero: object = 0
    fourier: object = None
    fourier_nonnegative_certified: bool = False
    H_decreasing_from: object = None
    proof_note: str = ""

    # Evaluate this stored test function at one real x.
    #
    def __call__(self, x):
        return RR(self.value(RR(x)))

    # Return the mathematical metadata of the test function as a serializable dictionary.
    #
    def describe(self):
        return {
            "name": self.name,
            "support_radius": rr_text(self.support_radius),
            "F0": rr_text(self.F0),
            "phi_center": None if self.phi_center is None else rr_text(self.phi_center),
            "right_derivative_at_zero": rr_text(self.right_derivative_at_zero),
            "fourier_nonnegative_certified": bool(self.fourier_nonnegative_certified),
            "H_decreasing_from": None if self.H_decreasing_from is None else rr_text(self.H_decreasing_from),
            "proof_note": self.proof_note,
        }


# evaluate the compact monotonicity test function. Input: real x. Output: Sage real.
#
def monotone_test_value(x):
    r = abs(RR(x))
    if r > 1:
        return RR(0)
    if r <= RR(1)/2:
        return (RR(1)
                - RR(40)/3*r**2
                + RR(80)/3*r**3
                - RR(40)/3*r**4
                - RR(8)/3*r**5)
    return RR(8)/3*(1-r)**5


# evaluate the Fourier transform of the monotonicity test. Input: real t. Output: Sage real.
#
def monotone_test_fourier(t):
    t = RR(t)
    if t == 0:
        return RR(5)/9
    return RR(320)*(t - RR(2)*sin(t/RR(2)))**2/t**6


MONOTONE_TEST = MestreTestFunction(
    name="F_monotone_5_g_convolution_g",
    value=monotone_test_value,
    support_radius=1,
    F0=1,
    phi_center=QQ(5)/9,
    right_derivative_at_zero=0,
    fourier=monotone_test_fourier,
    fourier_nonnegative_certified=True,
    H_decreasing_from=2*sqrt(RR(5)),
    proof_note=(
        "F=5(g*g), g(x)=(1-2|x|)^2 on [-1/2,1/2]. "
        "On a hat(F)(t)=320(t-2 sin(t/2))^2/t^6 et "
        "t*hat(F)(t) decreases for t >= 2*sqrt(5)."
    ),
)


# evaluate the Odlyzko test function. Input: real x. Output: Sage real.
#
def odlyzko_test_value(x):
    r = abs(RR(x))
    if r > 1:
        return RR(0)
    return (RR(1)-r)*cos(pi*r) + sin(pi*r)/pi


ODLYZKO_TEST = MestreTestFunction(
    name="F_Odlyzko",
    value=odlyzko_test_value,
    support_radius=1,
    F0=1,
    phi_center=RR(8)/(RR(pi)**2),
    right_derivative_at_zero=0,
    fourier=None,
    fourier_nonnegative_certified=True,
    H_decreasing_from=None,
    proof_note="Odlyzko test function, normalized square convolution.",
)


# numerically inspect a test function. Input: test object and sampling range. Output: diagnostic
# dictionary or None.
#
def diagnose_test_function(test, t_max=30, samples=600):
    print(test.describe())
    print("F(0) =", test(0))
    print("F(R) =", test(test.support_radius))
    if test.fourier is None:
        print("Pas de formule de Fourier fournie.")
        return None

    grid = [RR(t_max)*i/RR(samples) for i in range(samples+1)]
    hats = [RR(test.fourier(t)) for t in grid]
    min_hat = min(hats)
    print("Numerical minimum of hat(F) on the grid:", min_hat.n(12))

    max_increase = RR(0)
    if test.H_decreasing_from is not None:
        tail = [t for t in grid if t >= RR(test.H_decreasing_from)]
        H = [t*RR(test.fourier(t)) for t in tail]
        if len(H) >= 2:
            max_increase = max([H[i+1]-H[i] for i in range(len(H)-1)] + [RR(0)])
        print("Largest numerical increase of t*hat(F) after T:", max_increase.n(12))
    return {"min_hat": min_hat, "max_tail_increase": max_increase}


# Experiment configuration

# Configuration object for the exact-formula MILP workflow.
#
@dataclass
class ExperimentConfig:
    dimension: int
    analytic_rank: int
    lambda_values: list

    objective_test: MestreTestFunction = field(default_factory=lambda: MONOTONE_TEST)
    monotonicity_test: MestreTestFunction = field(default_factory=lambda: MONOTONE_TEST)

    default_reduction: object = "any"
    reduction_conditions: dict = field(default_factory=dict)
    candidate_provider: object = None
    candidate_family_certified_complete: bool = True

    # "off", "gamma_lower_bound" ou "heuristic"
    monotonicity_mode: str = "off"
    gamma_lower_bound: object = None
    lambda_start: object = None
    rank_is_exact: bool = True

    use_bad_prime_divisibility: bool = False

    # Optional cutoff coming from an already realized conductor.
    use_known_conductor_cutoff: bool = False
    known_conductor_upper_bound: object = None

    solver: str = "GLPK"
    solver_safety_margin: object = RR("1e-7")
    float_padding: object = RR("1e-11")
    local_value_padding: object = RR("1e-25")
    integration_padding: object = RR("1e-12")
    monotonicity_slack: object = RR("1e-10")
    local_minimum_tolerance: object = RR("1e-20")

    # Sage preparses numeric literals.
    # The explicit conversions below guarantee native Python types,
    # in particular when writing JSON files.
    integration_eps_abs: float = float("1e-12")
    integration_eps_rel: float = float("1e-12")
    integration_max_points: int = int(500)

    max_raw_candidates_per_prime: int = int(200000)
    max_total_profiles: int = int(100000)
    max_polynomials_shown_per_profile: int = int(4)

    output_directory: str = "resultats_formule_exacte"
    run_label: str = "mestre_exact"
    overwrite_output: bool = False


# validate and sort the lambda grid. Input: ExperimentConfig. Output: sorted list of positive Sage
# reals.
#
def sorted_lambdas(config):
    values = sorted(set(RR(v) for v in config.lambda_values))
    if len(values) < 1 or values[0] <= 0:
        raise ValueError("All lambda values must be positive.")
    return values


# determine where monotonicity constraints start. Input: ExperimentConfig. Output: (threshold,
# explanatory note).
#
def monotonicity_threshold(config):
    mode = str(config.monotonicity_mode).lower()
    if mode == "off":
        return None, "monotonicity not imposed"

    test = config.monotonicity_test
    if test is None or test.H_decreasing_from is None:
        raise ValueError("The monotonicity test function must provide H_decreasing_from.")
    if not config.rank_is_exact:
        raise ValueError("Monotonicity requires the exact analytic rank.")

    if mode == "gamma_lower_bound":
        if config.gamma_lower_bound is None or RR(config.gamma_lower_bound) <= 0:
            raise ValueError("gamma_lower_bound must be positive.")
        threshold = RR(test.H_decreasing_from)/RR(config.gamma_lower_bound)
        note = (
            "conditional on GRH, exact rank, and gamma_1 >= {}"
            .format(config.gamma_lower_bound)
        )
        return threshold, note

    if mode == "heuristic":
        if config.lambda_start is None:
            raise ValueError("Heuristic mode requires lambda_start.")
        return RR(config.lambda_start), "heuristic threshold chosen by the user"

    raise ValueError("monotonicity_mode must be 'off', 'gamma_lower_bound', or 'heuristic'.")


# validate mathematical and numerical experiment parameters. Input: ExperimentConfig. Output:
# (lambda list, threshold, note).
#
def validate_config(config):
    if ZZ(config.dimension) <= 0:
        raise ValueError("dimension must be positive.")
    if ZZ(config.analytic_rank) < 0:
        raise ValueError("analytic_rank must be nonnegative.")
    lambdas = sorted_lambdas(config)

    if config.use_known_conductor_cutoff:
        if config.known_conductor_upper_bound is None:
            raise ValueError("The cutoff requires known_conductor_upper_bound.")
        if RR(config.known_conductor_upper_bound) <= 0:
            raise ValueError("known_conductor_upper_bound must be positive.")

    if not config.objective_test.fourier_nonnegative_certified:
        raise ValueError("The user must certify nonnegativity of the Fourier transform of the objective test function.")

    threshold, threshold_note = monotonicity_threshold(config)
    if config.monotonicity_mode != "off":
        if not config.monotonicity_test.fourier_nonnegative_certified:
            raise ValueError("The monotonicity test must be an admissible compactly supported Mestre test function.")

    return lambdas, threshold, threshold_note


# convert an experiment configuration to JSON-safe data. Input: config and validated threshold data.
# Output: dictionary.
#
def serializable_config(config, lambdas, threshold, threshold_note):
    return {
        "dimension": int(config.dimension),
        "analytic_rank": int(config.analytic_rank),
        "rank_is_exact": bool(config.rank_is_exact),
        "lambda_values": [rr_text(v) for v in lambdas],
        "objective_test": config.objective_test.describe(),
        "monotonicity_test": None if config.monotonicity_test is None else config.monotonicity_test.describe(),
        "default_reduction": str(config.default_reduction),
        "reduction_conditions": {str(k): str(v) for k, v in config.reduction_conditions.items()},
        "candidate_provider": None if config.candidate_provider is None else getattr(config.candidate_provider, "__name__", str(config.candidate_provider)),
        "candidate_family_certified_complete": bool(config.candidate_family_certified_complete),
        "monotonicity_mode": config.monotonicity_mode,
        "gamma_lower_bound": None if config.gamma_lower_bound is None else rr_text(config.gamma_lower_bound),
        "lambda_start": None if config.lambda_start is None else rr_text(config.lambda_start),
        "monotonicity_threshold": None if threshold is None else rr_text(threshold),
        "monotonicity_threshold_note": threshold_note,
        "use_bad_prime_divisibility": bool(config.use_bad_prime_divisibility),
        "use_known_conductor_cutoff": bool(config.use_known_conductor_cutoff),
        "known_conductor_upper_bound": (
            None if config.known_conductor_upper_bound is None
            else rr_text(config.known_conductor_upper_bound)
        ),
        "solver": config.solver,
        "solver_safety_margin": rr_text(config.solver_safety_margin),
        "float_padding": rr_text(config.float_padding),
        "local_value_padding": rr_text(config.local_value_padding),
        "integration_padding": rr_text(config.integration_padding),
        "monotonicity_slack": rr_text(config.monotonicity_slack),
        # JSON does not directly accept Sage RealLiteral/Integer objects.
        "integration_eps_abs": float(config.integration_eps_abs),
        "integration_eps_rel": float(config.integration_eps_rel),
        "integration_max_points": int(config.integration_max_points),
        "max_raw_candidates_per_prime": int(config.max_raw_candidates_per_prime),
        "max_total_profiles": int(config.max_total_profiles),
        "max_polynomials_shown_per_profile": int(config.max_polynomials_shown_per_profile),
        "output_directory": str(config.output_directory),
        "run_label": str(config.run_label),
        "overwrite_output": bool(config.overwrite_output),
    }


# Archimedean term, Newton sums, and local contributions


# evaluate exp(z)-1 by a short series near zero. Input: real z. Output: Sage real.
#
def _expm1_series(z, terms=18):
    z = RR(z)
    term = z
    total = z
    for n in range(2, terms+1):
        term *= z/RR(n)
        total += term
    return total


# stably evaluate exp(z)-1. Input: real z. Output: Sage real.
#
def _stable_expm1(z):
    z = RR(z)
    if abs(z) < RR("1e-6"):
        return _expm1_series(z)
    return exp(z)-1


# stably evaluate 1-exp(-z). Input: real z. Output: Sage real.
#
def _stable_one_minus_exp_minus(z):
    return -_stable_expm1(-RR(z))


# compute Phi_F(1/2) with an error bound. Input: test function and config. Output: (value, error).
#
def phi_center_with_error(test, config):
    if test.phi_center is not None:
        return RR(test.phi_center), RR(0)

    R = RR(test.support_radius)
    kwargs = {
        "eps_abs": float(config.integration_eps_abs),
        "eps_rel": float(config.integration_eps_rel),
        "max_points": int(config.integration_max_points),
    }
    try:
        value, error = numerical_integral(lambda u: test(u), 0, R, **kwargs)
    except TypeError:
        value, error = numerical_integral(lambda u: test(u), 0, R)
    return RR(2)*RR(value), RR(2)*abs(RR(error)) + RR(config.integration_padding)


# compute M_{lambda,F} for one Gamma_C(s+1/2) factor. Input: lambda, test, config. Output: (value,
# error).
#
def M_lambda_with_error(lambda_value, test, config):
    lam = RR(lambda_value)
    R = RR(test.support_radius)
    F0 = RR(test.F0)
    d0 = RR(test.right_derivative_at_zero)
    if lam <= 0 or R <= 0:
        raise ValueError("lambda and the support radius must be positive.")

    # Regularized integrand used in the archimedean term M_{lambda,F}.
    #
    def integrand(u):
        u = RR(u)
        if u == 0:
            return F0/RR(2) + d0/lam
        z = lam*u
        numerator = z*test(u) - F0*_stable_one_minus_exp_minus(z)
        denominator = z*_stable_expm1(z)
        return numerator/denominator

    kwargs = {
        "eps_abs": float(config.integration_eps_abs),
        "eps_rel": float(config.integration_eps_rel),
        "max_points": int(config.integration_max_points),
    }
    try:
        a, error_a = numerical_integral(integrand, 0, R, **kwargs)
        b, error_b = numerical_integral(lambda t: exp(-t)/t, lam*R, Infinity, **kwargs)
    except TypeError:
        a, error_a = numerical_integral(integrand, 0, R)
        b, error_b = numerical_integral(lambda t: exp(-t)/t, lam*R, Infinity)

    value = RR(2)*(lam*RR(a) - F0*RR(b)) + RR(2)*F0*log(RR(2)*pi)
    error = (RR(2)*(lam*abs(RR(error_a)) + abs(F0)*abs(RR(error_b)))
             + RR(config.integration_padding)*(RR(1)+abs(value)))
    return value, error


# compute Newton power sums of a monic polynomial. Input: polynomial P and maximum power M. Output:
# [s_0,...,s_M].
#
def power_sums_of_roots(P, M):
    P = CHI(P)
    if P.leading_coefficient() != 1:
        raise ValueError("The characteristic polynomial must be monic.")
    d = P.degree()
    coefficients = [P[d-j] for j in range(1, d+1)]
    sums = [ZZ(d)]

    for m in range(1, M+1):
        if m <= d:
            value = sum(coefficients[j-1]*sums[m-j] for j in range(1, m))
            value += m*coefficients[m-1]
        else:
            value = sum(coefficients[j-1]*sums[m-j] for j in range(1, d+1))
        sums.append(ZZ(-value))
    return sums


# find the largest prime-power exponent inside the support. Input: p, lambda, support radius.
# Output: nonnegative integer.
#
def maximum_power(p, lambda_value, support_radius=1):
    p = ZZ(p)
    cutoff = RR(lambda_value)*RR(support_radius)
    m = 0
    while RR(m+1)*log(RR(p)) <= cutoff + RR("1e-35"):
        m += 1
    return m


# compute one local explicit-formula contribution from Newton sums. Input: p, power sums, lambda,
# test, config. Output: (value, error, maximum power).
#
def local_contribution_from_sums(p, power_sums, lambda_value, test, config):
    p = ZZ(p)
    lam = RR(lambda_value)
    mmax = maximum_power(p, lam, test.support_radius)
    if mmax == 0:
        return RR(0), RR(0), 0
    if len(power_sums) <= mmax:
        raise ValueError("Missing Newton sums for p={} and lambda={}.".format(p, lam))

    value = RR(0)
    absolute_sum = RR(0)
    for m in range(1, mmax+1):
        term = (RR(power_sums[m])
                * test(RR(m)*log(RR(p))/lam)
                / RR(p**m))
        value += term
        absolute_sum += abs(term)
    value *= log(RR(p))
    absolute_sum *= log(RR(p))
    error = RR(config.local_value_padding)*(RR(1)+abs(value)+absolute_sum)
    return value, error, mmax


# convert a characteristic polynomial to Euler-factor convention. Input: polynomial in X. Output:
# polynomial in T.
#
def characteristic_to_euler(P):
    P = CHI(P)
    d = P.degree()
    return EULER(sum(ZZ(P[d-j])*T**j for j in range(d+1)))


# convert an Euler factor to characteristic-polynomial convention. Input: polynomial in T. Output:
# polynomial in X.
#
def euler_to_characteristic(P):
    P = EULER(P)
    if P[0] != 1:
        raise ValueError("An Euler factor must have constant term 1.")
    d = P.degree()
    return CHI(sum(ZZ(P[j])*X**(d-j) for j in range(d+1)))


# Lambda grids


# build a lambda grid just after each new-prime threshold log(p). Input: lambda bounds and epsilon.
# Output: sorted list of Sage reals.
#
def prime_entry_lambda_grid(lambda_min=1.0, lambda_max=3.5, epsilon=1e-7):
    a = RR(lambda_min)
    b = RR(lambda_max)
    eps = RR(epsilon)
    if not (RR(0) < a <= b):
        raise ValueError("Require 0 < lambda_min <= lambda_max.")

    values = [a, b]
    p_bound = ZZ(floor(exp(b)))
    for p in prime_range(p_bound+1):
        value = log(RR(p)) + eps
        if a < value < b:
            values.append(value)
    return sorted(set(values))


# build a grid just after each prime-power threshold m*log(p). Input: lambda bounds and epsilon.
# Output: sorted list of Sage reals.
#
def prime_power_entry_lambda_grid(lambda_min=1.0, lambda_max=3.5, epsilon=1e-7):
    a = RR(lambda_min)
    b = RR(lambda_max)
    eps = RR(epsilon)
    values = [a, b]
    p_bound = ZZ(floor(exp(b)))
    for p in prime_range(p_bound+1):
        m = 1
        while RR(m)*log(RR(p)) < b:
            value = RR(m)*log(RR(p)) + eps
            if a < value < b:
                values.append(value)
            m += 1
    return sorted(set(values))


# describe which primes enter along a lambda grid. Input: lambda values and support radius. Output:
# list of dictionaries.
#
def lambda_grid_report(lambda_values, support_radius=1):
    previous = set()
    rows = []
    for index, lam in enumerate(sorted(set(RR(v) for v in lambda_values))):
        current = set(prime_range(ZZ(floor(exp(lam*RR(support_radius))))+1))
        entered = sorted(current-previous)
        rows.append({
            "index": index,
            "lambda": lam,
            "prime_bound": max(current) if current else None,
            "new_primes": entered,
            "number_of_primes": len(current),
        })
        previous = current
    return rows



# build a uniform lambda grid with both endpoints. Input: lambda bounds and step. Output: sorted
# list of Sage reals.
#
def uniform_lambda_grid(lambda_min=1.0, lambda_max=1.5, step=0.1):
    a = RR(lambda_min)
    b = RR(lambda_max)
    h = RR(step)
    if not (RR(0) < a <= b):
        raise ValueError("Require 0 < lambda_min <= lambda_max.")
    if h <= 0:
        raise ValueError("step must be positive.")

    values = []
    k = ZZ(0)
    while a + RR(k)*h < b - RR("1e-30"):
        values.append(a + RR(k)*h)
        k += 1
    values.append(b)
    return sorted(set(values))
