"""Contrôle indépendant des rejets D87 à précision arbitraire.

Le terme archimédien est réévalué à partir de l’intégrande original,
indépendamment de la régularisation SciPy. Les calculs mpmath ne sont PAS
une certification par intervalles. Les poids des boîtes sont recomptés.
"""
from __future__ import annotations
import itertools
import json
import math
from collections import Counter
from functools import lru_cache
from pathlib import Path
import mpmath as mp

# Recalculer les marges et vérifier une partition entière disjointe du domaine D87.
def verify_rejections(source: str | Path, out: str | Path, digits: int = 70) -> dict:
    source,out=Path(source),Path(out)
    if not isinstance(digits,int) or digits<40:
        raise ValueError('Au moins 40 chiffres de précision de travail sont requis.')
    path=source/'certificate_float.json'
    if not path.is_file():
        raise FileNotFoundError('Aucune couverture de rejets dans '+str(source))
    data=json.loads(path.read_text(encoding='utf8'))
    if (data['discriminant']!=-87 or data['base_norms']!=[3,3,5]
            or data['base_traces']!=[-3,-3,-4]):
        raise ValueError('Ce vérificateur est réservé à la configuration D87 archivée.')
    end=float(data['end'])
    if not 1.97<end<=4: raise ValueError('Support final inattendu.')
    all_groups=[(8,1),(19,1),(23,1),(25,1),(29,2),(31,1),(37,1),(41,3),(43,1),(53,1)]
    groups=[tuple(g) for g in data['groups']]
    if groups!=[(q,m) for q,m in all_groups if math.log(q)<end-1e-12]:
        raise ValueError('Liste des idéaux incompatible avec le support.')
    distributions=[]
    for q,m in groups:
        h=math.isqrt(4*q)
        distributions.append(Counter(map(sum,itertools.product(range(-h,h+1),repeat=m))))
    expected=math.prod((2*math.isqrt(4*q)+1)**m for q,m in groups)
    leaves=data['leaves']
    covered=0
    for i,a in enumerate(leaves):
        if not (len(a['lo'])==len(a['hi'])==len(groups)):
            raise ValueError('Dimension de boîte incorrecte.')
        w=1
        for (q,m),lo,hi,distribution in zip(groups,a['lo'],a['hi'],distributions):
            h=math.isqrt(4*q)*m
            if not (isinstance(lo,int) and isinstance(hi,int) and -h<=lo<=hi<=h):
                raise ValueError('Extrémités de boîte hors du domaine entier.')
            w*=sum(distribution[s] for s in range(lo,hi+1))
        if w!=a['weight']: raise ValueError('Multiplicité enregistrée incorrecte.')
        covered+=w
        for b in leaves[:i]:
            if not any(ahi<blo or bhi<alo for alo,ahi,blo,bhi in zip(a['lo'],a['hi'],b['lo'],b['hi'])):
                raise ValueError('Les boîtes se recouvrent.')
    if covered!=expected: raise ValueError('La couverture est incomplète.')
    with mp.workdps(digits):
        # Même noyau compact, réécrit entièrement en arithmétique mpmath.
        def kernel(u,kind):
            u=abs(u)
            if u>=1: return mp.mpf(0)
            if kind=='O': return (1-u)*mp.cos(mp.pi*u)+mp.sin(mp.pi*u)/mp.pi
            if u>=mp.mpf('.5'): return mp.mpf(8)/3*(1-u)**5
            return 1-mp.mpf(40)/3*u**2+mp.mpf(80)/3*u**3-mp.mpf(40)/3*u**4-mp.mpf(8)/3*u**5
        # Intégrer l’expression originale et sa queue, sans les constantes flottantes SciPy.
        @lru_cache(None)
        def arch(t,kind):
            lam=mp.mpf(t)
            def integrand(x):
                if not x: return mp.mpf('.5')
                return kernel(x/lam,kind)/mp.expm1(x)-mp.exp(-x)/x
            return 2*(mp.log(2*mp.pi)+mp.quad(integrand,[0,lam/2,lam])-mp.e1(lam))
        # Inclure chaque puissance des trois facteurs locaux déjà fixés.
        @lru_cache(None)
        def base_curve(t,kind):
            lam=mp.mpf(t);value=3*arch(t,kind)
            for q,a in zip(data['base_norms'],data['base_traces']):
                b0,b1=2,a
                for m in range(1,int(mp.floor(lam/mp.log(q)))+1):
                    if m>1: b0,b1=b1,a*b1-q*b0
                    value+=2*mp.log(q)*b1/mp.mpf(q)**m*kernel(m*mp.log(q)/lam,kind)
            return value
        # Les nouveaux idéaux ont q>=8 : q^2>exp(4), donc seul le terme m=1 intervient.
        @lru_cache(None)
        def local_weight(q,t,kind):
            return 2*mp.log(q)/q*kernel(mp.log(q)/mp.mpf(t),kind)
        checked=[]
        for i,r in enumerate(leaves):
            ts=[str(t) for t in r['lambdas']]
            if any(not 1<=float(t)<=end+1e-12 for t in ts):
                raise ValueError('Point de rejet hors du support.')
            if any(not any(abs(float(t)-g)<1e-13 for g in data['grid']) for t in ts):
                raise ValueError('Point de rejet absent de la grille archivée.')
            if r['rule']=='Odlyzko' and len(ts)==1:
                c=base_curve(ts[0],'O')-2*mp.log(87)
                coeff=[local_weight(q,ts[0],'O') for q,m in groups]
            elif r['rule']=='croissance_G2' and len(ts)==2 and float(ts[0])<float(ts[1]):
                c=base_curve(ts[0],'G')-base_curve(ts[1],'G')
                coeff=[local_weight(q,ts[0],'G')-local_weight(q,ts[1],'G') for q,m in groups]
            else: raise ValueError('Règle de rejet inconnue.')
            vertex=[lo if a>=0 else hi for lo,hi,a in zip(r['lo'],r['hi'],coeff)]
            margin=c+sum(a*v for a,v in zip(coeff,vertex))
            if not margin>0: raise ArithmeticError(f'Rejet {i} non confirmé à {digits} chiffres.')
            checked.append(dict(index=i,rule=r['rule'],lambdas=ts,box_lower=r['lo'],box_upper=r['hi'],
                covered_branches=r['weight'],margin_high_precision=str(margin)))
        lam=mp.mpf('1.97')
        values={q:{a:2*mp.log(q)*a/q*kernel(mp.log(q)/lam,'O')
                for a in range(-math.isqrt(4*q),math.isqrt(4*q)+1)} for q in (3,5)}
        initial=[(b,2*mp.log(87)-3*arch('1.97','O')-sum(values[q][a] for q,a in zip((3,3,5),b)))
                 for b in itertools.product(range(-3,4),range(-3,4),range(-4,5))]
        if [b for b,r in initial if r>=0]!=[(-3,-3,-4)]:
            raise ArithmeticError('Le contrôle initial haute précision ne concorde pas.')
        report=dict(precision_digits=digits,interval_certified=False,coverage_verified=True,
            multiplicities_recomputed=True,pairwise_disjoint=True,covered_extension_count=expected,
            rejection_boxes=len(checked),least_rejection_margin=str(min(mp.mpf(v['margin_high_precision']) for v in checked)),
            initial_count=441,initial_O_survivors=1,
            initial_survivor_residual=str(next(r for b,r in initial if b==(-3,-3,-4))),
            best_rejected_initial_residual=str(max(r for b,r in initial if b!=(-3,-3,-4))),
            explicit_example=dict(all_new_traces=0,
                G_35=str(base_curve('3.5','G')),G_36=str(base_curve('3.6','G')),
                G_change_35_36=str(base_curve('3.6','G')-base_curve('3.5','G')),
                O_residual_4=str(2*mp.log(87)-base_curve('4.0','O'))),checks=checked)
    out.mkdir(parents=True,exist_ok=True)
    (out/'verification_precision.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    return report
