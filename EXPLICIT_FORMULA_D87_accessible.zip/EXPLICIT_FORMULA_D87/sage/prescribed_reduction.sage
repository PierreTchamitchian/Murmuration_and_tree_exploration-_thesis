"""Conductor divisibility implied by prescribed local reduction."""

from typing import Any
from sage.all import ZZ, ceil


# obtain the minimum conductor exponent for an elliptic condition.
# Input: an elliptic local condition.  Output: the integer 0, 1, or 2.
#
def automatic_elliptic_conductor_exponent(condition: Any):
    signature = normalize_reduction_condition(condition, 1)
    if signature in {None, (1, 0, 0)}:
        return ZZ(0)
    if signature == (0, 1, 0):
        return ZZ(1)
    if signature == (0, 0, 1):
        return ZZ(2)
    raise ValueError('unexpected elliptic reduction signature: %r' % (signature,))


# compute a known divisor of the conductor norm.
# Input: dimension and local conditions, or explicit (prime, exponent) pairs.
# Output: a positive Sage integer, or None when no exponent rule is supplied.
#
def minimum_conductor_norm_divisor(
    dimension: int,
    reduction_conditions=(),
    minimum_conductor_exponents=None,
):
    g = ZZ(dimension)
    if minimum_conductor_exponents is not None:
        divisor = ZZ(1)
        for place, exponent in minimum_conductor_exponents:
            exponent = ZZ(exponent)
            if exponent < 0:
                raise ValueError('conductor exponents must be nonnegative')
            divisor *= prime_norm(place) ** exponent
        return divisor

    if g != 1:
        return None

    divisor = ZZ(1)
    for place, condition in reduction_conditions:
        divisor *= prime_norm(place) ** automatic_elliptic_conductor_exponent(condition)
    return divisor


# round a real conductor bound using known norm divisibility.
# Input: a bound dictionary and local exponent data.  Output: an enriched dict.
#
def add_arithmetic_bound(
    result,
    reduction_conditions=(),
    minimum_conductor_exponents=None,
):
    enriched = dict(result)
    divisor = minimum_conductor_norm_divisor(
        int(result['dimension']),
        reduction_conditions,
        minimum_conductor_exponents,
    )
    enriched['minimum_norm_divisor'] = divisor
    enriched['arithmetic_norm_bound'] = (
        None if divisor is None
        else divisor * ceil(result['absolute_norm_bound'] / divisor)
    )
    return enriched


# optimize the real bound and add the implied arithmetic bound.
# Input: field, rank/dimension, local conditions, and staged-search options.
# Output: the optimal result dictionary with divisor and arithmetic bound.
#
def optimal_bound_with_reduction(
    number_field: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    minimum_conductor_exponents=None,
    **search_options,
):
    result = optimal_bound(
        number_field=number_field,
        dimension=dimension,
        analytic_rank=analytic_rank,
        reduction_conditions=reduction_conditions,
        **search_options,
    )
    return add_arithmetic_bound(
        result,
        reduction_conditions,
        minimum_conductor_exponents,
    )
