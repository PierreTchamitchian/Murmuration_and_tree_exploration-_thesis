"""Standard-library utilities shared by the launcher, workers and exporter."""
from __future__ import annotations
import hashlib
import json
import math
import os
import re
import tempfile
from functools import lru_cache
from pathlib import Path
from typing import Any

SCHEMA = 3
VERSION = "4.0.0"
ROOT = Path(__file__).resolve().parent
THREAD_VARIABLES = ("OMP_NUM_THREADS", "OMP_THREAD_LIMIT", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                    "FLINT_NUM_THREADS", "NUMEXPR_MAX_THREADS",
                    "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
                    "SAGE_NUM_THREADS", "SAGE_NUM_THREADS_PARALLEL")


def single_thread_env() -> dict[str, str]:
    env = os.environ.copy()
    env.update({name: "1" for name in THREAD_VARIABLES})
    env["PYTHONUNBUFFERED"] = "1"
    return env


def validate_label(label: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", label):
        raise ValueError("Label: letters, digits, underscores or hyphens; no path separators")
    return label


def first_primes(count: int, coprime_to: int = 1) -> list[int]:
    if count < 0 or coprime_to < 1:
        raise ValueError("Invalid prime count or level")
    found, answer, candidate = [], [], 2
    while len(answer) < count:
        if all(candidate % p for p in found if p * p <= candidate):
            found.append(candidate)
            if coprime_to % candidate:
                answer.append(candidate)
        candidate = 3 if candidate == 2 else candidate + 2
    return answer


def fingerprint(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True).encode()).hexdigest()


def source_digest(root: Path = ROOT) -> str:
    """Changes to calculation, output validation or orchestration invalidate reuse."""
    h = hashlib.sha256()
    for name in ("common.py", "sieve.py", "engine.py", "worker.py", "run.py", "projection.py", "projected_collection.py", "migration.py"):
        h.update(name.encode()); h.update((root / name).read_bytes())
    return h.hexdigest()


def atomic_json(path: Path | str, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(obj, stream, sort_keys=True, ensure_ascii=True, allow_nan=False)
            stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def read_json(path: Path | str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def settings_hash(settings: dict) -> str:
    return fingerprint({k: v for k, v in settings.items() if k != "settings_hash"})


@lru_cache(maxsize=1024)
def quadratic_field_info(discriminant: int) -> dict:
    """Canonical metadata for a real quadratic FIELD discriminant, not a polynomial's.

    The arithmetic engine obtains this integer from Sage F.discriminant().
    Return copies at call sites before mutation: the cached dictionary is shared.
    """
    D = discriminant
    if type(D) is not int or D <= 1:
        raise ValueError("Expected a positive real quadratic field discriminant")
    if D % 4 == 1:
        m, poly = D, [(1-D)//4, -1, 1]
    elif D % 4 == 0 and (D//4) % 4 in (2, 3):
        m, poly = D//4, [-(D//4), 0, 1]
    else:
        raise ValueError("Discriminant is not fundamental")
    # Exact squarefreeness check. Cache makes repeated checkpoint checks cheap.
    n, p = m, 2
    while p*p <= n:
        if n % p == 0:
            n //= p
            if n % p == 0:
                raise ValueError("Discriminant is not fundamental")
        p = 3 if p == 2 else p + 2
    return {"id": f"D{D}", "degree": 2, "discriminant": D,
            "radicand": m, "canonical_polynomial": poly}


def validate_quadratic_field(record: dict) -> None:
    info = record.get("coefficient_field")
    if not isinstance(info, dict) or info != quadratic_field_info(info.get("discriminant")):
        raise ValueError("Missing or inconsistent quadratic field classification")


def validate_coefficients(record: dict, degree: int, limit: int, complete: bool = True) -> None:
    cps, traces, norms = (record[name] for name in ("hecke_charpolys", "traces", "norms"))
    n = len(cps)
    if n > limit or (complete and n != limit) or len(traces) != n or len(norms) != n:
        raise ValueError("Inconsistent coefficient counts")
    if record["root_number"] not in (-1, 1):
        raise ValueError("Invalid root number")
    for cp, tr, nm in zip(cps, traces, norms):
        if len(cp) != degree + 1 or cp[-1] != 1 or any(type(c) is not int for c in cp):
            raise ValueError("Invalid monic integral characteristic polynomial")
        if type(tr) is not int or type(nm) is not int:
            raise ValueError("Non-integral trace/norm")
        if tr != -cp[-2] or nm != (-1) ** degree * cp[0]:
            raise ValueError("Characteristic polynomial / trace / norm mismatch")


def validate_result(result: dict, settings: dict, level: int) -> None:
    if (result.get("schema"), result.get("settings_hash"), result.get("level"),
        result.get("complete")) != (SCHEMA, settings["settings_hash"], level, True):
        raise ValueError("Incompatible or incomplete level checkpoint")
    if result.get("prime_count") != settings["primes"]:
        raise ValueError("Incorrect prime count")
    if result.get("field_mode") != settings.get("field_mode"):
        raise ValueError("Incorrect field selection mode")
    if result.get("field_polynomial") != settings.get("poly"):
        raise ValueError("Incorrect prescribed-field polynomial")
    keys = set()
    for record in result["records"]:
        if record["component_key"] in keys:
            raise ValueError("Duplicate component")
        keys.add(record["component_key"])
        validate_coefficients(record, settings["degree"], settings["primes"])
        if settings["degree"] == 2:
            validate_quadratic_field(record)


def process_info(pid: int) -> dict | None:
    """Linux /proc metadata; start_ticks prevents confusing a reused PID."""
    try:
        folder = Path("/proc") / str(pid)
        text = (folder / "stat").read_text()
        fields = text[text.rfind(")") + 2:].split()
        argv = (folder / "cmdline").read_bytes().split(b"\0")
        return {"pid": pid, "uid": folder.stat().st_uid, "state": fields[0],
                "ppid": int(fields[1]), "pgid": int(fields[2]), "sid": int(fields[3]),
                "start_ticks": int(fields[19]),
                "argv": [a.decode(errors="replace") for a in argv if a]}
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        return None


def user_processes() -> list[dict]:
    answer = []
    for p in Path("/proc").iterdir():
        if p.name.isdigit():
            info = process_info(int(p.name))
            if info and info["uid"] == os.getuid():
                answer.append(info)
    return answer
