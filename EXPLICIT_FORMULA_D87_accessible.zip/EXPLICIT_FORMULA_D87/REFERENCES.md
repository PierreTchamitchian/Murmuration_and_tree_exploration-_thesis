# References

## Explicit formula and polynomial test functions

Pierre Tchamitchian, *Explicit lower bounds on the conductors of elliptic curves and abelian varieties over number fields*, Journal of Number Theory (2026), DOI `10.1016/j.jnt.2026.06.014`, arXiv:2410.12922v3.

- Section 5: number-field conductor bounds.
- Appendix A: continuity/density argument for polynomial convolution test functions and quadratic dependence on the polynomial coefficients.
- arXiv HTML: https://arxiv.org/html/2410.12922v3
- Publisher: https://www.sciencedirect.com/science/article/pii/S0022314X26001460?via%3Dihub

## Generalized quadratic-form optimization used in notebook 14

For fixed local moments, fixed lambda and a finite kernel basis, the code maximizes the generalized Rayleigh quotient

```text
(v^T A v) / (v^T Q v),
```

with symmetric `A` and positive-definite Gram matrix `Q`. The maximum is the largest generalized eigenvalue of `A v = mu Q v`.

The implementation calls `scipy.linalg.eigh(A, Q)`. SciPy documents that the full generalized problem uses the LAPACK `gvd` driver by default. For real double precision this corresponds to LAPACK `DSYGVD`; its documentation states that it solves the real generalized symmetric-definite eigenproblem and uses a divide-and-conquer algorithm when eigenvectors are requested.

- SciPy `eigh`: https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.eigh.html
- LAPACK `DSYGVD`: https://www.netlib.org/lapack/explore-html/d5/d0e/group__hegvd_gaf0bdec790208a5a56bbe0a5abcf581d0.html
