# Murmurations — données compactes et traces individuelles

Ce dossier contient les données et algorithmes nécessaires pour reproduire les
**sept figures retenues pour la thèse**, sans aucun nouveau calcul Sage.
Il couvre uniquement la fenêtre **5 000–10 000 inclus**, et non l'intégralité
11–10 000 de l'archive originale.

## Contenu scientifique

- Formes nouvelles classiques sur Q, poids 2, caractère trivial, corps de
  coefficients quadratique réel : **8 712 orbites**, **34 corps**, **2 000 premiers**
  de 2 à 17 389 ; chaque orbite représente deux formes conjuguées.
- **4 995 niveaux calculés** sur les 5 001 niveaux de la fenêtre.
- Niveaux manquants : **6400, 6912, 7056, 7200, 8281, 9216**. Ils sont exclus,
  jamais remplacés par des contributions nulles. Les figures décrivent la
  famille effectivement calculée, pas une famille prétendue exhaustive.
- Courbes elliptiques sur Q et moyennes sur Q(sqrt(5)) : les six CSV de comparaison
  déjà fournis sont conservés à l'identique. L'échantillon Q contient 20 728
  représentantes de classes ; la population K comporte 4 803 courbes à rang
  déclaré exact. Les identifiants individuels de ces courbes ne font pas partie
  de cette livraison : la sélection une classe/un poids côté K n'est pas
  vérifiable à partir de ces seules moyennes.

## Reproduire

Python >= 3.10. Depuis ce dossier décompressé :

```bash
python -m pip install -r requirements.txt
python verify.py
python -m unittest discover -s tests -v
python reproduce.py --out outputs/figures --axes p index
```

`REVIEW_DATA_OK` confirme les empreintes et contrôles internes des CSV.
`FIGURES_OK figures=14` indique les sept figures dans chacune des deux conventions
horizontales, en PNG et SVG. Un seul axe (`--axes p`) donne sept figures.
Les titres sont sobres ; la dernière figure signale l'effectif réduit de 35
orbites pour Q(sqrt(73)). Aucune moyenne glissante ou déformation n'est appliquée.
La mise en page peut varier légèrement avec les versions de Matplotlib/polices ;
les séries numériques et les conventions reproduites sont celles des fichiers.

Pour exporter aussi les moyennes de tous les corps, globales, par signe,
signées et sans séparation :

```bash
python aggregate.py --out outputs/means.csv
```

La colonne `field_discriminant=all` désigne le regroupement de tous les corps,
non un nouveau corps de coefficients. `--normalise` dans `reproduce.py` permet
de diviser **toutes** les ordonnées par sqrt(p), sans recalcul arithmétique.

## Organisation

```text
data/modforms_N5000_10000.csv    # 5 colonnes entières, 136 000 lignes
data/primes.csv                 # p et indice global pi(p)
data/curves/                    # 6 CSV originaux de comparaison
metadata/fields.csv             # radicands et effectifs par corps/signe
metadata/levels.csv             # niveaux terminés, vides ou manquants
metadata/manifest.json          # périmètre, conventions et provenance
metadata/preparation_validation.json
reference/aggregate.py          # agrégateur original, copie à l'identique
reference/common.py             # utilitaires originaux, copie à l'identique
murmurations.py                 # lecture/contrôles et regroupement exact
aggregate.py                   # export des moyennes depuis les sommes compactes
reproduce.py                   # 7 figures, p ou indice global
verify.py                      # empreintes et cohérence des CSV
SHA256SUMS.txt                  # intégrité des fichiers livrés
```

Les scripts `reference/` documentent le code d'origine qui travaillait sur des
JSON par niveau. Les commandes de reproduction ci-dessus utilisent les scripts
à la racine, adaptés aux données compactes, **avec les mêmes formules**.

## Ce que vérifie cette livraison

Lors de la préparation, les empreintes SHA256 des 4 995 résultats de niveau ont
été confrontées au manifeste original. Les 17 424 000 traces individuelles ont
été lues, confrontées aux polynômes caractéristiques enregistrés, puis agrégées.
Les sommes de traces **et** les effectifs des 136 000 lignes concordent exactement
avec le CSV source. Il ne s'agit pas d'un nouveau calcul de formes sous Sage ni
d'une vérification indépendante de l'exhaustivité mathématique.

Cette archive contient déjà l'ensemble du dossier léger et les traces individuelles.
Il n'est pas nécessaire de télécharger également l'archive légère.

## Provenance et droits

Les données proviennent des pièces jointes `modforms_jusqua10000.zip` et
`comparison.zip`; leurs empreintes sont dans le manifeste. Les données de courbes
sur Q étaient issues des exports LMFDB fournis, puis de calculs Sage; les moyennes
sur Q(sqrt(5)) proviennent de l'archive Nina fournie, sans réévaluation arithmétique
ici. Aucune nouvelle requête réseau n'est nécessaire.

Aucune licence de redistribution ni attribution d'auteur n'est inventée par
cette préparation. Le propriétaire du dépôt devra préciser les auteurs et la
licence applicable avant une publication publique. Les conditions et crédits des
sources externes restent à respecter. Ce dossier est une archive de reproductibilité,
pas une autorisation juridique de réutilisation.

## Vérification indépendante de l'agrégation à partir des traces

```bash
python recompute.py --out outputs/modforms_recomputed.csv
```

Le message `EXACT_AGGREGATION_OK` n'est affiché que si les **136 000** couples
(somme de traces, effectif) correspondent exactement au CSV de référence.

`data/individual/orbits.csv` : une ligne par orbite, avec son niveau, le
discriminant du corps, le signe et un identifiant dérivé de `component_key`.
Ce n'est **pas** un label LMFDB. `trace_row` commence à 0 et donne le numéro
de ligne dans la matrice. Les 8 712 identifiants sont distincts.

`data/individual/traces.npz` : tableau `traces` de forme (8712, 2000), dtype
int16, et vecteur `primes` int32. Les entiers vont de -524 à 524 : aucune
quantification, aucun arrondi, aucune perte. Lecture NumPy avec
`np.load(path, allow_pickle=False)`. Les coefficients aux mauvais premiers
sont conservés dans la matrice mais **exclus des moyennes** via le test p|N.

Les normes et les polynômes caractéristiques complets ne sont pas inclus ;
cette compression du périmètre vise les moyennes de traces utilisées dans
les figures. Les coordonnées algébriques des coefficients a_p ne peuvent
pas être reconstruites depuis les seules traces. Les données initiales
sous 5000 ne sont pas incluses non plus.

`reference/calcul_sage_v4/` conserve les sources Python de la v4 fournie
antérieurement (y compris le calcul des coefficients), comme référence
d'audit, pas comme nouveau lanceur prêt à l'emploi. Les outils SSH et tests
Sage complets ne sont pas tous recopiés. Aucun calcul de symboles modulaires
n'est relancé ici. Pour un audit arithmétique intégral, conserver également
l'archive de campagne d'origine. Certaines données de la campagne v4
avaient été importées des calculs v3.
