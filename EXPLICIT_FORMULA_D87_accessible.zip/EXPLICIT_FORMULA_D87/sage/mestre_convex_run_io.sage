"""Saved-run adapter and cached input preparation for mestre_convex_relaxation.sage.

The mathematical algorithms are in mestre_convex_relaxation.sage. This file
only reads the existing exact-formula CSV layout, assembles the same constraint
conventions, and prepares inputs using the unchanged source precomputation.
No original solver is called and no existing project file is overwritten.
"""

from pathlib import Path as _mc_Path
from decimal import Decimal as _mc_Decimal, localcontext as _mc_localcontext
import csv as _mc_csv
import gzip as _mc_gzip
import json as _mc_json
import hashlib as _mc_hashlib
import contextlib as _mc_contextlib
import tempfile as _mc_tempfile
import zipfile as _mc_zipfile
import sys as _mc_sys
import types as _mc_types


# read saved records. Input: Path to CSV or CSV.gz. Output: row iterator.
#
def _mc_rows(path):
    opener = _mc_gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8", newline="") as handle:
        yield from _mc_csv.DictReader(handle)


# outward-round a stored decimal coefficient. Input: Decimals and direction. Output: float.
#
def _mc_padded_float(value, padding, upward=False):
    delta = padding*(_mc_Decimal("1")+abs(value))
    value = value+delta if upward else value-delta
    direction = _mc_math.inf if upward else -_mc_math.inf
    return _mc_math.nextafter(float(value), direction)


# assemble the convex model from an existing exact-formula run, without enumeration.
# Input: directory Path/string, monotonicity bool. Output: model dict with arrays and profile
# metadata.
#
def load_mestre_convex_run(run_directory, monotonicity=False):
    root = _mc_Path(run_directory)
    config = _mc_json.loads((root/"configuration.json").read_text(encoding="utf-8"))
    grid = config["lambda_values"]
    L = len(grid)
    profiles = list(_mc_rows(root/"local_profiles.csv.gz"))
    groups_by_prime = {}
    profile_index = {}
    for k, row in enumerate(profiles):
        p = int(row["p"])
        groups_by_prime.setdefault(p, []).append(k)
        key = (p, row["profile_id"])
        if key in profile_index:
            raise ValueError("Duplicate profile in the saved run.")
        profile_index[key] = k
    primes = sorted(groups_by_prime)
    groups = [groups_by_prime[p] for p in primes]
    mode = config["monotonicity_mode"]
    if monotonicity and mode == "off":
        raise ValueError("This run has no monotonicity data. Prepare a run with a non-off mode first.")
    threshold = config.get("monotonicity_threshold")
    active = [j for j in range(L-1) if monotonicity and threshold is not None
              and _mc_Decimal(grid[j]) >= _mc_Decimal(str(threshold))]
    active_position = {j: t for t, j in enumerate(active)}
    N = len(profiles)
    bad = bool(config.get("use_bad_prime_divisibility", False))
    b = _mc_np.zeros(L+int(bad)); C = _mc_np.zeros((len(b), N))
    h = _mc_np.zeros(len(active)); D = _mc_np.zeros((len(active), N))
    seen = {"objective": _mc_np.zeros((L, N), dtype=bool),
            "monotonicity": _mc_np.zeros((L, N), dtype=bool) if active else None}
    arch = {"objective": {}, "monotonicity": {}}
    padding = _mc_Decimal(config["float_padding"])
    with _mc_localcontext() as context:
        context.prec = int(60)
        for row in _mc_rows(root/"archimedean_terms.csv"):
            role, j = row["role"], int(row["lambda_index"])
            if j in arch[role]:
                raise ValueError("Duplicate archimedean record.")
            v, e = _mc_Decimal(row["constant_part"]), _mc_Decimal(row["constant_error"])
            arch[role][j] = (v, e)
        if len(arch["objective"]) != L or (active and len(arch["monotonicity"]) != L):
            raise ValueError("Incomplete archimedean data.")
        for j in range(L):
            v, e = arch["objective"][j]
            b[j] = _mc_padded_float(v-e, padding)
        for j, t in active_position.items():
            v1, e1 = arch["monotonicity"][j]
            v2, e2 = arch["monotonicity"][j+1]
            delta = _mc_padded_float(v2+e2-v1+e1, padding, upward=True)
            # The old model allows a slack on the RHS; absorb it into h.
            h[t] = _mc_math.nextafter(delta+float(config["monotonicity_slack"]), _mc_math.inf)
        previous = {}
        for row in _mc_rows(root/"local_contributions.csv.gz"):
            role, j = row["role"], int(row["lambda_index"])
            if role == "monotonicity" and not active:
                continue
            k = profile_index[(int(row["p"]), row["profile_id"])]
            if not 0 <= j < L or seen[role][j, k]:
                raise ValueError("Invalid or duplicated local contribution index.")
            seen[role][j, k] = True
            v = _mc_Decimal(row["local_contribution_before_x2"])
            e = _mc_Decimal(row["error_bound"])
            if role == "objective":
                C[j, k] = _mc_padded_float(_mc_Decimal("2")*(v-e), padding)
            else:
                # The source writer orders the lambda entries within each profile.
                if j and (k not in previous or previous[k][0] != j-1):
                    raise ValueError("Monotonicity records must be in lambda order within each profile.")
                if j-1 in active_position:
                    _, v1, e1 = previous[k]
                    delta = _mc_Decimal("2")*(v+e-v1+e1)
                    D[active_position[j-1], k] = _mc_padded_float(delta, padding, upward=True)
                previous[k] = (j, v, e)
        if not seen["objective"].all() or (active and not seen["monotonicity"].all()):
            raise ValueError("The saved local contribution file is incomplete.")
        if bad:
            for k, row in enumerate(profiles):
                logp = _mc_Decimal(row["p"]).ln()
                exponent = int(row["conductor_exponent_lower_bound"])
                C[-1, k] = _mc_math.nextafter(exponent*_mc_padded_float(logp, padding), -_mc_math.inf) if exponent else float(0)
        cutoff = None
        if config.get("use_known_conductor_cutoff", False):
            cutoff = _mc_padded_float(_mc_Decimal(config["known_conductor_upper_bound"]).ln(), padding, upward=True)
    incumbent_selections = []
    for name in ("common_fixed_factors_selection.csv", "with_monotonicity_selection.csv"):
        if (root/name).is_file():
            selected = {int(row["p"]): row["profile_id"] for row in _mc_rows(root/name)}
            if set(selected) == set(primes):
                incumbent_selections.append([profile_index[(p, selected[p])] for p in primes])
    return {"groups": groups, "group_labels": primes, "offsets": b, "costs": C,
            "monotonicity_offsets": h, "monotonicity_coefficients": D, "log_cutoff": cutoff,
            "profiles": profiles, "incumbent_selections": incumbent_selections,
            "configuration": config, "lambda_values": grid, "monotonicity_pairs": active,
            "run_directory": str(root.resolve())}


# approximate a saved finite MILP and write a small reviewable report.
# Input: run directory, monotonicity bool, rounding budget and seed. Output: result dict with
# bound_interval.
#
def relax_mestre_saved_run(run_directory, monotonicity=False, rounding_trials=64, seed=0, save=True):
    model = load_mestre_convex_run(run_directory, monotonicity=monotonicity)
    result = solve_mestre_convex_model(model, rounding_trials=rounding_trials, seed=seed)
    config = model["configuration"]
    result.update({"run_directory": model["run_directory"], "monotonicity_applied": bool(monotonicity),
                   "monotonicity_mode": config["monotonicity_mode"] if monotonicity else "off",
                   "analytic_certification": False,
                   "number_of_monotonicity_constraints": len(model["monotonicity_pairs"])})
    if not save:
        return result
    # Never alter old outputs: each report has its own new directory.
    report = _mc_Path(_mc_tempfile.mkdtemp(prefix="convex_report_", dir=str(run_directory)))
    profile_fields = ["p", "profile_id", "representative_characteristic_polynomial",
                      "representative_euler_polynomial", "signature"]
    for filename, indices in (("convex_weights.csv", range(len(model["profiles"]))),
                              ("convex_checked_selection.csv", result["selected_profile_indices"] or [])):
        with open(report/filename, "w", encoding="utf-8", newline="") as handle:
            writer = _mc_csv.DictWriter(handle, fieldnames=profile_fields+["weight"])
            writer.writeheader()
            for k in indices:
                row = {key: model["profiles"][k][key] for key in profile_fields}
                row["weight"] = result["weights"][k] if filename == "convex_weights.csv" else float(1)
                if row["weight"] > float(0):
                    writer.writerow(row)
    cert = {key: [str(x) for x in value] if isinstance(value, list) else str(value)
            for key, value in result["dual_certificate"].items()}
    (report/"convex_dual_certificate.json").write_text(_mc_json.dumps(cert, indent=int(2)), encoding="utf-8")
    _mc_np.savez_compressed(report/"convex_numerical_model.npz", offsets=model["offsets"], costs=model["costs"],
                           monotonicity_offsets=model["monotonicity_offsets"],
                           monotonicity_coefficients=model["monotonicity_coefficients"])
    metadata = {key: model[key] for key in ("groups", "group_labels", "log_cutoff", "lambda_values", "monotonicity_pairs")}
    (report/"convex_model_metadata.json").write_text(_mc_json.dumps(metadata, indent=int(2)), encoding="utf-8")
    result["report_directory"] = str(report.resolve())
    summary = {key: value for key, value in result.items() if key not in ("weights", "dual_certificate")}
    summary.update({"rounding_trials": int(rounding_trials), "seed": int(seed), "source_configuration": config})
    (report/"convex_summary.json").write_text(_mc_json.dumps(summary, indent=int(2)), encoding="utf-8")
    return result


# cache the original candidate/contribution calculation without running any MILP.
# Input: dimension/rank integers, lambda list, optional source-style conditions and paths.
# Output: Path to a completed reusable run; identical inputs reuse it. Requires a Sage kernel.
#
def prepare_mestre_convex_run(dimension, analytic_rank, lambda_values, output_directory="outputs",
                              run_label="convex_inputs", monotonicity_mode="heuristic", lambda_start=1.0,
                              gamma_lower_bound=None, default_reduction="any", reduction_conditions=None,
                              use_bad_prime_divisibility=False, known_conductor_upper_bound=None,
                              source_directory=None):
    if int(dimension) != dimension or int(analytic_rank) != analytic_rank:
        raise ValueError("dimension and analytic_rank must be integers.")
    if not str(run_label) or _mc_Path(str(run_label)).name != str(run_label) or str(run_label) in (".", ".."):
        raise ValueError("run_label must be a simple directory name.")
    import sage.all as sage_all
    from sage.repl.preparse import preparse
    module = _mc_types.ModuleType("_mestre_convex_source_namespace")
    _mc_sys.modules[module.__name__] = module
    ns = module.__dict__
    filenames = ("exact_formula_core.sage", "exact_formula_local_factors.sage", "exact_formula_precomputation.sage")
    roots = [_mc_Path.cwd(), *_mc_Path.cwd().parents]
    if source_directory is not None:
        directory = _mc_Path(source_directory)
    else:
        directory = next((p/"sage" for p in roots if all((p/"sage"/name).is_file() for name in filenames)), None)
    texts = {}
    if directory is not None:
        texts = {name: (directory/name).read_bytes() for name in filenames}
    else:
        snapshot = next((p/"reference_data"/"mestre_source_snapshot.zip" for p in roots
                         if (p/"reference_data"/"mestre_source_snapshot.zip").is_file()), None)
        if snapshot is None:
            raise FileNotFoundError("Provide the original sage/ modules or keep reference_data/mestre_source_snapshot.zip with this add-on.")
        with _mc_zipfile.ZipFile(snapshot) as archive:
            for name in filenames:
                member = next(n for n in archive.namelist() if n.endswith("/sage/"+name))
                texts[name] = archive.read(member)
    # The private namespace prevents RR, X and source helper names from replacing yours.
    ns.update({"Integer": sage_all.Integer, "RealNumber": sage_all.RealNumber})
    hashes = {name: _mc_hashlib.sha256(text).hexdigest() for name, text in texts.items()}
    for name in filenames:
        exec(compile(preparse(texts[name].decode("utf-8")), name, "exec"), ns)
    config = ns["ExperimentConfig"](
        dimension=int(dimension), analytic_rank=int(analytic_rank), lambda_values=list(lambda_values),
        objective_test=ns["ODLYZKO_TEST"], monotonicity_test=ns["MONOTONE_TEST"],
        default_reduction=default_reduction, reduction_conditions=reduction_conditions or {},
        monotonicity_mode=monotonicity_mode, lambda_start=lambda_start, gamma_lower_bound=gamma_lower_bound,
        use_bad_prime_divisibility=bool(use_bad_prime_divisibility),
        use_known_conductor_cutoff=known_conductor_upper_bound is not None,
        known_conductor_upper_bound=known_conductor_upper_bound,
        output_directory=str(output_directory), run_label=str(run_label))
    grid, threshold, note = ns["validate_config"](config)
    serialized = ns["serializable_config"](config, grid, threshold, note)
    identity = {"configuration": serialized, "source_sha256": hashes}
    root = _mc_Path(output_directory); root.mkdir(parents=True, exist_ok=True)
    target = root/str(run_label)
    if target.exists():
        marker = target/"convex_inputs_complete.json"
        if marker.is_file() and _mc_json.loads(marker.read_text()) == identity:
            return target.resolve()
        raise FileExistsError("The run label already exists with different or incomplete inputs. Choose another run_label.")
    temporary = _mc_Path(_mc_tempfile.mkdtemp(prefix="convex_build_", dir=str(root)))
    (temporary/"configuration.json").write_text(_mc_json.dumps(serialized, indent=int(2)), encoding="utf-8")
    with open(temporary/"convex_precomputation.log", "w", encoding="utf-8") as log_file:
        with _mc_contextlib.redirect_stdout(log_file):
            database = ns["build_candidate_database"](config, grid, temporary)
            ns["precompute_contributions"](config, grid, database, temporary)
    (temporary/"convex_inputs_complete.json").write_text(_mc_json.dumps(identity, indent=int(2)), encoding="utf-8")
    temporary.rename(target)
    return target.resolve()
