# Provenance et références

## Sources fournies par l'utilisateur

- `murmurations_mod_forms.zip` : `Decomposition of spaces.ipynb`, fonctions `select_factors`, `decomposition_space`, `complete_decomposition` ; code extrait dans `reference/original_decomposition_code.txt`.
- Même archive : `Using modular symbols.ipynb`, construction de l'espace nouveau, calcul des polynômes de Hecke et convention de signe ; code extrait dans `reference/original_symbols_code.txt`.
- Même archive : premier enregistrement de `List of [level,sign, coeffs  = Det and Trace- level 1-2000`, niveau 23, pour les 20 premiers coefficients de la fixture `reference/level23_first20.json`.
- Même archive : sortie de `fields_of_coeff(14,90,3)`, qui donne au niveau 41 le corps cubique défini par x³ + x² − 5x − 1 (discriminant 148), utilisé comme second degré de contrôle dans le test Sage.
- `modforms_ssh.zip` : infrastructure initiale adaptée, mais **le moteur a été remplacé**, ainsi que la supervision des processus pour permettre un arrêt ciblé.
- `SSH_files.zip` : conventions d'organisation `tools/`, journaux datés, PID et codes de sortie, environnement conda Sage, scripts Python compatibles Sage. Aucun PDF de cette archive n'a servi à établir les assertions mathématiques.

Les empreintes des archives sources sont dans `reference/source_archives_sha256.json`.

## Sources primaires Sage consultées le 18 octobre 2026

[S1] Documentation et code source du module des modules de Hecke : `decomposition`, `eigenvalue`, `dual_eigenvector`. La documentation en ligne consultée affiche la version 10.8. Le paramètre `proof` est transmis à la décomposition matricielle ; le choix d'un générateur du corps de valeurs propres peut utiliser une combinaison d'opérateurs.

```text
https://doc.sagemath.org/html/en/reference/hecke/sage/modular/hecke/module.html
https://raw.githubusercontent.com/sagemath/sage/develop/src/sage/modular/hecke/module.py
```

[S2] Espaces et sous-espaces de symboles modulaires ; signification de `is_simple` ; restrictions aux sous-espaces et calcul des matrices ambiantes.

```text
https://doc.sagemath.org/html/en/reference/modsym/sage/modular/modsym/space.html
https://doc.sagemath.org/html/en/reference/modsym/sage/modular/modsym/subspace.html
https://doc.sagemath.org/html/en/reference/hecke/sage/modular/hecke/submodule.html
https://raw.githubusercontent.com/sagemath/sage/develop/src/sage/modular/hecke/submodule.py
```

[S3] Corps de nombres et test d'isomorphisme.

```text
https://doc.sagemath.org/html/en/reference/number_fields/sage/rings/number_field/number_field.html
```

La disponibilité de ces API a été contrôlée dans la documentation. Leur fonctionnement dans l'environnement conda exact du serveur doit être contrôlé par `tests/sage_smoke.py` ; il n'est pas supposé à partir de la seule documentation.


## Ajout v3 : discriminant du corps

La méthode `NumberField.discriminant()` sans argument renvoie le discriminant
de l'anneau des entiers, non celui du polynôme définissant le modèle.
https://doc.sagemath.org/html/en/reference/number_fields/sage/rings/number_field/number_field.html#sage.rings.number_field.number_field.NumberField_generic.discriminant

Code Sage 10.9 pour l'API des modules de Hecke :
https://raw.githubusercontent.com/sagemath/sage/10.9/src/sage/modular/hecke/module.py
