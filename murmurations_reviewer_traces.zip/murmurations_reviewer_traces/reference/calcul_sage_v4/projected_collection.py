"""Checkpointed, checked collection around the independently benchmarked kernel.

This module uses only the standard library plus common.py. Tests can inject an
exact fake projector/reference to exercise resume and failure handling without
pretending to execute Sage arithmetic.
"""
from __future__ import annotations
from common import validate_coefficients


def collect_projected(projector, records, primes, level, *, reference_poly,
                      verify_first=3, checkpoint_every=100, checkpoint=None,
                      report=None, batch_size=32):
    """Fill records in place, save at boundaries, and never round coefficients.

    All orbits share projected Hecke images. For ordinary v4 resumes, skip the
    common saved prefix after exact first/middle/last spot checks. For imported
    v3 partials, recompute and compare EVERY saved coefficient, without replacing
    any of them; a flag survives interruptions until this check is complete.

    Every level also checks first primes against restricted Hecke matrices and
    the largest prime plus all bad primes against the ordinary eigenvalue path.
    An exception aborts the level; it is not recorded as an absent newform.
    """
    if not records or not primes:
        raise ValueError("Expected nonempty records and prime grid")
    if verify_first < 0 or checkpoint_every < 1 or batch_size < 1 or level < 1:
        raise ValueError("Invalid projected collection bounds")
    if any(type(p) is not int or p < 2 for p in primes) or primes != sorted(set(primes)):
        raise ValueError("Expected strictly increasing integer prime indices")
    count = len(primes)
    emit = report or (lambda phase, data: None)
    offsets = []
    for rec in records:
        validate_coefficients(rec, 2, count, complete=False)
        offsets.append(len(rec["hecke_charpolys"]))
    # Independent reference samples on all orbits, including bad primes and the
    # largest index. Do not build a large ambient matrix solely for a last-prime check.
    independent = set(range(min(verify_first, count))) | {count - 1}
    independent.update(i for i, p in enumerate(primes) if level % p == 0)
    samples = set(independent)
    for offset in offsets:
        if offset:
            samples.update(range(min(offset, max(1, verify_first))))
            samples.update((offset // 2, offset - 1))
    indices = sorted(samples)
    checked = projector.compute([primes[i] for i in indices], batch_size=batch_size)
    if len(checked) != len(records) or any(len(row) != len(indices) for row in checked):
        raise ArithmeticError("Incorrect projection sample dimensions")
    for j, rec in enumerate(records):
        for pos, i in enumerate(indices):
            cp = checked[j][pos]
            if i in independent:
                ordinary = reference_poly(j, primes[i], matrix=False)
                if cp != ordinary:
                    raise ArithmeticError(f"Projected/eigenvalue mismatch level={level} orbit={j} p={primes[i]}")
                if i < verify_first:
                    direct = reference_poly(j, primes[i], matrix=True)
                    if cp != direct:
                        raise ArithmeticError(f"Projected/matrix mismatch level={level} orbit={j} p={primes[i]}")
            if i < offsets[j] and cp != rec["hecke_charpolys"][i]:
                raise ArithmeticError(f"Saved prefix mismatch level={level} orbit={j} p={primes[i]}")
        rec["matrix_checked_primes"] = sorted(set(rec.get("matrix_checked_primes", [])) |
                                             set(primes[:min(verify_first, count)]))
        rec["projected_checked_primes"] = [primes[i] for i in sorted(independent)]
    recheck_v3 = any(rec.get("_v3_prefix_needs_check", False) for rec in records)
    start = 0 if recheck_v3 else min(offsets)
    emit("coefficients", {"candidates": len(records), "grouped_orbits": len(records),
                          "done": start, "total": count, "rechecking_v3_prefixes": recheck_v3})
    while start < count:
        end = min(count, (start // checkpoint_every + 1) * checkpoint_every)
        polys = projector.compute(primes[start:end], batch_size=batch_size)
        if len(polys) != len(records) or any(len(row) != end - start for row in polys):
            raise ArithmeticError("Incorrect projected coefficient dimensions")
        for j, rec in enumerate(records):
            for i, cp in zip(range(start, end), polys[j]):
                if len(cp) != 3 or cp[2] != 1 or any(type(c) is not int for c in cp):
                    raise ArithmeticError("Projected output is not a monic integral quadratic polynomial")
                done = len(rec["hecke_charpolys"])
                if i < done:
                    if cp != rec["hecke_charpolys"][i]:
                        raise ArithmeticError(f"Saved prefix mismatch level={level} orbit={j} p={primes[i]}")
                elif i == done:
                    rec["hecke_charpolys"].append(cp)
                    rec["traces"].append(-cp[1])
                    rec["norms"].append(cp[0])
                else:
                    raise ArithmeticError("Noncontiguous projected checkpoint")
            if end >= offsets[j]:
                rec.pop("_v3_prefix_needs_check", None)
        if checkpoint:
            checkpoint()
        emit("coefficients", {"candidates": len(records), "grouped_orbits": len(records),
                              "done": end, "total": count, "prime": primes[end - 1]})
        start = end
    for rec in records:
        validate_coefficients(rec, 2, count)
        if rec.get("_v3_prefix_needs_check", False):
            raise ArithmeticError("Imported prefix was not completely checked")
