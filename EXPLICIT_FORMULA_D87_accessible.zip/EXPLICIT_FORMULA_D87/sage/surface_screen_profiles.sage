"""Exact local parameter domains for g=1,2 over Q; no polynomial enumeration at m<=2.
Load through surface_screen_load.sage. Coefficient lists are in DESCENDING
characteristic-polynomial order; the same list, read in ascending powers of T,
is the Euler denominator. The structural Weil over-family is not Honda--Tate.
"""
import math as _ss_math
from functools import lru_cache as _ss_cache


# reject nonintegers. Input: numeric value. Output: Python int.
#
def _ss_int(value, name="integer"):
    n = int(value)
    if n != value:
        raise ValueError(name + " must be an integer")
    return n


# enumerate rational primes. Input: real bound. Output: list[int], p<bound.
#
def surface_primes_below(bound):
    bound = float(bound)
    stop = int(_ss_math.ceil(bound))
    if stop < 2:
        return []
    sieve = bytearray(b"\x01") * stop
    sieve[:2] = b"\x00\x00"
    for p in range(2, _ss_math.isqrt(stop-1)+1):
        if sieve[p]:
            sieve[p*p:stop:p] = b"\x00" * len(range(p*p, stop, p))
    return [p for p in range(2, stop) if sieve[p]]


# factor the hypothesized conductor. Input: positive int. Output: dict[p, exponent].
#
def surface_conductor_factorization(conductor):
    n = _ss_int(conductor, "conductor")
    if n < 1:
        raise ValueError("conductor must be positive")
    factors, p = {}, 2
    while p*p <= n:
        while n % p == 0:
            factors[p] = factors.get(p, 0)+1
            n //= p
        p = 3 if p == 2 else p+2
    if n > 1:
        factors[n] = factors.get(n, 0)+1
    return factors


# exact quartic completion bounds. Input: prime p, integer a. Output: (b_min,b_max).
# For X^4-aX^3+bX^2-paX+p^2, require |a|<=4sqrt(p) and b_min<=b<=b_max.
# An empty interval means no integral Weil completion. No floating square root is used.
#
def surface_weil_b_interval(p, trace):
    p, a = _ss_int(p), _ss_int(trace)
    if p < 2:
        raise ValueError("p must be at least 2")
    if a*a > 16*p:
        return (1, 0)
    radicand = 4*a*a*p
    root = _ss_math.isqrt(radicand)
    ceil_root = root + int(root*root != radicand)
    return (ceil_root-2*p, a*a//4+2*p)


# generate extendable traces. Input: prime, g=1 or 2. Output: tuple[int].
#
@_ss_cache(maxsize=None)
def _ss_good_traces(p, dimension):
    bound = _ss_math.isqrt(4*dimension*dimension*p)
    return tuple(a for a in range(-bound, bound+1)
                 if dimension == 1 or surface_weil_b_interval(p, a)[0]
                 <= surface_weil_b_interval(p, a)[1])


# exact root power sums. Input: descending monic integer coefficients, m. Output: tuple(S1,...,Sm).
#
def surface_newton_sums(coefficients, max_power):
    c = tuple(_ss_int(v) for v in coefficients)
    mmax = _ss_int(max_power)
    if not c or c[0] != 1 or mmax < 0:
        raise ValueError("Use a monic polynomial and nonnegative max_power")
    d, sums = len(c)-1, [len(c)-1]
    for m in range(1, mmax+1):
        value = sum(c[j]*sums[m-j] for j in range(1, min(m, d+1)))
        if m <= d:
            value += m*c[m]
        sums.append(-value)
    return tuple(sums[1:])


# multiply characteristic polynomials. Input: two descending lists. Output: tuple[int].
#
def _ss_poly_product(a, b):
    out = [0]*(len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return tuple(out)


# filter local reduction by v_p(N). Input: g=1/2, e>=0, bool. Output: tuple[(g_ab,t,u)].
# Bad signatures require t+2u<=e. When u=0, semistability gives e=t exactly.
# Set semistable_exact=False to retain only the weaker lower-exponent condition.
# Wild conductor data are otherwise not classified.
#
def surface_reduction_signatures(dimension, exponent, semistable_exact=True):
    g, e = _ss_int(dimension), _ss_int(exponent)
    if g not in (1, 2) or e < 0:
        raise ValueError("Only dimensions 1 and 2 and nonnegative exponents are supported")
    if e == 0:
        return ((g, 0, 0),)
    return tuple((g-t-u, t, u) for u in range(g+1) for t in range(g-u+1)
                 if t+u > 0 and t+2*u <= e
                 and (not semistable_exact or u > 0 or e == t))


_SS_TORIC = {0: ((1,),), 1: ((1,-1), (1,1)),
             2: ((1,-2,1), (1,0,-1), (1,2,1), (1,1,1), (1,0,1), (1,-1,1))}


# package one local witness. Input: polynomial, signature, m. Output: small dict.
#
def _ss_profile(coefficients, signature, max_power):
    return {"characteristic_coefficients": tuple(coefficients),
            "signature": tuple(signature), "minimum_exponent": signature[1]+2*signature[2],
            "sums": surface_newton_sums(coefficients, max_power)}


# reconstruct a Weil completion. Input: p,g,a, optional b. Output: descending tuple.
#
def _ss_good_coefficients(p, dimension, trace, second=None):
    if dimension == 1:
        return (1, -trace, p)
    b = surface_weil_b_interval(p, trace)[0] if second is None else int(second)
    return (1, -trace, b, -p*trace, p*p)


# build exact local domains in the structural over-family.
# Input: p, g=1/2, m>=0, e=v_p(N), two bools. Output: domain dict with a mode.
# Modes: trace (one integer); trace_second (trace selectors plus integer b);
# profiles (short Newton vectors); unseen (bad prime outside analytic support).
# compact=False enumerates the full small domain, for regression comparisons only.
#
@_ss_cache(maxsize=None)
def surface_local_domain(p, dimension, max_power, conductor_exponent,
                         semistable_exact=True, compact=True):
    p, g, m, e = map(_ss_int, (p, dimension, max_power, conductor_exponent))
    if p < 2 or m < 0:
        raise ValueError("Require p>=2 and m>=0")
    signatures = surface_reduction_signatures(g, e, semistable_exact)
    if not signatures:
        return {"mode": "empty", "p": p}
    if m == 0:
        ab, t, u = signatures[0]
        coeff = _ss_poly_product((1,) if ab == 0 else _ss_good_coefficients(p, ab, 0),
                                 _SS_TORIC[t][0])
        return {"mode": "unseen", "p": p, "witness": _ss_profile(coeff, signatures[0], 0)}
    # At good primes with m<=2, encode all moments directly instead of enumerating quartics.
    if e == 0 and compact and m <= 2:
        traces = _ss_good_traces(p, g)
        if m == 1:
            witnesses = tuple(_ss_profile(_ss_good_coefficients(p, g, a), (g,0,0), 1)
                              for a in traces)
            return {"mode": "trace", "p": p, "values": traces, "witnesses": witnesses}
        if g == 2:
            return {"mode": "trace_second", "p": p, "values": traces,
                    "b_intervals": tuple(surface_weil_b_interval(p, a) for a in traces)}
    # For m>=3 (or bad reduction), enumerate the small remaining structural local family.
    profiles = {}
    for ab, t, u in signatures:
        if ab == 0:
            abelian = [(1,)]
        elif ab == 1:
            abelian = ((1,-a,p) for a in _ss_good_traces(p, 1))
        else:
            abelian = (_ss_good_coefficients(p, 2, a, b) for a in _ss_good_traces(p, 2)
                       for b in range(surface_weil_b_interval(p, a)[0],
                                      surface_weil_b_interval(p, a)[1]+1))
        for poly in abelian:
            for toric in _SS_TORIC[t]:
                profile = _ss_profile(_ss_poly_product(poly, toric), (ab,t,u), m)
                # N is fixed: equivalent moments may use any compatible signature as a witness.
                profiles.setdefault(profile["sums"], profile)
    ordered = tuple(profiles[key] for key in sorted(profiles))
    if compact and m == 1:
        return {"mode": "trace", "p": p, "values": tuple(d["sums"][0] for d in ordered),
                "witnesses": ordered}
    return {"mode": "profiles", "p": p, "profiles": ordered}
