"""Loader for the exact-formula local-factor search.

Loading this file makes the public functions from exact_formula_core, local_factors, precomputation and milp available."""

from pathlib import Path

_CURRENT = Path.cwd()
if (_CURRENT / "sage").is_dir():
    SAGE_DIR = _CURRENT / "sage"
elif (_CURRENT.parent / "sage").is_dir():
    SAGE_DIR = _CURRENT.parent / "sage"
else:
    raise FileNotFoundError(
        "Cannot locate the sage/ directory. Run the notebook from the project root "
        "or from the notebooks/ directory."
    )

load(str(SAGE_DIR / "exact_formula_core.sage"))
load(str(SAGE_DIR / "exact_formula_local_factors.sage"))
load(str(SAGE_DIR / "exact_formula_precomputation.sage"))
load(str(SAGE_DIR / "exact_formula_milp.sage"))
