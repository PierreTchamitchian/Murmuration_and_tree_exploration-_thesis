"""Degree-filtered Hecke primary decomposition, adapted from the supplied notebook.

No Sage import here: the control flow is tested with exact synthetic spectra.
Actual spaces/operators/polynomials in production are Sage objects.
"""
from __future__ import annotations


def hecke_sieve(space, target_degree: int, primes, field_matches=None, progress=None):
    """Return all possible target blocks; do NOT discard unresolved large blocks.

    On a newform orbit with coefficient field F of degree d, the irreducible
    polynomial of a_p has degree dividing d. We preserve the whole f-primary
    block, including repeated linear factors. The subsequent Sage decomposition
    is deliberately separate and is never limited to these screening primes.
    """
    if target_degree < 1:
        raise ValueError("Target degree must be positive")
    active, ready = [space], []
    stats = {"input_dimension": int(space.dimension()), "steps": [],
             "discarded_degree_dimension": 0, "discarded_field_dimension": 0,
             "discarded_small_dimension": 0}
    for p in primes:
        refine = []
        for block in active:
            n = int(block.dimension())
            if n < target_degree:
                stats["discarded_small_dimension"] += n
            elif n == target_degree:
                ready.append(block)
            else:
                refine.append(block)
        active = []
        if not refine:
            break
        before = sum(int(b.dimension()) for b in refine)
        for block in refine:
            T = block.T(p)
            cp = T.charpoly("x")
            n = int(block.dimension())
            if int(cp.degree()) != n:
                raise ArithmeticError("Hecke polynomial degree differs from block dimension")
            factors = list(cp.factor())
            if sum(int(f.degree()) * int(m) for f, m in factors) != n:
                raise ArithmeticError("Incomplete polynomial factorization")
            for f, m in factors:
                e, m = int(f.degree()), int(m)
                primary_dimension = e * m
                if target_degree % e:
                    stats["discarded_degree_dimension"] += primary_dimension
                    continue
                if primary_dimension < target_degree:
                    stats["discarded_small_dimension"] += primary_dimension
                    continue
                # If a_p already has degree d, Q(a_p) must be the target field.
                # This rejection is valid even if the primary block has dimension > d.
                if e == target_degree and field_matches is not None and not field_matches(f):
                    stats["discarded_field_dimension"] += primary_dimension
                    continue
                child = block if primary_dimension == n else ((f ** m)(T)).kernel()
                if int(child.dimension()) != primary_dimension:
                    raise ArithmeticError("Wrong primary-kernel dimension")
                active.append(child)
        step = {"prime": int(p), "dimension_before": before,
                "active_dimensions": [int(b.dimension()) for b in active],
                "ready_dimensions": [int(b.dimension()) for b in ready]}
        stats["steps"].append(step)
        if progress:
            progress("sieve", step)
    # The bound controls speed, not exhaustiveness: large blocks go to Sage.
    survivors = ready[:]
    for block in active:
        n = int(block.dimension())
        if n >= target_degree:
            survivors.append(block)
        else:
            stats["discarded_small_dimension"] += n
    stats["surviving_dimensions"] = [int(b.dimension()) for b in survivors]
    kept = sum(stats["surviving_dimensions"])
    discarded = sum(stats[name] for name in ("discarded_degree_dimension",
                                             "discarded_field_dimension",
                                             "discarded_small_dimension"))
    if kept + discarded != stats["input_dimension"]:
        raise ArithmeticError("Sieve dimension accounting failed")
    return survivors, stats
