"""Mestre explicit-formula conductor bounds over Q and number fields.

The functions in this file implement the fixed-lambda inequalities used in the
original notebooks.  Load the file from a SageMath notebook with ``load(...)``.
"""

from typing import Any, Callable
from sage.all import (
    Infinity, QQ, RealField, ZZ, cos, exp, floor, log,
    numerical_integral, pi, prime_range, sin, sqrt,
)


# evaluate the default compact Mestre test function.
# Input: a real Sage/Python number x.  Output: the real value F(x).
#
def mestre_test_function(x: Any):
    u = abs(x)
    if u > 1:
        return 0
    return (1 - u) * cos(pi * u) + sin(pi * u) / pi


# compute Phi_F(1/2).
# Input: an even test function F and a bit precision.  Output: a Sage real.
#
def phi_at_one_half(
    test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    value, _ = numerical_integral(lambda t: R(test_function(R(t))), 0, 1)
    return 2 * R(value)


# compute the archimedean term M_{lambda,F}.
# Input: lambda > 0, a test function, and a bit precision.  Output: a Sage real.
#
def archimedean_term(
    lambda_value: Any,
    test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    lam = R(lambda_value)
    if lam <= 0:
        raise ValueError('lambda_value must be positive')

    F0 = R(test_function(R(0)))
    small = R(2) ** (-(precision // 3))

    # Regularized integrand for the archimedean term; the apparent singularity is removable.
    #
    def integrand(u):
        y = lam * R(u)
        # The apparent singularity at y = 0 is removable; the limit is F(0)/2.
        if abs(y) <= small:
            return F0 / 2
        return R(test_function(R(u))) / (exp(y) - 1) - F0 * exp(-y) / y

    first, _ = numerical_integral(integrand, 0, 1)
    tail, _ = numerical_integral(lambda x: exp(-R(x)) / R(x), lam, Infinity)
    return 2 * (lam * R(first) - F0 * R(tail) + F0 * log(2 * R(pi)))


# convert a local reduction condition to (g_ab, g_m, g_u).
# Input: None, a supported string, or a length-three tuple; and dimension g.
# Output: a triple of nonnegative integers, or None for an unknown condition.
#
def normalize_reduction_condition(condition: Any, dimension: int):
    g = ZZ(dimension)
    if g < 1:
        raise ValueError('dimension must be positive')
    if condition is None:
        return None

    if isinstance(condition, str):
        name = condition.strip().lower()
        if name in {'unknown', 'any', 'unprescribed'}:
            return None
        if name == 'good':
            return (int(g), 0, 0)
        if name == 'bad':
            # This is the weakest prescribed bad-reduction type in Theorem 4.2.
            return (int(g - 1), 1, 0)
        if g == 1 and name in {'multiplicative', 'mult'}:
            return (0, 1, 0)
        if g == 1 and name in {'additive', 'add'}:
            return (0, 0, 1)
        raise ValueError('unsupported reduction condition: %r' % (condition,))

    if isinstance(condition, (tuple, list)) and len(condition) == 3:
        signature = tuple(ZZ(a) for a in condition)
        if min(signature) < 0 or sum(signature) != g:
            raise ValueError('signature entries must be nonnegative and sum to dimension')
        return tuple(int(a) for a in signature)

    raise TypeError('condition must be None, a supported string, or a triple')


# test whether the base field is Q.
# Input: QQ or a Sage number field.  Output: a Boolean.
#
def is_rational_field(number_field: Any) -> bool:
    return number_field is QQ or number_field == QQ


# read the absolute degree and discriminant.
# Input: QQ or a Sage number field.  Output: (degree, absolute discriminant).
#
def field_degree_and_discriminant(number_field: Any):
    if is_rational_field(number_field):
        return ZZ(1), ZZ(1)
    return ZZ(number_field.absolute_degree()), abs(ZZ(number_field.absolute_discriminant()))


# return the norm of a prime place.
# Input: a prime integer over Q or an exact Sage prime ideal.  Output: an integer.
#
def prime_norm(prime_place: Any):
    if hasattr(prime_place, 'absolute_norm'):
        return ZZ(prime_place.absolute_norm())
    p = ZZ(prime_place)
    if not p.is_prime():
        raise ValueError('an integer prime place over Q must be prime')
    return p


# list prime places of norm at most a bound.
# Input: QQ or a number field, and an integer bound.  Output: a Python list.
#
def prime_places(number_field: Any, norm_bound: Any):
    bound = ZZ(norm_bound)
    if bound < 2:
        return []
    if is_rational_field(number_field):
        return list(prime_range(bound + 1))
    return list(number_field.primes_of_bounded_norm(bound))


# find the condition attached to one exact prime place.
# Input: a prime place and a list of (prime_place, condition).  Output: condition/None.
#
def condition_at_prime(prime_place: Any, reduction_conditions):
    matches = [condition for place, condition in reduction_conditions if place == prime_place]
    if len(matches) > 1:
        raise ValueError('a prime place occurs more than once in reduction_conditions')
    return matches[0] if matches else None


# compute one worst-case non-archimedean penalty.
# Input: a prime place, lambda, dimension, and local condition.  Output: a Sage real.
#
def local_prime_penalty(
    prime_place: Any,
    lambda_value: Any,
    dimension: int = 1,
    condition: Any = None,
    test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    lam = R(lambda_value)
    g = ZZ(dimension)
    if lam <= 0 or g < 1:
        raise ValueError('require lambda_value > 0 and dimension >= 1')

    # q is the residue-field size. Rewrite the reduction condition as (g_ab,g_m,g_u).
    q = prime_norm(prime_place)
    signature = normalize_reduction_condition(condition, int(g))
    g_ab, g_m = (g, ZZ(0)) if signature is None else signature[:2]

    # Sum the worst allowed contribution of q, q^2, q^3, ... inside the support.
    total = R(0)
    q_power = q
    m = 1
    while q_power <= exp(lam):
        argument = m * log(R(q)) / lam
        coefficient = ZZ(g_ab) * floor(2 * sqrt(q_power)) + ZZ(g_m)
        total += coefficient * abs(R(test_function(argument))) / q_power
        # Move through every power q, q^2, q^3, ... .
        q_power *= q
        m += 1
    return 2 * log(R(q)) * total


# evaluate the conductor lower bound at one fixed lambda.
# Input: field, lambda, dimension, rank, and optional exact local conditions.
# Output: a dictionary containing absolute-norm and root-conductor bounds.
#
def conductor_bound(
    number_field: Any,
    lambda_value: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    test_function: Callable = mestre_test_function,
    precision: int = 100,
    phi_value: Any = None,
):
    R = RealField(precision)
    lam = R(lambda_value)
    g = ZZ(dimension)
    rank = ZZ(analytic_rank)
    if lam <= 0 or g < 1 or rank < 0:
        raise ValueError('require lambda > 0, dimension >= 1, analytic_rank >= 0')

    # F is supported on [-1,1], so only prime norms <= exp(lambda) can contribute.
    conditions = tuple(reduction_conditions)
    support_bound = ZZ(floor(exp(lam)))
    penalty = R(0)
    for place in prime_places(number_field, support_bound):
        penalty += local_prime_penalty(
            place,
            lam,
            int(g),
            condition_at_prime(place, conditions),
            test_function,
            precision,
        )

    # Assemble the global formula from rank, archimedean, local-prime and discriminant terms.
    degree, discriminant = field_degree_and_discriminant(number_field)
    phi = phi_at_one_half(test_function, precision) if phi_value is None else R(phi_value)
    archimedean = archimedean_term(lam, test_function, precision)
    log_absolute_bound = (
        lam * rank * phi
        + degree * g * archimedean
        - penalty
        - 2 * g * log(R(discriminant))
    )
    absolute_bound = exp(log_absolute_bound)
    root_bound = exp(log_absolute_bound / degree)

    return {
        'lambda': lam,
        'dimension': g,
        'analytic_rank': rank,
        'degree': degree,
        'discriminant': discriminant,
        'root_discriminant': R(discriminant) ** (R(1) / degree),
        'support_norm_bound': support_bound,
        'log_absolute_norm_bound': log_absolute_bound,
        'absolute_norm_bound': absolute_bound,
        'root_conductor_bound': root_bound,
        'prime_penalty': penalty,
        'archimedean_term': archimedean,
        'phi_at_one_half': phi,
    }
