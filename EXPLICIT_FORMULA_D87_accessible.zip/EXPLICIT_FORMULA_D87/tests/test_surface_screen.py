"""Run with: python tests/test_surface_screen.py (or sage -python ...).
These tests execute the same source used by the Sage entry point. They do not
claim to test Jupyter or Sage's kernel unless actually invoked there.
"""
from pathlib import Path
import json, sys, time, itertools, math
import numpy as np
import scipy
from scipy.optimize import milp, Bounds, LinearConstraint
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
ENV = {"SURFACE_SCREEN_ROOT": ROOT}
loader = ROOT / "sage" / "surface_screen_load.sage"
exec(compile(loader.read_text(encoding="utf-8"), str(loader), "exec"), ENV)
CORE = ENV["prepare_surface_screen"].__globals__
checks = []


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


class ReferenceCurve:
    """Independent point counts for y^2+y=x^3-x^2-10x-20, used only at small primes."""
    def conductor(self):
        return 11
    def ap(self, p):
        count = 1+sum((y*y+y-x**3+x*x+10*x+20) % p == 0
                      for x in range(p) for y in range(p))
        return p+1-count


def full_milp_margin(model):
    """Independent integer phase-I solve, for validating numerical infeasibility outcomes."""
    nv, na = len(model["lower"]), len(model["b"])
    A = np.vstack((np.column_stack((model["A"], -np.ones(na))),
                   np.column_stack((model["H"], np.zeros(len(model["h"])))),
                   np.column_stack((model["E"], np.zeros(len(model["e"]))))))
    lower = np.r_[np.full(na+len(model["h"]), -np.inf), model["e"]]
    upper = np.r_[model["b"], model["h"], model["e"]]
    result = milp(np.r_[np.zeros(nv),1.],integrality=np.r_[model["integer"],0],
                  bounds=Bounds(np.r_[model["lower"],-np.inf], np.r_[model["upper"],np.inf]),
                  constraints=LinearConstraint(A,lower,upper),options={"time_limit":5.0,"mip_rel_gap":0.0})
    return result


start = time.perf_counter()
for p, expected in [(2,35),(3,63),(5,129),(31,1861),(397,84443)]:
    pairs = [(a,*ENV["surface_weil_b_interval"](p,a)) for a in CORE["_ss_good_traces"](p,2)]
    check("quartic count p="+str(p), sum(hi-lo+1 for a,lo,hi in pairs)==expected)
for p in [2,3,5,7,11,13]:
    # Cross-check the interval against the two real quadratic traces.
    for a in range(-math.isqrt(16*p)-1, math.isqrt(16*p)+2):
        lo,hi = ENV["surface_weil_b_interval"](p,a)
        for b in range(-2*p-1,6*p+2):
            D = a*a-4*(b-2*p)
            allowed = D >= 0 and max(abs((a+math.sqrt(max(0,D)))/2),
                                     abs((a-math.sqrt(max(0,D)))/2)) <= 2*math.sqrt(p)+1e-12
            check(f"quartic domain {p},{a},{b}", allowed == (lo<=b<=hi))
for p, expected in [(2,59),(3,93),(5,165),(7,249)]:
    profiles = set()
    for e in range(5):
        domain = ENV["surface_local_domain"](p,2,5,e,True,False)
        for item in domain.get("profiles",()):
            profiles.add((item["characteristic_coefficients"],item["signature"]))
    check("source raw family p="+str(p),len(profiles)==expected)
check("semistable exact exponent", ENV["surface_reduction_signatures"](2,1)==((1,1,0),))
check("purely additive exponent four", (0,0,2) not in ENV["surface_reduction_signatures"](2,3))
check("purely additive exponent four admitted", (0,0,2) in ENV["surface_reduction_signatures"](2,4))
check("Newton recurrence", ENV["surface_newton_sums"]((1,2,2),4)==(-2,0,4,-8))

# Direct source integral, computed independently at high precision.
import mpmath as mp
mp.mp.dps=45
for name in ["odlyzko","source_growth"]:
    def F(u):
        if name=="odlyzko": return (1-u)*mp.cos(mp.pi*u)+mp.sin(mp.pi*u)/mp.pi
        if u<=mp.mpf('0.5'): return 1-mp.mpf(40)/3*u**2+mp.mpf(80)/3*u**3-mp.mpf(40)/3*u**4-mp.mpf(8)/3*u**5
        return mp.mpf(8)/3*(1-u)**5
    for lam in [1.0,1.33,2.0,3.0]:
        L=mp.mpf(lam)
        def integrand(u):
            if abs(u)<mp.mpf('1e-30'): return mp.mpf('0.5')
            z=L*u
            return (z*F(u)+mp.expm1(-z))/(z*mp.expm1(z))
        original=2*(L*mp.quad(integrand,[0,mp.mpf('.5'),1])-mp.e1(L))+2*mp.log(2*mp.pi)
        obtained=ENV["surface_archimedean_term"](lam,name)[0]
        check(f"source integral {name},{lam}",abs(float(original)-obtained)<2e-10)

# Reproduce the user's elliptic 10.39356 result before the old 1e-7 log safety margin.
elliptic = ENV["prepare_surface_screen"]([1+k/100 for k in range(51)],dimension=1)
values=[]
for a2,a3 in itertools.product(range(-2,3),range(-3,4)):
    sums={2:ENV['surface_newton_sums']((1,-a2,2),2),3:(a3,)}
    values.append(max(ENV['surface_evaluate_moments'](sums,l,1,0,'odlyzko') for l in elliptic['lambda_values']))
check("previous elliptic reference", abs(math.exp(min(values))-10.39356161305)<2e-8)

prepared = ENV["prepare_surface_screen"]()
baseline=ENV["scan_surface_conductors"](105,121,time_limit=3)
check("baseline plausible set",baseline["plausible_conductors"]==[115,117,119,121])
check("baseline no unresolved",not baseline["unresolved_conductors"])
refined=ENV["scan_surface_conductors"](105,121,time_limit=3,polynomial_rounds=3)
check("refined plausible set",refined["plausible_conductors"]==[121])
check("refined no unresolved",not refined["unresolved_conductors"])
for N,r in refined["results"].items():
    model=ENV['build_surface_conductor_model'](N,prepared,r['extra_tests'])
    if r['status']=='plausible':
        check("saved witness exact model",ENV['check_surface_vector'](model,r['vector']))
    elif r['status']=='excluded_milp':
        margin=full_milp_margin(model)
        check("integer slack confirms exclusion N="+str(N),margin.status==0 and margin.fun>1e-7)

# The compact and full-profile formulations describe the same integer choices.
expanded = ENV['prepare_surface_screen'](compact=False)
for N in range(105,122):
    r=refined['results'][N]
    M=ENV['build_surface_conductor_model'](N,expanded,r['extra_tests'])
    rr=ENV['solve_surface_conductor_model'](M,time_limit=3)
    check('expanded formulation N='+str(N),(rr['status']=='plausible')==(r['status']=='plausible'))

# Known product E x E should satisfy all generated inequalities, including growth.
moments=ENV['surface_curve_moments'](ReferenceCurve(),3.0,copies=2)
for N,r in refined['results'].items():
    for extra in r['extra_tests']:
        value=ENV['surface_evaluate_moments'](moments,extra['lambda_value'],2,0,extra['test'])
        check('learned test preserves E squared',value<=math.log(121)+1e-8)
growth=[ENV['surface_evaluate_moments'](moments,l,2,0,'source_growth') for l in prepared['lambda_values']]
check('known product sampled growth',all(b>=a for a,b in zip(growth,growth[1:])))
optimized=[]
for degree in [2,4,6]:
    result=ENV['optimize_surface_polynomial_test'](moments,3.0,degree=degree)
    optimized.append(result['conductor_bound'])
    check('normalized test degree='+str(degree),abs(ENV['surface_test_value'](result['test'],0)-1)<1e-11)
    direct=ENV['surface_evaluate_moments'](moments,3.0,2,0,result['test'])
    check('eigen/scalar agreement degree='+str(degree),abs(direct-result['log_bound'])<1e-9)
    check('known-product upper check degree='+str(degree),result['conductor_bound']<121)
check('nested polynomial spaces', optimized==sorted(optimized))

# A timeout or backend exception is not an exclusion.
original_milp=CORE['_ss_milp']
try:
    CORE['_ss_milp']=lambda *a,**k:SimpleNamespace(status=1,message='test time limit',x=None)
    timeout=ENV['solve_surface_conductor_model'](ENV['build_surface_conductor_model'](113,prepared))
    check('timeout classification',timeout['status']=='unresolved')
    def fail(*a,**k):raise RuntimeError('test backend failure')
    CORE['_ss_milp']=fail
    failure=ENV['solve_surface_conductor_model'](ENV['build_surface_conductor_model'](113,prepared))
    check('backend failure classification',failure['status']=='unresolved')
finally:
    CORE['_ss_milp']=original_milp

pruned=ENV['scan_surface_conductors'](105,121,time_limit=3,dual_pruning=True)
check('dual pruning preserves answer',pruned['plausible_conductors']==baseline['plausible_conductors'])
import tempfile
with tempfile.TemporaryDirectory() as d:
    first=ENV['scan_surface_conductors'](119,121,output_directory=d)
    second=ENV['scan_surface_conductors'](119,121,output_directory=d)
    check('saved run reuse',first['results']==second['results'])
    alternate=ENV['scan_surface_conductors'](119,121,output_directory=d,growth_from=None)
    check('assumption change creates new cache',alternate['run_directory']!=first['run_directory'])

report={'passed':len(checks),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,
        'elapsed_seconds':time.perf_counter()-start,
        'sage_kernel_executed':False,'source_sha256':ENV['_SS_SOURCE_HASH'],
        'baseline_plausible':baseline['plausible_conductors'],
        'refined_plausible':refined['plausible_conductors'],
        'known_product_polynomial_bounds_at_lambda_3':dict(zip([2,4,6],optimized)),
        'limits':'CPython executes the same implementation. SciPy MILP exclusions are numerical.\n'
                 'Rational LP certificates concern the stored binary64 model, not integration or analytic hypotheses.'}
(ROOT/'SURFACE_SCREEN_VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
