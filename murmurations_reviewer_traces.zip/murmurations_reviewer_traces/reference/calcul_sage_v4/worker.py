#!/usr/bin/env python3
"""One fresh Sage process per level: bounded lifetime of large algebra caches."""
from __future__ import annotations
import argparse
import os
import sys
import time
import traceback
from pathlib import Path
from common import (SCHEMA, THREAD_VARIABLES, atomic_json, read_json, settings_hash,
                    source_digest, validate_result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--settings", required=True, type=Path)
    parser.add_argument("--level", required=True, type=int)
    ns = parser.parse_args()
    for name in THREAD_VARIABLES:
        os.environ[name] = "1"
    settings = read_json(ns.settings)
    if settings_hash(settings) != settings["settings_hash"]:
        raise ValueError("Invalid settings fingerprint")
    base, level = ns.settings.parent, ns.level
    final = base / f"{level}.json"
    error = base / f"{level}.error.json"
    partial = base / f"{level}.partial.json"
    status = base / f"{level}.progress.json"

    def progress(phase, data):
        atomic_json(status, {"level": level, "pid": os.getpid(), "phase": phase,
                             "time": time.time(), **data})
        print(f"level={level} phase={phase} {data}", flush=True)

    def checkpoint(cache):
        atomic_json(partial, {"schema": SCHEMA, "settings_hash": settings["settings_hash"],
                              "level": level, "sage_version": settings["sage_version"],
                              "components": cache})

    try:
        if source_digest() != settings["source_digest"]:
            raise RuntimeError("Source files changed during the campaign; do not modify a running installation")
        from sage.env import SAGE_VERSION
        from engine import compute_level
        if str(SAGE_VERSION) != settings["sage_version"]:
            raise RuntimeError("Sage version changed; choose a new campaign label")
        resume = None
        if partial.exists():
            saved = read_json(partial)
            if (saved.get("schema"), saved.get("settings_hash"), saved.get("level"),
                saved.get("sage_version")) != (SCHEMA, settings["settings_hash"], level,
                                                settings["sage_version"]):
                raise ValueError("Incompatible partial checkpoint")
            resume = saved["components"]
        result = compute_level(level, settings["poly"], prime_count=settings["primes"],
                               sieve_primes=settings["sieve_primes"],
                               method=settings["coefficient_method"],
                               verify_first=settings["verify_first"], progress=progress,
                               resume=resume, checkpoint=checkpoint,
                               checkpoint_every=settings["checkpoint_every"])
        if source_digest() != settings["source_digest"]:
            raise RuntimeError("Source files changed while computing this level")
        result["settings_hash"] = settings["settings_hash"]
        validate_result(result, settings, level)
        atomic_json(final, result)
        for path in (error, partial, status):
            path.unlink(missing_ok=True)
        print(f"level={level} COMPLETE matches={len(result['records'])}", flush=True)
        return 0
    except Exception:
        text = traceback.format_exc()
        atomic_json(error, {"level": level, "settings_hash": settings["settings_hash"],
                            "time": time.time(), "traceback": text})
        progress("error", {"error_file": str(error)})
        print(text, file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
