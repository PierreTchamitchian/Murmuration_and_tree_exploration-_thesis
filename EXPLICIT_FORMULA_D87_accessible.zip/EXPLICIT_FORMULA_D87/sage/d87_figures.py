"""Trois figures reproductibles pour le notebook D87; aucune nouvelle recherche."""
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

# Lire les points numériques exportés par run_example.
def read_rows(path: Path) -> list[dict]:
    with path.open(encoding='utf8',newline='') as f:
        return list(csv.DictReader(f))

# Représenter la marge d’Odlyzko du prolongement à nouvelles traces nulles.
def plot_odlyzko(source: str | Path):
    rows=read_rows(Path(source)/'exemple_zero.csv')
    x=np.array([float(r['lambda_value']) for r in rows])
    y=np.array([float(r['R_O']) for r in rows])
    fig,ax=plt.subplots(figsize=(8.0,4.1))
    ax.plot(x,y,linewidth=2,label=r'$R_O(\lambda)=\log(87^2)-C_O(\lambda)$')
    ax.axhline(0,linestyle='--',linewidth=1,label='Seuil de rejet')
    ax.set(xlim=(1,4),xlabel=r'$\lambda$',ylabel=r'$R_O(\lambda)$',
           title='Le prolongement à nouvelles traces nulles passe Odlyzko')
    ax.grid(alpha=.2);ax.legend(frameon=False,fontsize=9)
    fig.tight_layout()
    return fig

# Représenter la décroissance qui rejette le même prolongement, sans changer les axes entre tests.
def plot_growth(source: str | Path):
    rows=read_rows(Path(source)/'exemple_zero.csv')
    selected=[r for r in rows if float(r['lambda_value'])>=2.6]
    x=np.array([float(r['lambda_value']) for r in selected])
    y=np.array([float(r['C_G2']) for r in selected])
    fig,ax=plt.subplots(figsize=(8.0,4.1))
    ax.plot(x,y,linewidth=2,label=r'$C_{G_2}(\lambda)$')
    for t in (3.5,3.6):
        j=int(np.argmin(abs(x-t)))
        ax.plot(x[j],y[j],marker='o')
        ax.annotate(f'{t:.1f} ; {y[j]:.6f}',(x[j],y[j]),xytext=(7,9),textcoords='offset points',fontsize=9)
    ax.set(xlim=(2.6,4),xlabel=r'$\lambda$',ylabel=r'$C_{G_2}(\lambda)$',
           title='Le même prolongement échoue à la croissance de G₂')
    ax.ticklabel_format(axis='y',useOffset=False);ax.grid(alpha=.2);ax.legend(frameon=False)
    fig.tight_layout()
    return fig

# Dessiner les 187 prolongements précoces : la deuxième règle seule retire 136 choix.
def plot_early_counts(source: str | Path):
    rows=read_rows(Path(source)/'arbre_partiel_norm19.csv')
    x=[int(r['a_8']) for r in rows]
    o=[int(r['O_survivors']) for r in rows]
    og=[int(r['OG_survivors']) for r in rows]
    fig,ax=plt.subplots(figsize=(8.0,4.1))
    ax.plot(x,o,marker='o',linewidth=1.8,label='Après Odlyzko')
    ax.plot(x,og,marker='s',linewidth=1.8,label='Après Odlyzko et croissance')
    ax.set(xlabel=r'$a_8$',ylabel='Valeurs de $a_{19}$ conservées',xticks=x,yticks=[0,17],ylim=(-1,19),
           title='Premier élagage : 187 prolongements, puis 51')
    ax.grid(alpha=.2);ax.legend(frameon=False)
    fig.tight_layout()
    return fig

# Exporter les figures séparément en SVG vectoriel et PNG, ou les retourner au notebook.
def save_figures(source: str | Path, out: str | Path) -> list[Path]:
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    paths=[]
    for name,func in [('odlyzko_zero',plot_odlyzko),('croissance_zero',plot_growth),('elagage_187',plot_early_counts)]:
        fig=func(source)
        for ext in ('svg','png'):
            path=out/(name+'.'+ext)
            fig.savefig(path,dpi=170,bbox_inches='tight');paths.append(path)
        plt.close(fig)
    return paths
