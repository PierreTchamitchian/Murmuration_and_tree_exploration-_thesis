"""Convex relaxation of the finite-grid Mestre local-factor MILP.

Minimize z with one convex combination of profiles at each prime, instead of
one binary choice. The lambda constraints and optional monotonicity/cutoff
constraints are unchanged. A rational dual certificate and an exactly checked
discrete selection bracket the optimum of the supplied NUMERICAL MILP model.
They do not certify the analytic integrals, a heuristic monotonicity threshold,
or the existence of a global L-function. See MESTRE_CONVEX_README.md.

This .sage file also uses ordinary Python syntax for independent testing.
"""

import builtins as _mc_b
import math as _mc_math
import time as _mc_time
from fractions import Fraction as _mc_Fraction
import numpy as _mc_np
from scipy.optimize import linprog as _mc_linprog
from scipy.sparse import csr_matrix as _mc_csr, hstack as _mc_hstack, vstack as _mc_vstack


# 1. Finite model and continuous optimization


# preserve a binary64 coefficient exactly. Input: real. Output: Fraction.
#
def _mc_fraction(value):
    return _mc_Fraction.from_float(float(value))


# validate the finite model. Input: dict. Output: normalized model dict.
#
def _mc_validate(model):
    b = _mc_np.asarray(model["offsets"], dtype=float)
    C = _mc_np.asarray(model["costs"], dtype=float)
    if b.ndim != 1 or len(b) == 0 or C.ndim != 2 or C.shape[0] != len(b):
        raise ValueError("costs must have shape (len(offsets), number_of_profiles).")
    groups = [[int(k) for k in group] for group in model["groups"]]
    if any(not group for group in groups):
        raise ValueError("Every prime group must contain at least one profile.")
    if sorted(k for group in groups for k in group) != list(range(C.shape[1])):
        raise ValueError("groups must partition the profile columns exactly once.")
    h = _mc_np.asarray(model.get("monotonicity_offsets", []), dtype=float)
    D = _mc_np.asarray(model.get("monotonicity_coefficients", []), dtype=float)
    if D.size == 0:
        D = _mc_np.empty((len(h), C.shape[1]), dtype=float)
        D.fill(float(0))
    if h.ndim != 1 or D.shape != (len(h), C.shape[1]):
        raise ValueError("The monotonicity arrays have incompatible shapes.")
    if not all(_mc_np.isfinite(a).all() for a in (b, C, h, D)):
        raise ValueError("All model coefficients must be finite.")
    cutoff = model.get("log_cutoff")
    if cutoff is not None and not _mc_math.isfinite(float(cutoff)):
        raise ValueError("log_cutoff must be finite or None.")
    return dict(model, groups=groups, offsets=b, costs=C,
                monotonicity_offsets=h, monotonicity_coefficients=D,
                log_cutoff=None if cutoff is None else float(cutoff))


# solve the relaxation without branching. Input: model dict. Output: SciPy result.
#
def _mc_solve_lp(model):
    b, C = model["offsets"], model["costs"]
    h, D = model["monotonicity_offsets"], model["monotonicity_coefficients"]
    n = C.shape[1]
    # Column zero is z. All other columns are nonnegative convex weights.
    rows = [_mc_hstack([-_mc_np.ones((len(b), int(1))), _mc_csr(C)])]
    rhs = [-b]
    if len(h):
        rows.append(_mc_hstack([_mc_np.zeros((len(h), int(1))), _mc_csr(-D)]))
        rhs.append(h)
    if model["log_cutoff"] is not None:
        rows.append(_mc_csr(([float(1)], ([int(0)], [int(0)])), shape=(int(1), n+int(1))))
        rhs.append(_mc_np.array([model["log_cutoff"]], dtype=float))
    eq_rows, eq_cols = [], []
    for p_index, group in enumerate(model["groups"]):
        eq_rows.extend([p_index]*len(group))
        eq_cols.extend(k+int(1) for k in group)
    Aeq = _mc_csr((_mc_np.ones(len(eq_cols)), (eq_rows, eq_cols)),
                  shape=(len(model["groups"]), n+int(1)))
    objective = _mc_np.zeros(n+int(1)); objective[0] = float(1)
    return _mc_linprog(
        objective, A_ub=_mc_vstack(rows, format="csr"), b_ub=_mc_np.concatenate(rhs),
        A_eq=Aeq if len(model["groups"]) else None,
        b_eq=_mc_np.ones(len(model["groups"])) if len(model["groups"]) else None,
        bounds=[(None, None)]+[(float(0), None)]*n, method="highs",
        options={"primal_feasibility_tolerance": float("1e-9"),
                 "dual_feasibility_tolerance": float("1e-9")},
    )


# 2. Exact bounds for the stored numerical model


# certify a dual lower bound. Input: model dict and nonnegative weight lists.
# Output: dict with an exact Fraction lower bound and rational dual weights.
#
def mestre_convex_dual_certificate(model, objective_weights, monotonicity_weights=(), cutoff_weight=0):
    b, C = model["offsets"], model["costs"]
    h, D = model["monotonicity_offsets"], model["monotonicity_coefficients"]
    # Quantize on a common dyadic denominator to keep rational arithmetic small.
    scale = int(2)**int(40)
    # Convert one floating dual weight to a small nonnegative dyadic rational.
    #
    def nonnegative_weight(x):
        return _mc_Fraction(int(round(max(float(0), float(x))*scale)), scale)
    alpha = [nonnegative_weight(v) for v in objective_weights]
    beta = [nonnegative_weight(v) for v in monotonicity_weights]
    if len(alpha) != len(b) or len(beta) != len(h):
        raise ValueError("One dual weight is required per model inequality.")
    nu = nonnegative_weight(cutoff_weight) if model["log_cutoff"] is not None else _mc_Fraction()
    mass = _mc_b.sum(alpha)
    if not mass:
        alpha[0] = _mc_fraction(1); mass = _mc_fraction(1)
    # Stationarity for the free variable z: sum(alpha) = 1 + nu.
    alpha = [a*(_mc_fraction(1)+nu)/mass for a in alpha]
    active_a = [(j, a) for j, a in enumerate(alpha) if a]
    active_b = [(t, v) for t, v in enumerate(beta) if v]
    scores = []
    for k in range(C.shape[1]):
        score = _mc_b.sum(a*_mc_fraction(C[j, k]) for j, a in active_a)
        score -= _mc_b.sum(v*_mc_fraction(D[t, k]) for t, v in active_b)
        scores.append(score)
    eta = [min(scores[k] for k in group) for group in model["groups"]]
    lower = _mc_b.sum(a*_mc_fraction(b[j]) for j, a in active_a)
    lower -= _mc_b.sum(v*_mc_fraction(h[t]) for t, v in active_b)
    lower += _mc_b.sum(eta)
    if nu:
        lower -= nu*_mc_fraction(model["log_cutoff"])
    return {"lower_log_exact": lower, "alpha": alpha, "beta": beta, "nu": nu, "eta": eta}


# verify a discrete choice exactly. Input: model dict, one column index per prime.
# Output: exact Fraction objective if feasible, otherwise None. No feasibility tolerance is used.
#
def mestre_convex_check_selection(model, selection):
    if len(selection) != len(model["groups"]):
        return None
    if any(k not in group for k, group in zip(selection, model["groups"])):
        return None
    for h, row in zip(model["monotonicity_offsets"], model["monotonicity_coefficients"]):
        # Sage preparses literal 0 as Integer(0); keep this exact comparison within Fraction.
        if _mc_fraction(h)+_mc_b.sum(_mc_fraction(row[k]) for k in selection) < _mc_Fraction():
            return None
    values = [_mc_fraction(b)+_mc_b.sum(_mc_fraction(row[k]) for k in selection)
              for b, row in zip(model["offsets"], model["costs"])]
    upper = max(values)
    if model["log_cutoff"] is not None and upper > _mc_fraction(model["log_cutoff"]):
        return None
    return upper


# improve/repair one rounded choice. Input: model and index list. Output: index list (not
# certified).
#
def _mc_improve_selection(model, selection, sweeps=2):
    b, C = model["offsets"], model["costs"]
    h, D = model["monotonicity_offsets"], model["monotonicity_coefficients"]
    choice = list(selection)
    current = b+C[:, choice].sum(axis=1)
    current_h = h+D[:, choice].sum(axis=1)
    for _ in range(int(sweeps)):
        changed = False
        for p_index, group in enumerate(model["groups"]):
            old = choice[p_index]
            base = current-C[:, old]
            objectives = (base[:, None]+C[:, group]).max(axis=0)
            violations = _mc_np.zeros(len(group))
            if len(h):
                base_h = current_h-D[:, old]
                violations = _mc_np.maximum(float(0), -(base_h[:, None]+D[:, group]).min(axis=0))
            if model["log_cutoff"] is not None:
                violations = _mc_np.maximum(violations, objectives-model["log_cutoff"])
            index = min(range(len(group)), key=lambda i: (violations[i], objectives[i]))
            choice[p_index] = group[index]
            current = base+C[:, group[index]]
            if len(h):
                current_h = base_h+D[:, group[index]]
            changed = changed or choice[p_index] != old
        if not changed:
            break
    return choice


# construct a checked upper bound on the MILP optimum. Input: model, LP weights, trials, seed.
# Output: (exact upper objective or None, selected indices or None).
#
def _mc_round_and_check(model, weights, trials, seed):
    rng = _mc_np.random.default_rng(int(seed))
    groups = model["groups"]
    probabilities = []
    for group in groups:
        w = _mc_np.maximum(float(0), weights[group])
        probabilities.append(w/w.sum() if w.sum() else _mc_np.ones(len(group))/len(group))
    first = [group[int(_mc_np.argmax(w))] for group, w in zip(groups, probabilities)]
    best, selected = None, None
    candidates = list(model.get("incumbent_selections", []))+[first]
    for _ in range(int(trials)):
        candidates.append([int(rng.choice(group, p=w)) for group, w in zip(groups, probabilities)])
    seen, starting_points = set(), set()
    for choice in candidates:
        if tuple(choice) in starting_points:
            continue
        starting_points.add(tuple(choice))
        for candidate in (list(choice), _mc_improve_selection(model, choice)):
            key = tuple(candidate)
            if key in seen:
                continue
            seen.add(key)
            upper = mestre_convex_check_selection(model, candidate)
            if upper is not None and (best is None or upper < best):
                best, selected = upper, candidate
    return best, selected


# 3. Public approximation and gap report


# approximate the finite Mestre MILP by an LP and checked rounding.
# Input: model dict (groups, offsets, costs; optional monotonicity arrays/cutoff), trial count,
# seed.
# Output: dictionary; bound_interval brackets the MILP's optimal lower bound, NOT an actual
# conductor.
#
def solve_mestre_convex_model(model, rounding_trials=64, seed=0):
    model = _mc_validate(model)
    if int(rounding_trials) < 0:
        raise ValueError("rounding_trials must be nonnegative.")
    started = _mc_time.perf_counter()
    lp = _mc_solve_lp(model)
    lp_seconds = _mc_time.perf_counter()-started
    if not lp.success:
        raise RuntimeError("LP solver failed (status {}): {}. This is not an exact infeasibility certificate."
                           .format(lp.status, lp.message))
    m, r = len(model["offsets"]), len(model["monotonicity_offsets"])
    dual = -_mc_np.asarray(lp.ineqlin.marginals, dtype=float)
    certificate = mestre_convex_dual_certificate(
        model, dual[:m], dual[m:m+r], dual[-1] if model["log_cutoff"] is not None else 0)
    lower = certificate["lower_log_exact"]
    upper, selection = _mc_round_and_check(model, lp.x[1:], rounding_trials, seed)
    if upper is not None and lower > upper:
        raise ArithmeticError("The exact dual and primal checks disagree; do not use this result.")
    # Convert a logarithmic model bound to conductor scale, with overflow protection.
    #
    def exponent(value):
        if value is None:
            return None
        try:
            return _mc_math.exp(float(value))
        except OverflowError:
            return _mc_math.inf
    lo, hi = exponent(lower), exponent(upper)
    gap = None if upper is None else float(upper-lower)
    relative = None if gap is None else (_mc_math.expm1(gap) if gap < 700 else _mc_math.inf)
    labels = model.get("group_labels", list(range(len(model["groups"]))))
    fractional = [p for p, group in zip(labels, model["groups"])
                  if max(lp.x[k+1] for k in group) < float(1)-float("1e-8")]
    return {
        "lower_conductor_bound": lo, "upper_model_bound": hi, "bound_interval": (lo, hi),
        "relative_gap": relative, "log_gap": gap,
        "lower_log_bound_exact": str(lower),
        "upper_log_bound_exact": None if upper is None else str(upper),
        "lp_log_objective": float(lp.fun), "fractional_primes": fractional,
        "selected_profile_indices": selection, "weights": [float(v) for v in lp.x[1:]],
        "dual_certificate": certificate, "status": "bracketed" if upper is not None else "lower_bound_only",
        "number_of_profiles": int(model["costs"].shape[1]),
        "number_of_variables": int(model["costs"].shape[1]+1),
        "number_of_constraints": int(m+r+len(model["groups"])+(model["log_cutoff"] is not None)),
        "lp_seconds": lp_seconds, "total_seconds": _mc_time.perf_counter()-started,
        "certificate_scope": "Exact rational certificate for the stored binary64 coefficient model only.",
    }
