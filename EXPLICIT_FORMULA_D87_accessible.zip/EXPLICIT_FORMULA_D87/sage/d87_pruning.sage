"""Chargeur facultatif pour Sage : la même interface que le notebook D87.

Depuis la racine : load('sage/d87_pruning.sage')
Depuis un notebook : définir D87_PROJECT_ROOT puis charger ce fichier.
"""
from pathlib import Path
import sys
_D87_ROOT = globals().get('D87_PROJECT_ROOT')
if _D87_ROOT is None:
    _D87_ROOT = next((p for p in [Path.cwd(), *Path.cwd().parents]
                     if (p/'sage/d87_core.py').is_file()), None)
if _D87_ROOT is None:
    raise RuntimeError('Définir D87_PROJECT_ROOT ou se placer dans le projet.')
sys.path.insert(0,str(Path(_D87_ROOT)/'sage'))
from d87_workflow import prepare, initial_branches, early_branches, run_example, read_csv, table
from d87_precision import verify_rejections
