#!/usr/bin/env python3
"""Entrée unique D87 : démonstration, reproduction complète, contrôle indépendant."""
from pathlib import Path
import argparse
import json
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'sage'))

# Lire les paramètres et appeler exclusivement les routines D87 documentées.
def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',nargs='?',choices=['demo','reproduire','verifier','reference'],default='demo')
    parser.add_argument('--out',type=Path,help='Dossier de sortie, séparé des références.')
    parser.add_argument('--step',type=float,default=0.01,help='Pas de grille; 0.01 reproduit le résultat archivé.')
    parser.add_argument('--seconds-per-stage',type=float,default=60.0)
    parser.add_argument('--source',type=Path,help='Dossier contenant certificate_float.json pour verifier.')
    parser.add_argument('--digits',type=int,default=70)
    args=parser.parse_args()
    try:
        from d87_workflow import run_example,REFERENCE
        if args.action=='reference':
            print('RÉFÉRENCE ARCHIVÉE — aucun calcul exécuté.')
            print((REFERENCE/'bilan.json').read_text(encoding='utf8'))
            return 0
        if args.action=='verifier':
            from d87_precision import verify_rejections
            source=args.source or REFERENCE
            out=args.out or ROOT/'outputs/D87_precision'
            if out.resolve()==REFERENCE.resolve() or REFERENCE.resolve() in out.resolve().parents:
                raise ValueError('Choisir un dossier hors des références pour les nouveaux contrôles.')
            print('Recalcul haute précision de la couverture située dans : '+str(source),flush=True)
            result=verify_rejections(source,out,args.digits)
            print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2,ensure_ascii=False))
            print('Contrôle numérique, sans arithmétique d’intervalles.')
            return 0
        out=args.out or ROOT/'outputs'/('D87' if args.action=='reproduire' else 'D87_demo')
        summary=run_example(out,full=args.action=='reproduire',step=args.step,
                            seconds_per_stage=args.seconds_per_stage)
        print(json.dumps(summary,indent=2,ensure_ascii=False))
        print('Données enregistrées dans : '+str(out.resolve()))
        print('Croissance imposée comme hypothèse supplémentaire; calculs non certifiés par intervalles.')
        if not summary['no_branch_to_4']:
            print('Exploration non concluante : consulter pending, borderline et les budgets.',file=sys.stderr)
            return 2
        return 0
    except (ImportError,ValueError,FileNotFoundError,ArithmeticError,RuntimeError) as exc:
        print(f'Erreur : {exc}',file=sys.stderr)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
