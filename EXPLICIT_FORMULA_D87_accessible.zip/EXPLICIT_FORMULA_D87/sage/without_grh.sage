"""Unconditional variant obtained by the Odlyzko cosh modification."""

from typing import Any, Callable
from sage.all import RealField, cosh


# build F(x)/cosh(lambda*x/2) in normalized coordinates.
# Input: lambda and a compact base test function.  Output: a callable function.
#
def no_grh_test_function(
    lambda_value: Any,
    base_test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    lam = R(lambda_value)
    if lam <= 0:
        raise ValueError('lambda_value must be positive')

    # Evaluate the cosh-modified test function used in the no-GRH inequality.
    #
    def modified(x):
        x = R(x)
        return R(base_test_function(x)) / cosh(lam * x / 2)

    return modified


# evaluate the no-GRH conductor bound at one lambda.
# Input: the usual bound data.  Output: the standard conductor-bound dictionary.
#
def conductor_bound_without_grh(
    number_field: Any,
    lambda_value: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    base_test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    modified = no_grh_test_function(lambda_value, base_test_function, precision)
    result = conductor_bound(
        number_field=number_field,
        lambda_value=lambda_value,
        dimension=dimension,
        analytic_rank=analytic_rank,
        reduction_conditions=reduction_conditions,
        test_function=modified,
        precision=precision,
    )
    result['assumption'] = 'without_GRH'
    return result


# reproduce the original no-GRH workflow.
# Input: field and bound data.  Output: no-GRH result at the GRH-selected lambda.
#
def original_no_grh_bound(
    number_field: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    start_lambda: Any = 1,
    steps=(1, 0.1, 0.01),
    safety_lambda: Any = 50,
    precision: int = 100,
):
    grh_result = optimal_bound(
        number_field=number_field,
        dimension=dimension,
        analytic_rank=analytic_rank,
        reduction_conditions=reduction_conditions,
        start_lambda=start_lambda,
        steps=steps,
        safety_lambda=safety_lambda,
        precision=precision,
    )
    result = conductor_bound_without_grh(
        number_field=number_field,
        lambda_value=grh_result['lambda'],
        dimension=dimension,
        analytic_rank=analytic_rank,
        reduction_conditions=reduction_conditions,
        precision=precision,
    )
    result['lambda_source'] = 'GRH staged optimum, as in the original notebook'
    result['grh_reference_bound'] = grh_result
    return result


# optionally optimize the modified no-GRH bound itself.
# Input: field and staged-search parameters.  Output: the selected result dictionary.
#
def optimal_bound_without_grh(
    number_field: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    start_lambda: Any = 1,
    steps=(1, 0.1, 0.01),
    safety_lambda: Any = 50,
    precision: int = 100,
):
    # Evaluate the no-GRH bound at one trial lambda during the staged search.
    #
    def evaluate(lam):
        return conductor_bound_without_grh(
            number_field=number_field,
            lambda_value=lam,
            dimension=dimension,
            analytic_rank=analytic_rank,
            reduction_conditions=reduction_conditions,
            precision=precision,
        )

    result = staged_lambda_search(
        evaluate,
        start_lambda=start_lambda,
        steps=steps,
        safety_lambda=safety_lambda,
        precision=precision,
    )
    result['lambda_source'] = 'direct optimization of the no-GRH bound'
    return result
