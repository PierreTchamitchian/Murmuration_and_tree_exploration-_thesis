"""Run with: python tests/check_mestre_convex_relaxation.py

Execute the actual numerical .sage source as ordinary Python. Tests exercise
HiGHS, exact rational certificates, rounding, and saved-run parsing. This does
not test Sage's preparser or the optional original Sage precomputation loader.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
import json
import math
import platform
import sys
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
API = {}
for name in ("mestre_convex_relaxation.sage", "mestre_convex_run_io.sage"):
    file = ROOT / "sage" / name
    exec(compile(file.read_text(encoding="utf-8"), str(file), "exec"), API)


def exact_dual_check(model, certificate):
    """Independently check all rational dual inequalities and the objective."""
    Q = lambda x: Fraction.from_float(float(x))
    alpha, beta, nu, eta = (certificate[k] for k in ("alpha", "beta", "nu", "eta"))
    assert all(v >= 0 for v in alpha + beta + [nu])
    assert sum(alpha) == 1 + nu
    assert model["log_cutoff"] is not None or nu == 0
    for e, group in zip(eta, model["groups"]):
        for k in group:
            value = sum(a*Q(model["costs"][j, k]) for j, a in enumerate(alpha))
            value -= sum(v*Q(model["monotonicity_coefficients"][t, k]) for t, v in enumerate(beta))
            assert e <= value
    value = sum(a*Q(model["offsets"][j]) for j, a in enumerate(alpha))
    value -= sum(v*Q(model["monotonicity_offsets"][t]) for t, v in enumerate(beta))
    value += sum(eta)
    if nu:
        value -= nu*Q(model["log_cutoff"])
    assert value == certificate["lower_log_exact"]


def check(model):
    """Compare the relaxation with complete enumeration of a small finite model."""
    model = API["_mc_validate"](model)
    result = API["solve_mestre_convex_model"](model, rounding_trials=12)
    exact_dual_check(model, result["dual_certificate"])
    values = [API["mestre_convex_check_selection"](model, list(s))
              for s in product(*model["groups"])]
    feasible = [v for v in values if v is not None]
    if feasible:
        true_min = min(feasible)
        assert Fraction(result["lower_log_bound_exact"]) <= true_min
        if result["upper_log_bound_exact"] is not None:
            assert true_min <= Fraction(result["upper_log_bound_exact"])
    else:
        assert result["upper_model_bound"] is None
    return result, len(feasible)


def main():
    summaries = []
    gap, _ = check(dict(groups=[[0, 1]], offsets=[0, 0], costs=[[0, 2], [2, 0]]))
    assert gap["lower_log_bound_exact"] == "1" and gap["upper_log_bound_exact"] == "2"
    assert gap["fractional_primes"] == [0]
    no_integer, _ = check(dict(groups=[[0, 1]], offsets=[0], costs=[[0, 2]],
                              monotonicity_offsets=[-.5, .5], monotonicity_coefficients=[[0, 1], [0, -1]]))
    assert no_integer["status"] == "lower_bound_only"
    cutoff, _ = check(dict(groups=[[0, 1]], offsets=[0, 0], costs=[[0, 2], [2, 0]], log_cutoff=1.5))
    assert cutoff["upper_model_bound"] is None
    check(dict(groups=[], offsets=[2, 3], costs=[[], []]))
    rng = np.random.default_rng(941)
    random_passed = 0
    for _ in range(60):
        C = rng.integers(-4, 6, size=(4, 7)).astype(float)
        D = rng.integers(-2, 3, size=(2, 7)).astype(float)
        h = np.maximum(0, -D[:, [0, 3, 5]].sum(axis=1))
        check(dict(groups=[[0, 1, 2], [3, 4], [5, 6]], offsets=[2, 3, 4, 5], costs=C,
                   monotonicity_offsets=h, monotonicity_coefficients=D))
        random_passed += 1
    reference = ROOT / "tests" / "fixtures" / "elliptic_g1_validation_run"
    for mono in (False, True):
        model = API["load_mestre_convex_run"](reference, monotonicity=mono)
        result, feasible = check(model)
        assert result["number_of_profiles"] == 18
        assert result["number_of_variables"] == 19
        assert result["number_of_constraints"] == (107 if mono else 55)
        assert abs(result["lower_conductor_bound"]-10.39356161305) < 1e-9
        assert result["relative_gap"] < 1e-12
        summaries.append(dict(monotonicity=mono, bound_interval=result["bound_interval"],
                              relative_gap=result["relative_gap"], feasible_choices=feasible,
                              number_of_variables=result["number_of_variables"],
                              number_of_constraints=result["number_of_constraints"]))
    # Parsing and report serialization are exercised on a disposable copy.
    import tempfile, shutil
    with tempfile.TemporaryDirectory() as temp:
        copy = Path(temp)/"run"; shutil.copytree(reference, copy)
        result = API["relax_mestre_saved_run"](copy, monotonicity=True, rounding_trials=4)
        report = Path(result["report_directory"])
        assert (report/"convex_dual_certificate.json").is_file()
        assert (report/"convex_checked_selection.csv").is_file()
        assert (report/"convex_numerical_model.npz").is_file()
    report = {
        "numerical_tests": "passed", "random_models_checked_by_full_enumeration": random_passed,
        "synthetic_tests": ["strict integrality gap", "no feasible integer selection", "cutoff", "no primes"],
        "elliptic_reference": summaries,
        "reference_provenance": "Independent mpmath evaluation of the supplied analytic formulas, not an execution of Sage precomputation.",
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
        "sage_precomputation_executed": False,
        "analytic_interval_certification": False,
        "certificate_scope": "Exact lower and upper logarithmic bounds for the stored binary64 finite models.",
    }
    (ROOT/"MESTRE_CONVEX_VALIDATION.json").write_text(json.dumps(report, indent=2)+"\n")
    print("Passed: exact dual certificates, 60 random exhaustive comparisons, four edge cases,")
    print("the 80-choice elliptic reference (with and without monotonicity), and report I/O.")
    print("Sage precomputation and Sage preparsing were not executed by this test.")


if __name__ == "__main__":
    main()
