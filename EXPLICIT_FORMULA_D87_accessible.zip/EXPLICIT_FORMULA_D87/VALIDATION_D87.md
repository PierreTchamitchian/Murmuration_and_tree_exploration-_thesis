# Validation de l’ajout D87

## Exécuté lors du conditionnement

- **58 fichiers** du projet fourni conservés octet pour octet; aucun ancien module remplacé.
- Les **10 routines de calcul** de `d87_core.py` ont les mêmes arbres syntaxiques
  exécutables que les fonctions correspondantes du programme D87 archivé.
- **14 tests unitaires passés**, dont **40 modèles entiers aléatoires** comparés
  à une énumération complète, les cas D87 et le refus de poids de couverture incorrects.
- Démonstration réellement recalculée : 441 → 1; 187 → 51; fermeture finale.
- **Sept paliers recalculés**, comptages identiques à `progression.csv` archivé.
- Couverture finale de **34 boîtes** identique après sérialisation JSON.
- Poids entiers et disjonction recomptés indépendamment : **18 919 991 475** prolongements.
- Recalcul indépendant des **34 rejets à 70 chiffres de travail** : toutes les marges positives.
- Notebook `16_D87_tree_pruning.ipynb` validé et **12 cellules de code exécutées
  sous Python 3, sans erreur**. Les sorties sont incluses dans le notebook.

Les journaux et résultats de contrôle sont dans `tests/fixtures/D87_validation/`.
Les versions effectivement utilisées sont dans `VALIDATION_D87.json`.

## Non exécuté ici

- SageMath natif n’est pas installé dans l’environnement de conditionnement.
  Le test `sage tests/smoke_d87.sage` est fourni pour vérifier les idéaux et
  la correspondance du terme archimédien avec le module Sage fourni.
- Les 14 anciens notebooks n’ont pas été réexécutés; ils sont inchangés.
- Aucune certification par arithmétique d’intervalles. Les 70 chiffres sont
  une précision de travail, pas un nombre de décimales garanties.
- La croissance sur grille demeure une hypothèse supplémentaire, non une
  conséquence générale démontrée de l’équation fonctionnelle.

`VALIDATION.md` et `VALIDATION.json` concernent le projet original. Ce fichier
ne remplace pas leurs déclarations.
