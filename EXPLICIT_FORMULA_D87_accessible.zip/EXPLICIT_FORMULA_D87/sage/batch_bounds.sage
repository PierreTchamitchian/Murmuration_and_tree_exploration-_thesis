"""Compute the Weil-approximation conductor bound for many number fields and save one CSV row per field."""

import csv
import json
from pathlib import Path
from sage.all import NumberField, PolynomialRing, QQ, RealField

BOUND_COLUMNS = [
    "label", "coefficients", "polynomial", "signature", "degree", "discriminant",
    "root_discriminant", "lambda", "absolute_norm_bound", "root_conductor_bound", "configuration",
]

# Store the common calculation settings in every CSV row so incompatible runs cannot be mixed.
# Input: calculation parameters. Output: deterministic JSON string.
#
def _configuration_string(dimension, analytic_rank, lambda_value, start_lambda, steps, safety_lambda, precision):
    return json.dumps({
        "dimension": int(dimension), "analytic_rank": int(analytic_rank),
        "lambda_value": None if lambda_value is None else str(lambda_value),
        "start_lambda": str(start_lambda), "steps": [str(step) for step in steps],
        "safety_lambda": str(safety_lambda), "precision": int(precision),
    }, sort_keys=True)

# Read a previously saved batch calculation.
# Input: CSV path. Output: list of dictionaries; values are strings exactly as stored in the CSV.
#
def load_bound_results(output_file):
    path = Path(output_file)
    if not path.is_file():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))

# Compute one bound for every field record and save each completed field immediately.
# Input: records, CSV path, common dimension/rank, and lambda_value.
#        lambda_value=None uses the original staged optimization separately for each field.
# Output: list of all saved CSV rows, including rows reused when resume=True.
#
def compute_field_bounds(records, output_file, dimension=1, analytic_rank=0, lambda_value=None,
                         start_lambda=1, steps=(1,0.1,0.01), safety_lambda=50, precision=100,
                         max_records=None, resume=True, progress_every=25):
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    records = list(records)
    if max_records is not None:
        records = records[:int(max_records)]
    if not records:
        raise ValueError("The input contains no field records.")

    configuration = _configuration_string(
        dimension, analytic_rank, lambda_value, start_lambda, steps, safety_lambda, precision
    )
    previous_rows = load_bound_results(path) if resume else []
    if previous_rows and previous_rows[0].get("configuration") != configuration:
        raise ValueError("Existing CSV uses different parameters; choose a new output filename.")
    completed = {row["label"] for row in previous_rows}

    with path.open("a" if previous_rows else "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=BOUND_COLUMNS)
        if not previous_rows:
            writer.writeheader()
        for index, record in enumerate(records, start=1):
            label = str(record.get("label", "field_%s" % index))
            if label in completed:
                continue

            # Reconstruct K from the polynomial data stored in this record.
            K = field_from_record(record, generator_name="a%s" % index)

            # Evaluate the basic Weil-approximation formula, either at fixed lambda or at the staged optimum.
            if lambda_value is None:
                result = optimal_bound(K, dimension=dimension, analytic_rank=analytic_rank,
                                       start_lambda=start_lambda, steps=steps,
                                       safety_lambda=safety_lambda, precision=precision)
            else:
                result = conductor_bound(K, lambda_value=lambda_value, dimension=dimension,
                                         analytic_rank=analytic_rank, precision=precision)

            polynomial = record.get("poly", K.absolute_polynomial())
            coefficients = record.get("coeffs", list(polynomial))
            row = {
                "label": label,
                "coefficients": json.dumps([int(c) for c in coefficients]),
                "polynomial": str(polynomial),
                "signature": json.dumps([int(v) for v in K.signature()]),
                "degree": str(result["degree"]),
                "discriminant": str(result["discriminant"]),
                "root_discriminant": str(result["root_discriminant"]),
                "lambda": str(result["lambda"]),
                "absolute_norm_bound": str(result["absolute_norm_bound"]),
                "root_conductor_bound": str(result["root_conductor_bound"]),
                "configuration": configuration,
            }
            writer.writerow(row); handle.flush()
            previous_rows.append(row); completed.add(label)
            if progress_every and index % int(progress_every) == 0:
                print("%s / %s fields processed" % (index, len(records)))
    return previous_rows

# Compatibility wrapper for the old v1 name: always optimize lambda separately for each field.
# Input/output: same as compute_field_bounds, with lambda_value fixed to None.
#
def compute_optimal_bounds(records, output_file, **kwargs):
    return compute_field_bounds(records, output_file, lambda_value=None, **kwargs)

# Reconstruct fields whose saved root-conductor bound is above a chosen threshold.
# Input: batch CSV and threshold. Output: list of Sage number fields.
#
def fields_with_root_bound_above(output_file, threshold=1):
    R = RealField(100)
    polynomial_ring = PolynomialRing(QQ, "x")
    fields = []
    for index, row in enumerate(load_bound_results(output_file), start=1):
        if R(row["root_conductor_bound"]) > R(threshold):
            coefficients = json.loads(row["coefficients"])
            fields.append(NumberField(polynomial_ring(coefficients), "a%s" % index))
    return fields
