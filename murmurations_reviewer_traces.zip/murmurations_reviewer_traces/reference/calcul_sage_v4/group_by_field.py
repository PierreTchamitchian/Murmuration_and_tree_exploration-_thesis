#!/usr/bin/env python3
"""Export complete quadratic-orbit records into one directory per field.

Read level checkpoints only; no Sage computation and no pooling of different
fields. The output is published only after all requested files validate.
"""
from __future__ import annotations
import argparse
import csv
import json
import os
from pathlib import Path
import shutil
import tempfile
from common import ROOT, atomic_json, read_json, validate_label, validate_result


def export_fields(base: Path, settings: dict, lo: int, hi: int,
                  allow_incomplete: bool = False, output: Path | None = None) -> Path:
    if lo < 1 or hi < lo:
        raise ValueError("Invalid level interval")
    if settings["degree"] != 2:
        raise ValueError("This exporter groups quadratic fields only")
    paths, missing = [], []
    for level in range(lo, hi + 1):
        path = base / f"{level}.json"
        if not path.exists():
            missing.append(level)
        else:
            # Validate BEFORE publishing anything, also for zero-match levels.
            validate_result(read_json(path), settings, level)
            paths.append(path)
    if missing and not allow_incomplete:
        raise ValueError(f"{len(missing)} missing/error levels; export refused. First missing: {missing[:20]}")
    suffix = "_INCOMPLETE" if missing else ""
    output = Path(output) if output else base / f"by_field_N{lo}_{hi}{suffix}"
    if output.exists():
        raise FileExistsError(f"Output exists: {output}. Use --output NEW_DIRECTORY; existing data are never overwritten.")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".by_field.", dir=output.parent))
    fields = {}
    try:
        for path in paths:
            result = read_json(path)
            level = int(path.stem)
            validate_result(result, settings, level)
            by_D = {}
            for record in result["records"]:
                info = record["coefficient_field"]
                D = info["discriminant"]
                if D not in fields:
                    fields[D] = {**info, "orbit_count": 0, "embedding_count": 0,
                                 "level_count": 0, "root_minus": 0, "root_plus": 0,
                                 "min_level_found": level, "max_level_found": level}
                    (temporary / info["id"]).mkdir()
                item = fields[D]
                item["orbit_count"] += 1
                item["embedding_count"] += 2
                item["root_plus" if record["root_number"] == 1 else "root_minus"] += 1
                item["max_level_found"] = level
                by_D.setdefault(D, []).append({"level": level, **record})
            # Open at most one field file at a time, even for many fields.
            for D, records in by_D.items():
                fields[D]["level_count"] += 1
                target = temporary / fields[D]["id"] / "forms.jsonl"
                with target.open("a", encoding="utf-8") as stream:
                    for record in records:
                        stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")
        manifest = {"schema": settings["schema"], "settings_hash": settings["settings_hash"],
                    "field_mode": settings["field_mode"], "complete": not missing,
                    "exhaustive_over_all_quadratic_fields": not missing and settings["field_mode"] == "all_quadratic",
                    "min_level": lo, "max_level": hi, "missing_levels": missing,
                    "levels_used": len(paths), "prime_count": settings["primes"],
                    "prime_indices": settings["prime_indices"], "field_count": len(fields),
                    "orbit_count": sum(item["orbit_count"] for item in fields.values()),
                    "forms_convention": "Galois orbits; two conjugate normalized newforms per quadratic orbit",
                    "coefficients_convention": "hecke_charpolys=[Norm(a_p),-Trace(a_p),1]; no chosen embedding",
                    "settings": settings}
        for D, item in fields.items():
            atomic_json(temporary / item["id"] / "field.json",
                        {**item, "settings_hash": settings["settings_hash"],
                         "prime_indices": settings["prime_indices"], "prime_count": settings["primes"],
                         "requested_min_level": lo, "requested_max_level": hi,
                         "interval_complete": not missing})
        names = ["id", "discriminant", "radicand", "canonical_polynomial", "orbit_count",
                 "embedding_count", "level_count", "root_minus", "root_plus", "min_level_found", "max_level_found"]
        with (temporary / "fields.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=names, extrasaction="ignore")
            writer.writeheader()
            for D in sorted(fields):
                row = dict(fields[D])
                row["canonical_polynomial"] = json.dumps(row["canonical_polynomial"])
                writer.writerow(row)
        atomic_json(temporary / "manifest.json", manifest)
        os.rename(temporary, output)
        return output
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("label")
    parser.add_argument("--min-level", type=int, required=True)
    parser.add_argument("--max-level", type=int, required=True)
    parser.add_argument("--allow-incomplete", action="store_true")
    parser.add_argument("--output", type=Path)
    ns = parser.parse_args()
    validate_label(ns.label)
    base = ROOT / "results" / ns.label
    try:
        output = export_fields(base, read_json(base / "settings.json"), ns.min_level,
                               ns.max_level, ns.allow_incomplete, ns.output)
    except (ValueError, FileExistsError) as exc:
        parser.error(str(exc))
    manifest = read_json(output / "manifest.json")
    print(f"EXPORT={output} FIELDS={manifest['field_count']} ORBITS={manifest['orbit_count']} COMPLETE={manifest['complete']}")
    return 0 if manifest["complete"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
