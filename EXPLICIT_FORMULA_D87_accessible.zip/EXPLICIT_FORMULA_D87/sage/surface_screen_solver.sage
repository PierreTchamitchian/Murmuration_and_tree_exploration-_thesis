"""LP-first feasibility, exact finite-model checks, and bounded-time integer solving.
Certificates concern the stored binary64 coefficient model ONLY. Quadrature,
GRH and the sampled growth hypothesis are not certified by these routines.
"""
from fractions import Fraction as _ss_Fraction
from scipy.optimize import linprog as _ss_linprog, milp as _ss_milp
from scipy.optimize import LinearConstraint as _ss_LinearConstraint, Bounds as _ss_Bounds
from scipy.sparse import csc_matrix as _ss_csc
import time as _ss_time


# preserve a stored binary64 coefficient. Input: number. Output: Python Fraction.
#
def _ss_fraction(value):
    return _ss_Fraction.from_float(float(value))


# exact finite-model scalar product. Input: real row, rational values. Output: Fraction.
#
def _ss_exact_dot(row, values):
    return sum((_ss_fraction(c)*v for c,v in zip(row,values) if c and v), _ss_Fraction())


# check a candidate without an unreported feasibility tolerance.
# Input: model dict, real vector, bool. Output: bool for the stored padded numerical model.
# Integer candidates are rounded only if each coordinate is within 1e-5 of an integer.
#
def check_surface_vector(model, vector, require_integer=True):
    x = _ss_np.asarray(vector,dtype=float)
    if x.shape != model["lower"].shape or not _ss_np.all(_ss_np.isfinite(x)):
        return False
    if require_integer:
        if _ss_np.any(_ss_np.abs(x-_ss_np.rint(x)) > 1e-5):
            return False
        x = _ss_np.rint(x)
    if _ss_np.any(x < model["lower"]) or _ss_np.any(x > model["upper"]):
        return False
    xx = [_ss_fraction(v) for v in x]
    for key,rhs in (("A","b"),("H","h")):
        if any(_ss_exact_dot(row,xx) > _ss_fraction(v) for row,v in zip(model[key],model[rhs])):
            return False
    return all(_ss_exact_dot(row,xx) == _ss_fraction(v) for row,v in zip(model["E"],model["e"]))


# verify a phase-I dual lower bound using rationals.
# Input: model and HiGHS LP result. Output: dict with exact lower bound and reduced scores.
# For s>=A_j*x-b_j, min s >= -alpha*b-mu*h-nu*e + min_box d*x,
# where alpha>=0, sum(alpha)=1, mu>=0 and d=alpha*A+mu*H+nu*E.
#
def _ss_phase_certificate(model, result):
    na = len(model["b"])
    scale = 2**36
    # quantize a dual weight. Input: real and sign flag. Output: Fraction.
    #
    def weight(v, positive=False):
        v = max(0.0,float(v)) if positive else float(v)
        return _ss_Fraction(int(round(v*scale)), scale)
    alpha = [weight(-v,True) for v in result.ineqlin.marginals[:na]]
    mu = [weight(-v,True) for v in result.ineqlin.marginals[na:]]
    nu = [weight(-v) for v in result.eqlin.marginals]
    mass = sum(alpha,_ss_Fraction())
    if not mass:
        alpha = [_ss_Fraction(int(j==0)) for j in range(na)]; mass = _ss_Fraction(1)
    alpha,mu,nu = ([v/mass for v in weights] for weights in (alpha,mu,nu))
    active = [(w,row) for weights,key in ((alpha,"A"),(mu,"H"),(nu,"E"))
              for w,row in zip(weights,model[key]) if w]
    scores = [sum((w*_ss_fraction(row[k]) for w,row in active if row[k]),_ss_Fraction())
              for k in range(len(model["lower"]))]
    lower = -_ss_exact_dot(model["b"],alpha)-_ss_exact_dot(model["h"],mu)-_ss_exact_dot(model["e"],nu)
    lower += sum((min(d*_ss_fraction(lo),d*_ss_fraction(hi))
                  for d,lo,hi in zip(scores,model["lower"],model["upper"])),_ss_Fraction())
    return {"lower":lower,"scores":scores,"alpha":alpha,"mu":mu,"nu":nu}


# optional safe integer-domain pruning. Input: model, rational certificate. Output: number
# tightened.
# Each deviation from the best box endpoint must cost at most -certificate['lower'].
# This changes solver bounds only; no local profile is discarded because of zero LP weight.
#
def _ss_dual_tighten(model, certificate):
    budget = -certificate["lower"]
    if budget < _ss_Fraction():
        return 0
    changed = 0
    for j,d in enumerate(certificate["scores"]):
        if not d:
            continue
        lo,hi = int(model["lower"][j]),int(model["upper"][j])
        distance = budget/abs(d)
        whole = distance.numerator//distance.denominator
        if d > _ss_Fraction():
            new = min(hi,lo+whole)
            changed += int(new<hi); model["upper"][j] = new
        else:
            new = max(lo,hi-whole)
            changed += int(new>lo); model["lower"][j] = new
    return changed


# test one conductor. Input: model, seconds per solver, optional pruning, MILP flag.
# Output: dict with status, witness/moments when available, and timing/diagnostics.
# plausible=checked integer solution; excluded_lp=positive rational phase-I certificate;
# excluded_milp=HiGHS numerical infeasibility; unresolved=no checked integer witness.
# No status means existence of a global L-function or of an abelian variety.
#
def solve_surface_conductor_model(model, time_limit=10.0, dual_pruning=False, integer_search=True):
    start = _ss_time.perf_counter()
    limit = float(time_limit)
    if not _ss_math.isfinite(limit) or limit <= 0:
        raise ValueError("time_limit must be positive and finite")
    out = {"conductor":model["conductor"],"status":"unresolved","witness":None,
           "moments":None,"lp_margin":None,"lp_certificate":None,"variables":0,
           "growth_from":model["prepared"]["growth_from"],"certificate_scope":"padded_binary64_model"}
    if "empty_prime" in model:
        out.update(status="excluded_local", reason="No compatible signature at p="+str(model["empty_prime"]))
        return out
    nv, na = len(model["lower"]), len(model["b"])
    out.update(variables=nv, constraints=len(model["b"])+len(model["h"])+len(model["e"]),
               block_modes={block["p"]:block["mode"] for block in model["blocks"]})
    # Phase I LP: minimize a common violation variable before attempting any integer solve.
    objective = _ss_np.zeros(nv+1); objective[-1]=1.0
    Aub = _ss_np.vstack((_ss_np.column_stack((model["A"],-_ss_np.ones(na))),
                         _ss_np.column_stack((model["H"],_ss_np.zeros(len(model["h"]))))))
    bub = _ss_np.r_[model["b"],model["h"]]
    E = _ss_np.column_stack((model["E"],_ss_np.zeros(len(model["e"]))))
    try:
        lp = _ss_linprog(objective,A_ub=Aub,b_ub=bub,A_eq=E if len(E) else None,
                         b_eq=model["e"] if len(E) else None,
                         bounds=list(zip(model["lower"],model["upper"]))+[(None,None)],
                         method="highs", options={"time_limit":limit})
    except Exception as exc:
        out.update(reason="LP error: "+str(exc), elapsed_seconds=_ss_time.perf_counter()-start)
        return out
    out["lp_solver_status"] = int(lp.status)
    if lp.status != 0:
        out.update(reason="LP not solved: "+str(lp.message), elapsed_seconds=_ss_time.perf_counter()-start)
        return out
    out["lp_margin"] = float(lp.fun)
    x = lp.x[:-1]
    out["relaxed_moments"] = surface_model_moments(model,x)
    certificate = _ss_phase_certificate(model,lp) if lp.fun > 0 or dual_pruning else None
    if certificate is not None:
        out["lp_certificate"] = {key:str(certificate[key]) for key in ("lower",)}
        out["lp_certificate"].update({key:[str(v) for v in certificate[key]] for key in ("alpha","mu","nu")})
    if certificate is not None and certificate["lower"] > _ss_Fraction():
        out.update(status="excluded_lp",reason="Positive exact phase-I lower bound for the finite model")
    else:
        # If the LP does not exclude N, first try a cheap rounded integer witness.
        candidate = _ss_rounded_vector(model,x)
        checked = check_surface_vector(model,candidate)
        out["domains_tightened"] = _ss_dual_tighten(model,certificate) if dual_pruning and certificate else 0
        # Only if rounding fails, ask the MILP solver for an integral feasible point.
        if not checked and integer_search:
            A = _ss_csc(_ss_np.vstack((model["A"],model["H"],model["E"])))
            lows = _ss_np.r_[_ss_np.full(na+len(model["h"]),-_ss_np.inf),model["e"]]
            highs = _ss_np.r_[model["b"],model["h"],model["e"]]
            try:
                mip = _ss_milp(_ss_np.zeros(nv),integrality=model["integer"],
                               bounds=_ss_Bounds(model["lower"],model["upper"]),
                               constraints=_ss_LinearConstraint(A,lows,highs),
                               options={"time_limit":limit,"mip_rel_gap":0.0})
                # Fixed-variable presolve can misclassify delicate floating models.
                # Recheck an infeasibility report without presolve; a limit is unresolved.
                out["milp_initial_status"] = int(mip.status)
                if mip.status == 2:
                    mip = _ss_milp(_ss_np.zeros(nv),integrality=model["integer"],
                                   bounds=_ss_Bounds(model["lower"],model["upper"]),
                                   constraints=_ss_LinearConstraint(A,lows,highs),
                                   options={"time_limit":limit,"mip_rel_gap":0.0,"presolve":False})
                    out["milp_presolve_recheck_status"] = int(mip.status)
                out["milp_solver_status"],out["milp_message"] = int(mip.status),str(mip.message)
                if mip.x is not None:
                    candidate = _ss_np.rint(mip.x)
                    checked = check_surface_vector(model,candidate)
                if not checked and mip.status == 2:
                    out.update(status="excluded_milp", reason="Numerical infeasibility reported by HiGHS; not a formal certificate")
                elif not checked:
                    out["reason"] = "No verified integer witness (limit, numerical issue, or fractional-only survival)"
            except Exception as exc:
                out["reason"] = "MILP error: "+str(exc)
        if checked:
            out.update(status="plausible", reason="One integer local selection passes every stored test",
                       witness=surface_model_witness(model,candidate),
                       moments=surface_model_moments(model,candidate), vector=[int(v) for v in candidate])
        elif not integer_search and out["status"] == "unresolved":
            out["reason"] = "LP survived; integer_search=False and rounding did not yield a verified witness"
    out["elapsed_seconds"] = _ss_time.perf_counter()-start
    return out
