#!/usr/bin/env python3
"""Reproduce the seven thesis figure series, with a consistent horizontal axis."""
from __future__ import annotations
import argparse
import math
from pathlib import Path

from murmurations import load_data, means, pool_fields


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('outputs/figures'))
    parser.add_argument('--axes', choices=['p', 'index'], nargs='+', default=['p'])
    parser.add_argument('--normalise', action='store_true', help='Divide all ordinate values by sqrt(p)')
    args = parser.parse_args()
    data = load_data()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plt.rcParams.update({'font.family':'serif', 'mathtext.fontset':'cm', 'font.size':11,
        'axes.titlesize':13, 'axes.spines.top':False, 'axes.spines.right':False,
        'legend.frameon':False, 'legend.fontsize':10, 'savefig.dpi':180})
    pooled = pool_fields(data['blocks'])
    q = {p:s/n for p,(s,n) in data['curves']['weighted'].items()}
    k = {p:v for p,(v,n) in data['comparisons']['weighted'].items()}
    selections = [
        ('01_courbes_Q_formes', 'Courbes et formes — tous corps quadratiques',
         [(r'Courbes sur $\mathbb{Q}$',q),('Formes nouvelles',means(pooled,signed=True))],
         r'pondérations $(-1)^r$ / $\varepsilon(f)$ · formes : $\mathrm{Tr}(a_p)/2$'),
        ('02_courbes_Q_Qsqrt5', 'Courbes elliptiques — moyenne signée par la parité',
         [(r'$\mathbb{Q}$',q),(r'$\mathbb{Q}(\sqrt{5})$',k)],
         'premiers décomposés · moyenne par place')]
    for filename, D in [('03_formes_tous_corps',0),('04_formes_Qsqrt5',5),
                        ('05_formes_Qsqrt2',8),('06_formes_Qsqrt3',12),('07_formes_Qsqrt73',73)]:
        block = pooled if not D else data['blocks'][D]
        field = 'tous corps quadratiques' if not D else rf'$K_f=\mathbb{{Q}}(\sqrt{{{data["fields"][D]["radicand"]}}})$'
        detail = r'données disponibles · coefficient $\mathrm{Tr}(a_p)/2$'
        if D == 73:
            detail = r'35 orbites seulement (17 de signe $+$, 18 de signe $-$)'
        selections.append((filename,'Formes nouvelles — '+field,
            [(r'$\varepsilon=+1$',means(block,sign=1)),(r'$\varepsilon=-1$',means(block,sign=-1))],detail))
    args.out.mkdir(parents=True,exist_ok=True)
    count=0
    for stem,title,series,detail in selections:
        primes=sorted(set.intersection(*(set(values) for label,values in series)))
        for axis in dict.fromkeys(args.axes):
            x=primes if axis=='p' else [data['indices'][p] for p in primes]
            fig,ax=plt.subplots(figsize=(8.8,4.7))
            for j,(label,values) in enumerate(series):
                y=[values[p]/(math.sqrt(p) if args.normalise else 1) for p in primes]
                ax.plot(x,y,linestyle='none',marker=('.', '+')[j%2],markersize=3,
                        markeredgewidth=.6,alpha=.75,label=label)
            ax.set_title(title,pad=34)
            ax.set_xlabel(r'Nombre premier $p$' if axis=='p' else r'Indice global $n=\pi(p)$')
            ax.set_ylabel('Coefficient moyen'+(r' / $\sqrt{p}$' if args.normalise else ''))
            ax.grid(axis='y',alpha=.16)
            ax.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncol=2,markerscale=2)
            fig.text(.5,.018,'Fenêtre 5000–10000 · '+detail,ha='center',fontsize=9)
            fig.tight_layout(rect=(0,.055,1,1))
            for extension in ('png','svg'):
                fig.savefig(args.out/f'{stem}_{axis}.{extension}')
            plt.close(fig)
            count+=1
    print(f'FIGURES_OK figures={count} formats=PNG,SVG output={args.out}')


if __name__=='__main__':
    main()
