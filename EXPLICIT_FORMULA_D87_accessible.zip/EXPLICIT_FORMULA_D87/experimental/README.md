# Experimental code

`mestre_abelian.py` is the larger independent local-factor search preserved from the earlier project.
It is kept separate because it is exploratory and has a different software structure from the short Sage modules.
The stable conductor-screen algorithms are in `sage/`.
