# Detailed guide

## 1. Design rule

A reviewer should be able to answer “what does this file do?” from its first paragraph, and “what does this function do?” from the comments immediately above its definition. Notebooks contain only explanations, loading, parameters and short computations; reusable algorithms live in `sage/`.

## 2. Basic Weil-approximation formula

`mestre_formula.sage` evaluates one fixed-lambda conductor lower bound. Unknown local Frobenius sums are replaced by the Weil worst-case estimates prime by prime and prime power by prime power while the test function is supported. The returned dictionary exposes the field degree/discriminant, root discriminant, lambda, archimedean term, total prime penalty, absolute conductor-norm bound and root-conductor bound.

`lambda_optimization.sage` contains the original staged heuristic: move forward by step 1 until the value stops increasing, backtrack and repeat with 0.1, then with 0.01. This is the production-style optimizer. The finite-grid routine is retained only as a diagnostic.

## 3. Many number fields

Notebook 03 calls `load_lmfdb_number_fields(DATA_FILE)`. The result is a Python list. Each list item is a dictionary describing one number field, normally by an LMFDB label plus a defining polynomial. `field_from_record` reconstructs the Sage field.

`compute_field_bounds` then evaluates one bound per record. Each completed field is immediately appended to a CSV. The row records the original label, polynomial, signature, field invariants, chosen lambda and both conductor normalizations. The CSV can therefore be plotted or filtered later without recomputing arithmetic.

## 4. Exact local factors and local-factor searches

`exact_curve_formula.sage` is the simple exact case: the local factors are supplied or computed from a known elliptic curve.

The `exact_formula_*` modules solve a different problem: generate a structural finite family of local factors and choose one common factor per prime across a finite lambda grid. The MILP makes the cross-lambda consistency explicit. Notebook 10 is the review entry point.

The convex relaxation in notebook 12 keeps the same finite local candidate family but replaces discrete one-of-K choices by simplex weights. This gives an LP lower value for the same finite model; a checked discrete selection gives an upper value.

## 5. Conductor-by-conductor surface screen

Notebook 13 fixes an integer conductor N and searches the complete local moment family represented by the surface model. At a good prime in dimension 2, the characteristic polynomial is

```text
X^4 - a X^3 + b X^2 - p a X + p^2.
```

The code uses the structural integral Weil region for `(a,b)`. If only the first moment is visible, all extendable traces are represented. If the first two moments are visible, all admissible `(a,b)` pairs are represented by trace selectors and one integer `b` variable. Higher moments are enumerated only for the few small primes where they are required. Across primes, the mixed-integer model represents the Cartesian product implicitly rather than looping through it.

The solver first solves a phase-I LP. A positive rationally rechecked dual lower bound excludes the stored finite model. If the LP does not exclude, a rounded integer witness is tried and then, when requested, a bounded MILP feasibility solve. The status fields distinguish checked survivors, LP exclusions, numerical MILP exclusions and unresolved cases.

## 6. What polynomial_rounds means

`polynomial_rounds` does not change the local Euler-factor family. It changes the set of explicit-formula inequalities.

One round is:

1. solve the complete local-choice model using all inequalities currently known;
2. take the surviving local moments;
3. optimize a polynomial-convolution test function for those fixed moments at the trial lambda values;
4. if the optimized test violates the conductor inequality, add that inequality to the whole model;
5. solve again, allowing the model to choose completely different local factors.

Thus `polynomial_rounds=4` means “add at most four optimized test-function cuts for this conductor.” It does not mean four candidate factors or four moment vectors.

## 7. Test-function optimization: theorem and numerical algorithm

Appendix A of the paper proves the continuity/density statement that motivates restricting the search to polynomial convolution kernels. In a finite even-polynomial basis, write the kernel coefficient vector as `v`. For fixed local moments and fixed lambda, linearity in the test function makes the explicit-formula expression a quadratic form `v^T A v`; normalization is `v^T Q v=1`.

The optimization is therefore a generalized Rayleigh quotient. The maximizing vector is an eigenvector for the largest generalized eigenvalue of

```text
A v = mu Q v.
```

The implementation calls `scipy.linalg.eigh((A+A.T)/2, Q)`. This is not a generic nonlinear optimizer. SciPy's documented default for a full generalized spectrum is LAPACK `gvd`; real double precision maps to `DSYGVD`, whose eigenvector path uses divide-and-conquer. The code records an eigen-residual and repeats the base quadrature at twice the order as numerical diagnostics.

## 8. External data and generated data

External number-field lists belong in `data/lmfdb/`. Small demonstration inputs belong in `data/examples/`. Research outputs belong in `outputs/`; reusable intermediates belong in `cache/`. The release ships no old result directories and no bulk database dump.

## 9. Assumptions and evidence levels

The mathematical assumptions are those of the corresponding formulas in the cited paper. The no-GRH notebook uses the separate modified test. Finite LP/MILP feasibility is not a global L-function existence statement. Numerical solver infeasibility is distinguished from rational finite-model LP certificates. The sampled growth condition, when enabled, is explicitly an additional sampled hypothesis and is not silently promoted to a theorem.

## 10. Validation

`VALIDATION.md` states which structural/Python tests were executed when this clean folder was built. Native Sage arithmetic must be rerun in a Sage environment; `00_quick_checks.ipynb` and `tests/smoke_test.sage` are provided for that purpose.
