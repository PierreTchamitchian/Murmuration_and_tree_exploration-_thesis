"""Exact truncated explicit formula when the local Euler factors are known.

Main use: evaluate a known elliptic curve over Q, or any supplied complete set of relevant local factors."""

from typing import Any, Callable
from sage.all import PolynomialRing, RealField, ZZ, exp, floor, log

CHARACTERISTIC_RING = PolynomialRing(ZZ, 'X')
X = CHARACTERISTIC_RING.gen()


# compute Newton power sums of the roots of a monic polynomial.
# Input: a monic polynomial and M >= 0.  Output: [s_0, ..., s_M].
#
def power_sums_of_roots(monic_polynomial, maximum_power: int):
    polynomial = CHARACTERISTIC_RING(monic_polynomial)
    if polynomial == 0 or polynomial.leading_coefficient() != 1:
        raise ValueError('the characteristic polynomial must be monic and nonzero')
    M = int(maximum_power)
    if M < 0:
        raise ValueError('maximum_power must be nonnegative')

    degree = int(polynomial.degree())
    if degree == 0:
        return [ZZ(0)] * (M + 1)

    coefficients = [polynomial[degree - j] for j in range(1, degree + 1)]
    sums = [ZZ(degree)]
    for m in range(1, M + 1):
        if m <= degree:
            value = sum(coefficients[j - 1] * sums[m - j] for j in range(1, m))
            value += m * coefficients[m - 1]
        else:
            value = sum(
                coefficients[j - 1] * sums[m - j]
                for j in range(1, degree + 1)
            )
        sums.append(-value)
    return sums


# compute the exact local prime-power sum, including the factor 2.
# Input: prime place, lambda, and Frobenius characteristic polynomial.
# Output: a Sage real.
#
def exact_local_prime_sum(
    prime_place: Any,
    lambda_value: Any,
    characteristic_polynomial,
    test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    lam = R(lambda_value)
    q = prime_norm(prime_place)
    if lam <= 0:
        raise ValueError('lambda_value must be positive')

    maximum_power = 0
    q_power = q
    while q_power <= exp(lam):
        maximum_power += 1
        q_power *= q
    root_sums = power_sums_of_roots(characteristic_polynomial, maximum_power)

    total = R(0)
    q_power = q
    for m in range(1, maximum_power + 1):
        argument = m * log(R(q)) / lam
        total += root_sums[m] * R(test_function(argument)) / q_power
        q_power *= q
    return 2 * log(R(q)) * total


# evaluate the exact truncated formula from supplied local factors.
# Input: list of (exact prime place, characteristic polynomial) pairs.
# Output: a conductor-bound dictionary.
#
def exact_conductor_bound(
    number_field: Any,
    lambda_value: Any,
    local_factors,
    dimension: int = 1,
    analytic_rank: int = 0,
    test_function: Callable = mestre_test_function,
    precision: int = 100,
    require_all_relevant_primes: bool = True,
):
    R = RealField(precision)
    lam = R(lambda_value)
    factors = list(local_factors)
    places = prime_places(number_field, floor(exp(lam)))

    if require_all_relevant_primes:
        missing = [P for P in places if not any(P == Q for Q, _ in factors)]
        if missing:
            raise ValueError('missing local factors for relevant prime places: %s' % missing)

    exact_sum = R(0)
    for place, polynomial in factors:
        if prime_norm(place) <= floor(exp(lam)):
            if CHARACTERISTIC_RING(polynomial).degree() > 2 * int(dimension):
                raise ValueError('a local factor has degree greater than 2*dimension')
            exact_sum += exact_local_prime_sum(
                place, lam, polynomial, test_function, precision
            )

    degree, discriminant = field_degree_and_discriminant(number_field)
    phi = phi_at_one_half(test_function, precision)
    archimedean = archimedean_term(lam, test_function, precision)
    log_absolute_bound = (
        lam * ZZ(analytic_rank) * phi
        + degree * ZZ(dimension) * archimedean
        + exact_sum
        - 2 * ZZ(dimension) * log(R(discriminant))
    )
    result = {
        'lambda': lam,
        'dimension': ZZ(dimension),
        'analytic_rank': ZZ(analytic_rank),
        'degree': degree,
        'discriminant': discriminant,
        'log_absolute_norm_bound': log_absolute_bound,
        'absolute_norm_bound': exp(log_absolute_bound),
        'root_conductor_bound': exp(log_absolute_bound / degree),
        'exact_prime_sum': exact_sum,
        'archimedean_term': archimedean,
    }
    return result


# evaluate the exact formula for one elliptic curve over Q.
# Input: a Sage elliptic curve, lambda, and analytic rank.  Output: result dict.
#
def exact_bound_for_elliptic_curve_Q(
    elliptic_curve,
    lambda_value: Any,
    analytic_rank: int = 0,
    test_function: Callable = mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    lam = R(lambda_value)
    conductor = ZZ(elliptic_curve.conductor())
    factors = []
    for p in prime_places(QQ, floor(exp(lam))):
        ap = ZZ(elliptic_curve.ap(p))
        if conductor % p == 0:
            polynomial = CHARACTERISTIC_RING(1) if ap == 0 else X - ap
        else:
            polynomial = X ** 2 - ap * X + p
        factors.append((p, polynomial))

    result = exact_conductor_bound(
        number_field=QQ,
        lambda_value=lam,
        local_factors=factors,
        dimension=1,
        analytic_rank=analytic_rank,
        test_function=test_function,
        precision=precision,
    )
    result['actual_conductor'] = conductor
    result['local_factors'] = factors
    return result
