"""Tests du nouvel exemple D87; les tests du projet d’origine restent séparés."""
from pathlib import Path
import sys,unittest,itertools,json,tempfile,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'sage'))
import d87_core as c
import d87_workflow as w
from d87_precision import verify_rejections

class D87Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model=w.prepare(.01)
        cls.early,cls.curves,cls.tree=w.early_branches(cls.model)
        cls.final,cls.certificate=w.run_stage(cls.model,math.log(41),60.)

    def test_01_arithmetic(self):
        self.assertEqual([i['norm'] for i in self.model['ideals']],
                         [3,3,5,8,19,23,25,29,29,31,37,41,41,41,43,53])

    def test_02_kernels(self):
        for k in ('O','G'):
            self.assertEqual(c.F(0,k),1)
            self.assertEqual(c.F(1,k),0)
            self.assertEqual(c.F(-1.5,k),0)
            self.assertAlmostEqual(c.F(.3,k),c.F(-.3,k))
        self.assertAlmostEqual(c.F(.5,'G'),1/12)

    def test_03_grid(self):
        grid=self.model['grid']
        self.assertEqual(len(grid),315)
        self.assertTrue(np.all(np.diff(grid)>0))
        self.assertEqual((grid[0],grid[-1]),(1,4))
        for x in [1.97,math.log(23),math.log(41),2*math.log(3),3*math.log(3)]:
            self.assertLess(np.min(abs(grid-x)),1e-12)

    def test_04_initial(self):
        rows=w.initial_branches()
        self.assertEqual(len(rows),441)
        self.assertEqual([(r['a_3_1'],r['a_3_2'],r['a_5']) for r in rows if r['survives']],[(-3,-3,-4)])

    def test_05_early(self):
        self.assertEqual(len(self.early),187)
        self.assertEqual(sum(r['passes_O'] for r in self.early),187)
        self.assertEqual(sum(r['status']=='passe' for r in self.early),51)
        self.assertEqual(sum(r['status']=='indecis' for r in self.early),0)
        self.assertTrue(all((r['a_8']>=3)==(r['status']=='passe') for r in self.early))

    def test_06_local_power_recurrence(self):
        q,a,t=3,-3,4.
        b=[2,a]
        for _ in range(2,4): b.append(a*b[-1]-q*b[-2])
        for kind in ('O','G'):
            expected=sum(2*math.log(q)*b[m]/q**m*c.F(m*math.log(q)/t,kind) for m in range(1,4))
            self.assertAlmostEqual(c.local(q,a,t,kind),expected,places=13)

    def test_07_random_counter_against_explicit_enumeration(self):
        groups=[(8,1),(29,2)]
        sizes,cums=c.weights(groups)
        points=list(itertools.product(range(-5,6),range(-20,21)))
        weights=[21-abs(s) for _,s in points]
        rng=np.random.default_rng(87)
        for _ in range(40):
            A=rng.integers(-3,4,(3,2)).astype(float)
            rhs=rng.integers(-20,21,3).astype(float)+.5
            good=sum(wgt for point,wgt in zip(points,weights) if np.all(A@point<rhs))
            result=c.count_boxes(A,rhs,sizes,cums,np.array([1.,2.]),seconds=10.)
            self.assertTrue(result['complete'])
            self.assertEqual(result['accepted'],good)
            self.assertEqual(result['borderline'],0)
            self.assertEqual(result['total'],11*21**2)

    def test_08_final(self):
        self.assertEqual(self.final['total'],18919991475)
        self.assertEqual(self.final['accepted'],0)
        self.assertEqual(self.final['borderline'],0)
        self.assertEqual(self.final['pending'],0)
        self.assertEqual(len(self.certificate['leaves']),34)

    def test_09_same_final_partition_as_archive(self):
        expected=json.loads((w.REFERENCE/'certificate_float.json').read_text())
        self.assertEqual(json.loads(json.dumps(self.certificate)),expected)

    def test_10_zero_example(self):
        self.assertGreater(np.min(self.model['log_Q']-self.model['base']['O']),0)
        change=3*c.arch(3.6,'G')+sum(c.local(q,a,3.6,'G') for q,a in zip(c.BASE_NORMS,c.BASE))
        change-=3*c.arch(3.5,'G')+sum(c.local(q,a,3.5,'G') for q,a in zip(c.BASE_NORMS,c.BASE))
        self.assertAlmostEqual(change,-0.0168293827775,places=10)

    def test_11_no_reference_overwrite(self):
        with self.assertRaises(ValueError): w.output_directory(w.REFERENCE,.01)

    def test_12_reject_bad_weights_before_quadrature(self):
        data=json.loads(json.dumps(self.certificate))
        data['leaves'][0]['weight']+=1
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'certificate_float.json').write_text(json.dumps(data))
            with self.assertRaises(ValueError): verify_rejections(p,p/'verification',40)

    def test_13_reject_wrong_grid_step(self):
        for step in [0,-.1,1,float('nan')]:
            with self.assertRaises(ValueError): w.prepare(step)

    def test_14_complete_multiplicities(self):
        sizes,cums=c.weights([(29,2)])
        self.assertEqual(c.weight(np.array([-20]),np.array([20]),sizes,cums),441)
        self.assertEqual(c.weight(np.array([0]),np.array([0]),sizes,cums),21)

if __name__=='__main__':
    unittest.main(verbosity=2)
