# External data

**Goal.** Make it obvious where every external input belongs.

## Number fields for notebook 03

Put trusted LMFDB **number-field Sage exports** in `data/lmfdb/`. The notebook contains one visible line:

```sage
DATA_FILE = PROJECT_ROOT / "data" / "lmfdb" / "lmfdb_number_fields_degree_05.sage"
```

The file must define `make_data()` and return a **Python list of dictionaries**. Each dictionary describes one field and must contain one of:

- `field`: an already constructed Sage number field;
- `poly`: a defining polynomial;
- `coeffs`: defining-polynomial coefficients in ascending powers.

An LMFDB export normally also contains `label`, `disc`, and other metadata. The calculation records the original `label` when it is present. If no label exists, the code uses `field_1`, `field_2`, ... only as a fallback name.

A tiny runnable example is `data/examples/number_fields_demo.sage`. It is only for checking the workflow.

## Generated files

- `data/` = inputs supplied before the computation;
- `outputs/` = CSV, JSON and figures created by notebooks;
- `cache/` = reusable intermediate data.

Only load Sage exports from a trusted source because a `.sage` file is executable code.
