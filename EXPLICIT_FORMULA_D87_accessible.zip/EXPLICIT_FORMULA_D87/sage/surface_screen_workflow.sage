"""Small public workflow: screen an integer interval and retain reproducible witnesses.
No existing project filenames are overwritten. Each mathematical configuration
and source fingerprint has its own output subdirectory, with one JSON per conductor.
"""
import json as _ss_json
import sys as _ss_sys
import scipy as _ss_scipy
import hashlib as _ss_hashlib
from pathlib import Path as _ss_Path


# test one integer conductor, optionally separating polynomial tests.
# Input: N, prepared dict or None, solver seconds, booleans, number of extra-test rounds,
# even polynomial degree and a short optional lambda list. Output: result dict.
# Each newly optimized test is imposed on ALL local choices before a conductor is excluded.
# A violated test for a single witness never by itself excludes that conductor.
#
def screen_surface_conductor(conductor, prepared=None, time_limit=10.0, dual_pruning=False,
                             integer_search=True, polynomial_rounds=0, polynomial_degree=4,
                             polynomial_lambdas=None):
    prepared = prepare_surface_screen() if prepared is None else prepared
    n, rounds = _ss_int(conductor), _ss_int(polynomial_rounds)
    if rounds < 0:
        raise ValueError("polynomial_rounds must be nonnegative")
    trial_grid = ([min(v,prepared["lambda_max"]) for v in (1.3,1.6,2.0,2.5,3.0)]
                  if polynomial_lambdas is None else [float(v) for v in polynomial_lambdas])
    trial_grid = sorted(set(trial_grid))
    if not trial_grid or any(not _ss_math.isfinite(v) or v<=0 or v>prepared["lambda_max"]+1e-12 for v in trial_grid):
        raise ValueError("Polynomial-test lambdas must be positive and within prepared support")
    extra, history, start = [], [], _ss_time.perf_counter()
    # One iteration = solve the complete local-choice model with all cuts found so far.
    for iteration in range(rounds+1):
        model = build_surface_conductor_model(n,prepared,extra)
        result = solve_surface_conductor_model(model,time_limit,dual_pruning,integer_search)
        history.append({"iteration":iteration,"status":result["status"],"lp_margin":result["lp_margin"]})
        if result["status"].startswith("excluded") or iteration == rounds:
            break
        moments = result["moments"] or result.get("relaxed_moments")
        if moments is None:
            break
        # Hold the surviving moments fixed and optimize a new test function at trial lambdas.
        candidates = [optimize_surface_polynomial_test(moments,lam,prepared["dimension"],
                       prepared["analytic_rank"],polynomial_degree) for lam in trial_grid]
        optimized = max(candidates,key=lambda item:item["log_bound"])
        history[-1]["separation_log_bound"] = optimized["log_bound"]
        history[-1]["separation_lambda"] = optimized["lambda_value"]
        if optimized["log_bound"] <= _ss_math.log(n)+max(1e-7,10*prepared["numerical_slack"]):
            result["polynomial_separation"] = "No violated test found in this basis at the trial lambdas"
            break
        # Add the violated inequality to the WHOLE model; the next solve may choose different local factors.
        extra.append({"lambda_value":optimized["lambda_value"],"test":optimized["test"]})
    result.update(extra_tests=extra, refinement_history=history,
                  polynomial_round_limit_reached=bool(rounds and len(extra)==rounds),
                  total_seconds=_ss_time.perf_counter()-start,
                  numerical_slack=prepared["numerical_slack"],
                  scope="Necessary finite tests for formal Euler data over Q, not global existence")
    return result


# serialize numerical outputs. Input: nested arrays/numbers. Output: JSON-compatible object.
#
def _ss_json_ready(value):
    if isinstance(value,dict):
        return {str(k):_ss_json_ready(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):
        return [_ss_json_ready(v) for v in value]
    if isinstance(value,_ss_np.ndarray):
        return value.tolist()
    if isinstance(value,_ss_np.generic):
        return value.item()
    return value


# atomic result save. Input: Path, nested data. Output: None.
#
def _ss_write_json(path, data):
    path = _ss_Path(path)
    temporary = path.with_suffix(path.suffix+".tmp")
    temporary.write_text(_ss_json.dumps(_ss_json_ready(data),indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")
    temporary.replace(path)


# return plausible integer conductors in an inclusive interval.
# Input: endpoints, coarse lambda list, g/r, growth threshold (None disables), optional
# runtime/output controls.
# Output: dict containing plausible_conductors, excluded_conductors, unresolved_conductors,
# not_excluded_conductors, results[N] and run_directory. Saves/reuses one result per N when
# requested.
# A time limit is NEVER reported as an exclusion. Resume retries unresolved runs.
#
def scan_surface_conductors(conductor_min=105, conductor_max=121, lambda_values=None,
                            dimension=2, analytic_rank=0, growth_from=1.0,
                            time_limit=10.0, polynomial_rounds=0, polynomial_degree=4,
                            output_directory=None, resume=True, dual_pruning=False,
                            integer_search=True, semistable_exact=True, numerical_slack=1e-8):
    lo,hi = _ss_int(conductor_min),_ss_int(conductor_max)
    if not 1 <= lo <= hi:
        raise ValueError("Require 1<=conductor_min<=conductor_max")
    prepared = prepare_surface_screen(lambda_values,dimension,analytic_rank,growth_from,
               numerical_slack=numerical_slack,semistable_exact=semistable_exact)
    configuration = {k:prepared[k] for k in ("dimension","analytic_rank","lambda_values","growth_from",
                     "tests","numerical_slack","semistable_exact")}
    configuration.update(polynomial_rounds=int(polynomial_rounds),polynomial_degree=int(polynomial_degree),
                         dual_pruning=bool(dual_pruning),integer_search=bool(integer_search),
                         source_sha256=globals().get("_SS_SOURCE_HASH","direct_source_execution"),
                         numerical_engine={"python":_ss_sys.version.split()[0],
                                           "numpy":_ss_np.__version__,"scipy":_ss_scipy.__version__})
    fingerprint = _ss_hashlib.sha256(_ss_json.dumps(configuration,sort_keys=True).encode()).hexdigest()[:16]
    run_dir = None
    if output_directory is not None:
        run_dir = _ss_Path(output_directory).expanduser()/('surface_screen_'+fingerprint)
        run_dir.mkdir(parents=True,exist_ok=True)
        _ss_write_json(run_dir/'configuration.json',configuration)
    results = {}
    for n in range(lo,hi+1):
        path = None if run_dir is None else run_dir/('conductor_'+str(n)+'.json')
        result = _ss_json.loads(path.read_text(encoding="utf-8")) if resume and path is not None and path.exists() else None
        if result is None or result["status"] == "unresolved":
            result = screen_surface_conductor(n,prepared,time_limit,dual_pruning,integer_search,
                                               polynomial_rounds,polynomial_degree)
            if path is not None:
                _ss_write_json(path,result)
        # Keep the public output types identical on fresh runs and JSON reloads.
        result = _ss_json_ready(result)
        for key in ("moments","relaxed_moments","witness","block_modes"):
            if result.get(key) is not None:
                result[key] = {int(p):v for p,v in result[key].items()}
        results[n] = result
    summary = {"plausible_conductors":[n for n,r in results.items() if r["status"]=="plausible"],
               "excluded_conductors":[n for n,r in results.items() if r["status"].startswith("excluded")],
               "unresolved_conductors":[n for n,r in results.items() if r["status"]=="unresolved"],
               "finite_model_certified_exclusions":[n for n,r in results.items() if r["status"] in ("excluded_lp","excluded_local")],
               "numerical_milp_exclusions":[n for n,r in results.items() if r["status"]=="excluded_milp"],
               "not_excluded_conductors":[n for n,r in results.items() if not r["status"].startswith("excluded")],
               "run_directory":None if run_dir is None else str(run_dir.resolve()),
               "configuration":configuration,"results":results}
    if run_dir is not None:
        _ss_write_json(run_dir/('summary_'+str(lo)+'_'+str(hi)+'.json'),summary)
    return summary
