"""Compact mixed-integer model for a specified conductor.
A*x<=b contains analytic tests, H*x<=h and E*x=e contain exact local structure.
Each moment is an integer linear form in x. No epigraph/conductor variable is used.
"""


# model plausible Euler data of exactly N. Input: integer N, prepared dict, optional test rows.
# Output: dict of matrices, local blocks and variable bounds for LP/MILP use.
# Extra tests are dictionaries {'lambda_value':real,'test':test_dict_or_name}.
#
def build_surface_conductor_model(conductor, prepared, extra_tests=()):
    n = _ss_int(conductor, "conductor")
    factors = surface_conductor_factorization(n)
    g, cap = prepared["dimension"], prepared["powers"]
    lower, upper, integer, blocks = [], [], [], []
    eq_rows, eq_rhs, structural_rows, structural_rhs = [], [], [], []
    forms = {p:[{} for _ in range(cap[p])] for p in prepared["primes"]}

    # append one variable. Input: bounds and integrality. Output: column index.
    #
    def variable(lo, hi, integral=True):
        j = len(lower)
        lower.append(float(lo)); upper.append(float(hi)); integer.append(int(integral))
        return j

    # select one trace/profile. Input: number of choices. Output: column indices.
    #
    def selectors(number):
        ix = [variable(0,1) for _ in range(number)]
        eq_rows.append({j:1.0 for j in ix}); eq_rhs.append(1.0)
        return ix

    # Build one exact local block for every prime that is analytically visible or divides N.
    for p in sorted(set(prepared["primes"]) | set(factors)):
        m, e = cap.get(p,0), factors.get(p,0)
        domain = surface_local_domain(p, g, m, e, prepared["semistable_exact"], prepared["compact"])
        mode = domain["mode"]
        if mode == "empty":
            return {"empty_prime":p, "conductor":n, "prepared":prepared}
        block = {"p":p, "mode":mode, "max_power":m, "exponent":e, "domain":domain}
        if mode == "unseen":
            blocks.append(block); continue
        if mode == "trace" and domain["values"] == tuple(range(domain["values"][0],domain["values"][-1]+1)):
            j = variable(domain["values"][0], domain["values"][-1])
            forms[p][0][j] = 1.0
            block["columns"] = [j]
        elif mode == "trace_second":
            traces, intervals = domain["values"], domain["b_intervals"]
            ix = selectors(len(traces))
            bcol = variable(min(lo for lo,hi in intervals), max(hi for lo,hi in intervals))
            # sum b_min(a)*delta_a <= b <= sum b_max(a)*delta_a.
            structural_rows.extend([{**{j:float(lo) for j,(lo,hi) in zip(ix,intervals)}, bcol:-1.0},
                                    {**{j:-float(hi) for j,(lo,hi) in zip(ix,intervals)}, bcol:1.0}])
            structural_rhs.extend([0.0,0.0])
            forms[p][0] = {j:float(a) for j,a in zip(ix,traces)}
            forms[p][1] = {**{j:float(a*a) for j,a in zip(ix,traces)}, bcol:-2.0}
            block["columns"], block["b_column"] = ix, bcol
        else:
            profiles = domain["witnesses"] if mode == "trace" else domain["profiles"]
            ix = selectors(len(profiles))
            for power in range(m):
                forms[p][power] = {j:float(profile["sums"][power]) for j,profile in zip(ix,profiles)}
            block["mode"], block["columns"], block["choices"] = "profiles", ix, profiles
        blocks.append(block)

    nv = len(lower)
    # assemble sparse row dictionaries. Input: rows. Output: dense float matrix.
    #
    def dense(rows):
        M = _ss_np.zeros((len(rows),nv),dtype=float)
        for i,row in enumerate(rows):
            for j,c in row.items():
                M[i,j] = c
        return M

    # substitute moment linear forms. Input: analytic row. Output: coefficient vector.
    #
    def moment_row(row):
        vector = _ss_np.zeros(nv,dtype=float)
        for p, weights in row["weights"].items():
            for w, form in zip(weights,forms[p]):
                for j,c in form.items():
                    vector[j] += w*c
        return vector

    # Convert each explicit-formula inequality into one linear row in the moment variables.
    row_specs = list(prepared["bound_rows"])
    for item in extra_tests:
        row_specs.append(_ss_analytic_row(prepared,float(item["lambda_value"]),item["test"]))
    tolerance = prepared["numerical_slack"]
    A = [moment_row(row) for row in row_specs]
    b = [_ss_math.log(n)-row["offset"]+tolerance for row in row_specs]
    names = ["bound:"+str(row["lambda"]) for row in row_specs]
    for row in prepared["growth_rows"]:
        A.append(-moment_row(row)); b.append(row["offset"]+tolerance)
        names.append("growth:"+str(row["lambda_pair"]))
    return {"conductor":n,"factorization":factors,"prepared":prepared,"blocks":blocks,"forms":forms,
            "A":_ss_np.asarray(A,dtype=float).reshape((len(A),nv)), "b":_ss_np.asarray(b,dtype=float),
            "H":dense(structural_rows),"h":_ss_np.asarray(structural_rhs,dtype=float),
            "E":dense(eq_rows),"e":_ss_np.asarray(eq_rhs,dtype=float),
            "lower":_ss_np.asarray(lower,dtype=float),"upper":_ss_np.asarray(upper,dtype=float),
            "integer":_ss_np.asarray(integer,dtype=int),"row_names":names,
            "extra_tests":list(extra_tests)}


# decode local Newton sums. Input: model dict, real vector. Output: dict[p,tuple[float]].
#
def surface_model_moments(model, vector):
    x = _ss_np.asarray(vector,dtype=float)
    return {p:tuple(float(sum(c*x[j] for j,c in row.items())) for row in rows)
            for p,rows in model["forms"].items()}


# reconstruct discrete local factors. Input: model, integral feasible vector. Output:
# dict[p,record].
# At m=1 an arbitrary Weil completion is reported; it is not uniquely determined by the
# optimization.
#
def surface_model_witness(model, vector):
    x = _ss_np.rint(_ss_np.asarray(vector,dtype=float)).astype(int)
    factors = {}
    for block in model["blocks"]:
        p, mode, domain = block["p"],block["mode"],block["domain"]
        if mode == "unseen":
            profile = domain["witness"]
        elif mode == "trace":
            trace = int(x[block["columns"][0]])
            profile = domain["witnesses"][domain["values"].index(trace)]
        elif mode == "trace_second":
            index = int(_ss_np.argmax(x[block["columns"]]))
            trace, second = domain["values"][index], int(x[block["b_column"]])
            profile = _ss_profile(_ss_good_coefficients(p,2,trace,second),(2,0,0),2)
        else:
            profile = block["choices"][int(_ss_np.argmax(x[block["columns"]]))]
        factors[p] = {"signature":profile["signature"], "conductor_exponent":block["exponent"],
                      "minimum_exponent":profile["minimum_exponent"],
                      "euler_coefficients":profile["characteristic_coefficients"],
                      "observed_moments":profile["sums"], "mode":mode,
                      "completion_is_arbitrary":mode in ("trace","unseen")}
    return factors


# one cheap LP rounding attempt. Input: model, real vector. Output: integer vector, not yet checked.
#
def _ss_rounded_vector(model, vector):
    x = _ss_np.clip(_ss_np.rint(vector),model["lower"],model["upper"])
    for block in model["blocks"]:
        if block["mode"] in ("profiles","trace_second"):
            ix = block["columns"]
            k = int(_ss_np.argmax(_ss_np.asarray(vector)[ix]))
            x[ix] = 0.0; x[ix[k]] = 1.0
            if block["mode"] == "trace_second":
                lo,hi = block["domain"]["b_intervals"][k]
                x[block["b_column"]] = _ss_np.clip(x[block["b_column"]],lo,hi)
    return x
