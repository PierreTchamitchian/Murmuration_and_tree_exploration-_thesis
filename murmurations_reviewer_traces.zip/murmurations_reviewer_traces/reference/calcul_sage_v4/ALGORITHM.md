# Complément v4 : projection exacte des coefficients

Le crible et la décomposition Sage ci-dessous sont inchangés depuis v3. Seul le
chemin des coefficients quadratiques et l'organisation de leurs sauvegardes sont
modifiés. Le mode de ligne de commande par défaut est désormais `projected`.

Les définitions de `projection.py` sont copiées textuellement du benchmark validé
sur le serveur (SHA256 dans `reference/projection_provenance.json`). Pour chaque
orbite, on normalise une forme propre duale et on préprojette la matrice de
réduction des symboles dans deux colonnes rationnelles. Les orbites ayant une
coordonnée non nulle commune partagent l'évaluation des images de Hecke. C'est
l'identité `(u_p R)V = u_p(RV)`, sur des nombres rationnels exacts, sans approximation.
Les polynômes enregistrés restent des polynômes caractéristiques (trace/norme sur
le corps entier), pas seulement des polynômes minimaux. Le contrôle de T_1 vérifie
la normalisation. Le routage creux/dense de Sage 10.9 pour le seuil 30 est conservé.

Chaque niveau vérifie les premiers coefficients par les matrices restreintes,
et le plus grand premier ainsi que les premiers divisant le niveau par l'ancien
chemin `eigenvalue`. Une divergence interrompt le niveau ; elle n'est jamais
assimilée à l'absence d'une forme. Il ne s'agit pas de refaire une décomposition
ou de vérifier 2 000 grandes matrices.

Les sauvegardes groupées se font tous les 100 indices premiers par défaut. Un
préfixe importé de v3 est **entièrement comparé** au calcul projeté. Lors d'une
reprise ultérieure v4, on contrôle des entrées initiales, médianes et finales,
puis on saute le préfixe commun enregistré ; les recouvrements entre préfixes de
longueurs différentes sont également comparés. Les espaces et les corps sont
reconstruits et les clés de composantes doivent recouvrir les données sauvegardées.

Les détails suivants, hérités de v3, décrivent le calcul des espaces et le crible.

---

> **Correctif Sage 10.9** : la décomposition est appelée avec `proof=None`,
> après `proof.linear_algebra(True)` ; voir `FIX_SAGE109.md`.

# Algorithme mathématique et garanties

## 1. Espace de calcul

Pour chaque niveau N, on construit avec Sage :

```python
M = ModularSymbols(Gamma0(N), 2, sign=1)
V = M.cuspidal_subspace().new_subspace()
```

Dans ce cadre classique de poids 2 et caractère trivial, une orbite de formes nouvelles dont le corps des coefficients est F correspond à un constituant rationnel de dimension [F:Q] dans l'espace de signe + des symboles modulaires. Le `sign=1` des symboles modulaires ne sélectionne PAS le signe + de l'équation fonctionnelle : les deux signes fonctionnels sont conservés et calculés séparément. [S1, S2]

Deux sélections sont possibles. En mode `--all-quadratic`, la cible est **[F:Q] = 2**, sans imposer le corps F : d = 2 et le test de corps dans le crible est désactivé. En mode `--poly`, d = [K:Q] et la cible reste **F isomorphe à K**, et pas simplement l'égalité des degrés ou des discriminants en degré supérieur à 2. Les corps sont des corps de coefficients, pas des corps de base de formes de Hilbert. Dans le cadre du caractère trivial, ils sont totalement réels.

## 2. Le crible du notebook, effectivement avant la décomposition

La fonction `hecke_sieve` reprend `select_factors`, `decomposition_space` et `complete_decomposition` du notebook fourni. Le calcul initial n'appelle pas `V.decomposition()`.

Sur un bloc U, et pour un petit premier p ne divisant pas N, on factorise exactement :

    charpoly(T_p | U) = produit f_i(X)^(m_i).

On conserve un facteur seulement si son degré e_i divise d et si la dimension e_i m_i de son bloc primaire est au moins d. Le bloc conservé est le noyau de f_i(T_p)^(m_i). Quand ce facteur primaire est le polynôme caractéristique entier, on réutilise directement U, sans recalculer un noyau égal à U.

La multiplicité n'est jamais transformée en « une seule copie ». En particulier, un facteur linéaire répété peut contenir une orbite quadratique, cubique, etc. Les dimensions des noyaux et la comptabilité totale des dimensions conservées/écartées sont contrôlées.

Uniquement en mode `--poly`, si e_i = d, le corps Q[X]/(f_i) doit être isomorphe à K. On peut alors écarter un mauvais corps AVANT de construire son noyau, même si son bloc primaire a dimension supérieure à d. Pour d = 2, on compare exactement la classe modulo les carrés des discriminants des polynômes ; pour d > 2, on utilise `NumberField(...).is_isomorphic(K)`. Un échec de l'API n'est jamais interprété comme une réponse négative. [S3]

Par défaut, on utilise **au plus 12 premiers ne divisant pas N**, et non les trois premiers seulement. Le paramètre est `--sieve-primes`. Un bloc de dimension d est envoyé directement à l'étape suivante : continuer à le cribler n'est pas nécessaire. Un bloc de dimension supérieure à d resté indécomposé après le budget n'est **jamais** supprimé pour cette raison.

## 3. Pourquoi ce crible ne perd pas d'orbite cible

Voici la justification des éliminations, indépendante de toute hypothèse sur la rapidité de séparation.

Sur une orbite cible, T_p agit comme la multiplication par a_p dans F, où [F:Q] = d (et, uniquement en mode prescrit, F est isomorphe à K). Si f est le polynôme minimal de a_p et e = [Q(a_p):Q], la formule des degrés donne e divisant d. Le polynôme caractéristique sur cette orbite est f^(d/e).

Par conséquent :

* le facteur f satisfait toujours le test e divisant d ;
* le bloc primaire qui contient l'orbite a dimension au moins d ;
* si e = d, alors Q(a_p) = F ; en mode prescrit le test de corps ne peut pas l'écarter, et en mode tous quadratiques ce test est absent ;
* les opérateurs de Hecke commutent, donc les blocs primaires successifs restent stables et l'orbite entière survit à chaque étape.

Ces observations prouvent l'invariant du crible : **toute orbite cible appartient à un des blocs conservés**. Le pari heuristique est que quelques petits premiers réduisent fortement ces blocs. L'exhaustivité ne repose pas sur ce pari, puisque les gros blocs restants passent à la décomposition suivante.

Ce raisonnement ne dit pas qu'un facteur quadratique isolé dans un bloc de dimension 4 prouve l'existence d'une forme quadratique : une forme à corps quartique peut avoir un coefficient quadratique. D'où la nécessité de l'étape suivante.

## 4. Décomposition complète des survivants par Sage

Pour chaque bloc U restant, le moteur appelle :

```python
U.decomposition(bound=None, anemic=False, sort_by_basis=True, proof=None)
```

`bound=None` conserve la borne complète prévue par Sage ; il n'est pas remplacé par le budget du crible. `anemic=False` utilise l'algèbre de Hecke complète, pas uniquement les indices premiers au niveau. La documentation décrit l'utilisation de la borne de Sturm lorsque aucune borne explicite n'est fournie. Le réglage global `proof.linear_algebra(True)` active les preuves ; `proof=None` est passé explicitement pour hériter de ce réglage sans déclencher le défaut de Sage 10.9 concernant les noyaux rationnels. [S1]

Les dimensions de la décomposition doivent se sommer à celle du bloc. Seuls les constituants finaux de dimension d sont candidats au test de corps. Pour ceux-ci, `is_simple()` doit réussir. Une exception ou un constituant inattendu donne une erreur de niveau, pas un succès incomplet.

Cela reste une garantie reposant sur la correction des algorithmes exacts de Sage et sur leur exécution effective. Ce paquet n'est pas une preuve formelle indépendante du logiciel, et n'apporte aucune garantie de temps ou de mémoire.

## 5. Identification du corps sans limite artificielle de petits générateurs

On demande `space.eigenvalue(1, name="a")` et on prend son corps parent. Bien que a_1 soit l'élément 1, son parent est ici le corps complet utilisé par Sage pour le système de valeurs propres. L'algorithme de vecteur propre dual de Sage cherche un opérateur de polynôme caractéristique irréductible, en autorisant des **combinaisons** d'opérateurs de Hecke. [S1]

Il n'est donc plus imposé qu'un seul des 40 ou 60 premiers a_p engendre le corps. On vérifie que le degré du corps retourné est d. En mode tous quadratiques, toute composante simple de degré 2 est retenue ; en mode prescrit, on vérifie en plus l'isomorphisme avec K. Un corps différent est une exclusion définitive, pas un `unresolved`. Cette construction exacte peut être coûteuse et comporte de l'aléa interne ; il n'y a pas de promesse de temps de terminaison uniforme.

### Classement exact des corps quadratiques

Pour chaque F de degré 2, on calcule `D = F.discriminant()`, le discriminant de son anneau des entiers, et non le discriminant du polynôme d'un a_p. Un discriminant fondamental positif détermine un corps quadratique réel à isomorphisme près. On enregistre `D<discriminant>`, le radicand sans carré m et un modèle canonique :

- si D = 1 modulo 4 : m = D, polynôme X² - X + (1-D)/4 ;
- sinon : m = D/4, polynôme X² - m.

Un discriminant négatif ou non fondamental est une erreur, pas un corps silencieusement écarté. Deux modèles de F différents ne séparent pas artificiellement un même corps dans les exports. Ainsi X²-5 (discriminant polynomial 20) et X²-X-1 (discriminant polynomial 5) donnent tous deux l'identifiant D5. [S3]

## 6. Coefficients et signe

Pour chacune des orbites retenues, la grille enregistrée est p_1 = 2, ..., p_2000 = 17 389. Elle comprend les premiers divisant N ; l'exclusion éventuelle de ceux-ci appartient à l'agrégation, avec un dénominateur variable.

Par défaut, on utilise `space.eigenvalue(p, name="a")`, l'API de Sage pour calculer les coefficients d'une forme propre. Cette API exploite notamment une action creuse sur un symbole pour un indice premier, plutôt que de demander explicitement toute la matrice T_p à chaque coefficient. Des matrices ambiantes peuvent néanmoins être calculées pour construire le corps ou le vecteur propre. Le mode `--coefficient-method matrices` fournit le contrôle direct par les polynômes caractéristiques des matrices. [S1, S2]

Si h_p est le polynôme minimal de a_p, de degré e_p, on enregistre

    C_p(X) = h_p(X)^(d/e_p) = Norme_{F/Q}(X - a_p).

Ses coefficients sont des entiers, vérifiés par coercition exacte dans ZZ. Les traces et normes sont déduites de C_p. En degré 2, C_p = X² - Tr(a_p) X + Nm(a_p). Si a_p = 3 est rationnel, on enregistre X² - 6X + 9, pas X - 3. Les données historiques fournies comportent des polynômes de degré 1 ; la fixture du niveau 23 restaure cette multiplicité avant comparaison.

Les polynômes sont stockés avec leurs coefficients par puissances croissantes, coefficient dominant compris : `[Nm, -Tr, 1]` en degré 2. On conserve aussi explicitement les tableaux `traces` et `norms`. On ne stocke pas un choix de plongement de F dans un modèle de K.

On calcule W_N sur le constituant, on vérifie que sa matrice est scalaire de valeur +1 ou -1, puis on enregistre le signe fonctionnel epsilon = -W_N en poids 2, comme dans le notebook fourni. Cette convention est contrôlée aux niveaux 11 et 23.

Le nombre de 2 000 désigne les données enregistrées par orbite. La construction des espaces, le crible, la décomposition complète et le choix du corps peuvent nécessiter d'autres calculs de Hecke internes.

## 7. Reprise et statut de complétude

Un niveau reçoit `complete: true` seulement après tous les tests de corps et le calcul de tous les coefficients de ses orbites retenues. Toute exception produit un fichier d'erreur. Les écritures sont atomiques. Des préfixes sont sauvegardés tous les 100 coefficients ; à la reprise, on reconstruit les sous-espaces, on les identifie par leur matrice rationnelle échelonnée, et on vérifie le début du préfixe avant de poursuivre.

La version du code, celle de Sage, le mode de sélection (et K le cas échéant), et la grille de premiers sont inscrits dans la configuration et son empreinte. Les fichiers de la version précédente ou d'autres réglages ne sont pas silencieusement réutilisés. L'export de moyennes refuse par défaut les niveaux manquants ou en erreur.

Références : `REFERENCES.md`. Validation effectivement exécutée : `VALIDATION.md`.


## 8. Export et niveau maximum

La borne par défaut est N_max = 20 000, inclusive, et elle peut être augmentée sans changer la sélection mathématique. Il n'y a aucune assertion de temps ou de mémoire disponible à ces niveaux. Les processus parallèles sont indépendants par niveau ; une décomposition interne à un niveau n'est pas elle-même répartie sur 40 processus par ce paquet.

Les fichiers par niveau distinguent déjà les corps. `group_by_field.py` réorganise leurs enregistrements par discriminant et publie le dossier seulement après validation. Un niveau absent/en erreur bloque l'export par défaut. `aggregate.py` calcule séparément les sommes par corps, signe et premier, jamais une moyenne confondant les différents corps.

Les résultats d'une recherche prescrite ne permettent pas de conclure à l'absence d'autres corps dans le même niveau. Les fichiers v2 ne sont donc pas marqués complets ou importés automatiquement dans une campagne v3 tous quadratiques.
