# Tiny self-contained input with the same make_data() interface expected by notebook 03.
# Coefficients are in ascending powers of x.

def make_data():
    return [
        {"label": "demo_Qsqrt5", "coeffs": [-5, 0, 1]},
        {"label": "demo_cuberoot2", "coeffs": [-2, 0, 0, 1]},
        {"label": "demo_cyclotomic5", "coeffs": [1, 1, 1, 1, 1]},
    ]
