#!/usr/bin/env python3
"""D=-87: exploration entiere, Odlyzko et croissance G2 jusqu'a lambda=4.

Pas de LP/MILP. Les intervalles entiers sont subdivises ou rejetes en bloc
par des bornes additives. Les signes sont numeriques, non certifies par
arithmetique d'intervalles. La croissance est un critere SUPPLEMENTAIRE.
"""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ.setdefault(key, '1')
import argparse
import csv
import itertools
import json
import math
import time
import warnings
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.integrate import quad

D, DEGREE = 87, 3
INITIAL = 1.97
BASE_NORMS = (3, 3, 5)
BASE = (-3, -3, -4)
EPS = 1e-10                 # Marge numerique, pas un taux de convergence.


# Écrire un dictionnaire de résultats en JSON UTF-8.
def save_json(path: Path, obj: dict) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf8')


# Écrire une liste de lignes dans un CSV; aucune conversion des grands entiers en flottants.
def save_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open('w', newline='', encoding='utf8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


# Évaluer le noyau compact Odlyzko (O) ou le noyau G2 (G) du calcul archivé.
def F(u: float, kind: str) -> float:
    u = abs(u)
    if u >= 1:
        return 0.0
    if kind == 'O':
        return (1-u)*math.cos(math.pi*u)+math.sin(math.pi*u)/math.pi
    if u >= .5:
        return (8/3)*(1-u)**5
    return 1+u*u*(-40/3+u*(80/3+u*(-40/3-8*u/3)))


# Calculer le terme archimédien M(lambda,F) par la même quadrature que dans l’archive.
@lru_cache(None)
def arch(lam: float, kind: str) -> float:
    def integrand(t):
        return 0.0 if t == 0 else (F(t/lam, kind)-1)/math.expm1(t)
    value, _ = quad(integrand, 0, lam, points=[lam/2],
                    epsabs=2e-13, epsrel=2e-13, limit=160)
    return 2*(math.log(2*math.pi)+float(np.euler_gamma)+value
              +math.log1p(-math.exp(-lam)))


# Calculer toutes les puissances locales visibles à partir de b0=2, b1=a, bm=a*b(m-1)-q*b(m-2).
@lru_cache(None)
def local(q: int, a: int, lam: float, kind: str) -> float:
    result, b0, b1 = 0.0, 2, a
    for m in range(1, int(math.floor((lam+1e-13)/math.log(q)))+1):
        if m > 1:
            b0, b1 = b1, a*b1-q*b0
        result += 2*math.log(q)*b1/q**m * F(m*math.log(q)/lam, kind)
    return result


# Vérifier le corps D=-87 et la liste des idéaux jusqu’à exp(4); aucune base externe requise.
def verify_field() -> list[dict]:
    import sympy as sp
    from sympy.polys.numberfields import round_two
    x = sp.Symbol('x')
    f = sp.Poly(x**3-x**2+2*x+1, x)
    if not f.is_irreducible or int(f.discriminant()) != -D or int(round_two(f)[1]) != -D:
        raise RuntimeError('Discriminant, irreductibilite ou indice inattendu.')
    ideals = []
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for p in sp.primerange(2, math.floor(math.exp(4))+1):
            for g, e in sp.factor_list(f, modulus=p)[1]:
                q = int(p**g.degree())
                if q <= math.exp(4):
                    ideals.append(dict(norm=q, p=int(p), f=int(g.degree()),
                                       e=int(e), factor=str(g.as_expr())))
    ideals.sort(key=lambda i:(i['norm'],i['factor']))
    expected = [3,3,5,8,19,23,25,29,29,31,37,41,41,41,43,53]
    if [i['norm'] for i in ideals] != expected:
        raise RuntimeError('Decomposition des petits premiers inattendue.')
    return ideals


# Construire la grille sur [1,4], avec le support initial et les seuils des normes et puissances.
def make_grid(step: float, ideals: list[dict]) -> np.ndarray:
    values = [1., INITIAL, 4.]
    values += [round(1+i*step,12) for i in range(int(3/step)+1)]
    for q in set(i['norm'] for i in ideals):
        for m in range(1, int(4/math.log(q))+1):
            values.append(m*math.log(q))
    grid = []
    for t in sorted(v for v in values if 1 <= v <= 4+1e-13):
        if not grid or t-grid[-1] > 2e-11:
            grid.append(min(t,4.))
        else:
            grid[-1] = max(grid[-1],min(t,4.))
    return np.array(grid)


# Calculer les multiplicités exactes des sommes de traces aux normes répétées.
def weights(groups):
    sizes, cumulative = [], []
    for q, multiplicity in groups:
        h = math.isqrt(4*q)
        w = np.ones(2*h+1, dtype=np.int64)
        for _ in range(multiplicity-1):
            w = np.convolve(w, np.ones(2*h+1, dtype=np.int64))
        sizes.append(h*multiplicity)
        cumulative.append(np.r_[0, np.cumsum(w)])
    return np.array(sizes,dtype=int), cumulative


# Compter exactement les branches étiquetées représentées par une boîte de sommes de traces.
def weight(lo, hi, sizes, cumulative):
    return math.prod(int(w[b+h+1]-w[a+h])
                     for a,b,h,w in zip(lo,hi,sizes,cumulative))


# Partitionner le domaine entier par bornes additives; conserver les cas limites et le reste non exploré.
def count_boxes(A, rhs, sizes, cumulative, grid, seconds=30.):
    """Exhaustive partition of an integer domain; retain unresolved cases."""
    root_lo, root_hi = -sizes, sizes
    upper_root = np.where(A>=0, A*root_hi, A*root_lo).sum(axis=1)
    selected = np.flatnonzero(upper_root>rhs-EPS)
    A, rhs = A[selected], rhs[selected]
    pos, neg = np.maximum(A,0), np.minimum(A,0)
    stack = [(root_lo,root_hi)]
    accepted = rejected = borderline = nodes = 0
    rejecting_boxes = []
    started = time.monotonic()
    while stack:
        if nodes % 1024 == 0 and time.monotonic()-started > seconds:
            break
        lo,hi = stack.pop()
        nodes += 1
        lower,upper = pos@lo+neg@hi, pos@hi+neg@lo
        bad = np.flatnonzero(lower>rhs+EPS)
        if len(bad):
            i = int(bad[np.argmax((lower-rhs)[bad])])
            original_row = int(selected[i])
            covered = weight(lo,hi,sizes,cumulative)
            rejected += covered
            if original_row < len(grid):
                kind = 'Odlyzko'
                points = [float(grid[original_row])]
            else:
                k = original_row-len(grid)
                kind = 'croissance_G2'
                points = [float(grid[k]),float(grid[k+1])]
            rejecting_boxes.append(dict(lo=lo.tolist(),hi=hi.tolist(),
                weight=covered,rule=kind,lambdas=points,
                minimizing_point=np.where(A[i]>=0,lo,hi).tolist(),
                margin_float=float(lower[i]-rhs[i])))
        elif np.all(upper<=rhs-EPS):
            accepted += weight(lo,hi,sizes,cumulative)
        elif np.all(lo==hi):
            borderline += weight(lo,hi,sizes,cumulative)
        else:
            k = int(np.argmax(upper-rhs))
            j = int(np.argmax(np.abs(A[k])*(hi-lo)))
            if hi[j]==lo[j]:
                j=int(np.argmax(hi-lo))
            mid = int((lo[j]+hi[j])//2)
            left_hi,right_lo = hi.copy(),lo.copy()
            left_hi[j],right_lo[j] = mid,mid+1
            stack.extend([(right_lo,hi),(lo,left_hi)])
    pending = sum(weight(lo,hi,sizes,cumulative) for lo,hi in stack)
    total = weight(root_lo,root_hi,sizes,cumulative)
    if accepted+rejected+borderline+pending != total:
        raise RuntimeError('Nombre de combinaisons non conserve.')
    return dict(complete=not stack,total=total,accepted=accepted,rejected=rejected,
        borderline=borderline,pending=pending,nodes=nodes,
        elapsed_seconds=time.monotonic()-started,leaves=rejecting_boxes)
