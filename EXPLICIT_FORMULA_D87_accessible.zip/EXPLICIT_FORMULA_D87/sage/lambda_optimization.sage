"""Source-faithful lambda optimization for Mestre conductor bounds.

The primary search follows the original three stages: step 1, then 0.1, then
0.01.  It exposes one optimal lambda rather than a user-chosen search interval.
"""

from typing import Any, Callable
from sage.all import RealField, floor


# maximize a one-variable bound by the original staged heuristic.
# Input: evaluate(lambda)->result dictionary, start, step sizes, and safety cap.
# Output: the best result dictionary found at the last stage.
#
def staged_lambda_search(
    evaluate: Callable,
    start_lambda: Any = 1,
    steps=(1, 0.1, 0.01),
    safety_lambda: Any = 50,
    precision: int = 100,
):
    R = RealField(precision)
    start = R(start_lambda)
    step_values = tuple(R(step) for step in steps)
    safety = R(safety_lambda)
    if start <= 0 or safety <= start or not step_values or min(step_values) <= 0:
        raise ValueError('invalid staged-search parameters')

    current_lambda = start
    current = evaluate(current_lambda)
    previous_step = None

    for step in step_values:
        if previous_step is not None:
            # This reproduces the original backtracking: 0.9 after step 1,
            # then 0.09 after step 0.1.
            current_lambda -= previous_step - step
            if current_lambda <= 0:
                current_lambda = step
            current = evaluate(current_lambda)

        while True:
            candidate_lambda = current_lambda + step
            if candidate_lambda > safety:
                raise RuntimeError(
                    'the bound was still increasing at safety_lambda; increase the safety cap'
                )
            candidate = evaluate(candidate_lambda)
            if candidate['log_absolute_norm_bound'] > current['log_absolute_norm_bound']:
                current_lambda = candidate_lambda
                current = candidate
            else:
                break
        previous_step = step

    current['search_method'] = 'original_staged_search'
    current['search_start'] = start
    current['search_steps'] = step_values
    return current


# compute the source-style optimal bound for one field.
# Input: the mathematical bound data; no lambda interval is required.
# Output: the conductor-bound dictionary at the selected lambda.
#
def optimal_bound(
    number_field: Any,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    test_function=mestre_test_function,
    start_lambda: Any = 1,
    steps=(1, 0.1, 0.01),
    safety_lambda: Any = 50,
    precision: int = 100,
):
    phi = phi_at_one_half(test_function, precision)

    # Evaluate the same conductor formula at one trial lambda during the staged search.
    #
    def evaluate(lam):
        return conductor_bound(
            number_field=number_field,
            lambda_value=lam,
            dimension=dimension,
            analytic_rank=analytic_rank,
            reduction_conditions=reduction_conditions,
            test_function=test_function,
            precision=precision,
            phi_value=phi,
        )

    return staged_lambda_search(
        evaluate,
        start_lambda=start_lambda,
        steps=steps,
        safety_lambda=safety_lambda,
        precision=precision,
    )


# check the optimum on an explicit finite grid.
# Input: field, lambda interval, step, and bound data.  Output: best result dict.
#
def grid_optimal_bound(
    number_field: Any,
    lambda_min: Any,
    lambda_max: Any,
    step: Any = 0.01,
    dimension: int = 1,
    analytic_rank: int = 0,
    reduction_conditions=(),
    test_function=mestre_test_function,
    precision: int = 100,
):
    R = RealField(precision)
    first, last, delta = R(lambda_min), R(lambda_max), R(step)
    if not (0 < first <= last and delta > 0):
        raise ValueError('require 0 < lambda_min <= lambda_max and step > 0')

    phi = phi_at_one_half(test_function, precision)
    count = int(floor((last - first) / delta))
    best = None
    for index in range(count + 1):
        result = conductor_bound(
            number_field=number_field,
            lambda_value=first + index * delta,
            dimension=dimension,
            analytic_rank=analytic_rank,
            reduction_conditions=reduction_conditions,
            test_function=test_function,
            precision=precision,
            phi_value=phi,
        )
        if best is None or result['log_absolute_norm_bound'] > best['log_absolute_norm_bound']:
            best = result
    best['search_method'] = 'finite_grid_check'
    best['lambda_min'] = first
    best['lambda_max'] = last
    best['grid_step'] = delta
    return best
