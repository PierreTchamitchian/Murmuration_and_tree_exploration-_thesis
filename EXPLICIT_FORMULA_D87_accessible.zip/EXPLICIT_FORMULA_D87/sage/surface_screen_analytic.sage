"""Analytic rows for fixed-conductor screening over Q.
Source convention: C_F(lambda)=g*M_F(lambda)+lambda*r*integral(F)
                              +2*sum_{p,m} S_m(p)*log(p)*F(m log(p)/lambda)/p^m.
The SOURCE_GROWTH function is copied mathematically from the supplied notebook;
its sampled increasing condition is an additional, explicitly labelled heuristic.
"""
import numpy as _ss_np
from scipy.integrate import quad as _ss_quad
from numpy.polynomial.legendre import leggauss as _ss_leggauss


# create a coarse endpoint-inclusive grid. Input: positive reals. Output: list[float].
#
def surface_lambda_grid(start=1.0, stop=3.0, step=0.1):
    a, b, h = map(float, (start, stop, step))
    if not all(_ss_math.isfinite(v) for v in (a,b,h)) or not (0 < a <= b and h > 0):
        raise ValueError("Require finite 0<start<=stop and step>0")
    values = [a+k*h for k in range(int(_ss_math.floor((b-a)/h+1e-10))+1)]
    if values[-1] < b-1e-12:
        values.append(b)
    else:
        values[-1] = b
    return values


# evaluate a supported test. Input: name or polynomial-test dict, real x. Output: float.
#
def surface_test_value(test, x):
    x = abs(float(x))
    if x >= 1.0:
        return 0.0
    if isinstance(test, dict):
        if test.get("kind") != "polynomial_convolution":
            raise ValueError("Unrecognized test dictionary")
        return float(surface_polynomial_test_value(test, x))
    if test == "odlyzko":
        return float((1.0-x)*_ss_math.cos(_ss_math.pi*x)+_ss_math.sin(_ss_math.pi*x)/_ss_math.pi)
    if test == "source_growth":
        if x <= 0.5:
            return float(1.0-40.0/3*x*x+80.0/3*x**3-40.0/3*x**4-8.0/3*x**5)
        return float(8.0/3*(1.0-x)**5)
    raise ValueError("Use 'odlyzko', 'source_growth', or a polynomial-test dictionary")


# central-zero coefficient. Input: test. Output: integral over [-1,1] as float.
#
def surface_test_integral(test):
    if test == "odlyzko":
        return float(8.0/_ss_math.pi**2)
    if test == "source_growth":
        return float(5.0/9)
    if isinstance(test, dict):
        return float(test["phi_center"])
    raise ValueError("Unrecognized test")


# evaluate the source M integral stably. Input: positive lambda, test. Output: (value,
# estimated_error).
# Rewritten as 2[log(2pi)+gamma+log(1-exp(-lambda))
# + integral_0^1 lambda*(F(u)-1)/expm1(lambda*u) du].
# QUADPACK error estimates are diagnostics, not rigorous interval enclosures.
#
def surface_archimedean_term(lambda_value, test="odlyzko"):
    lam = float(lambda_value)
    if not _ss_math.isfinite(lam) or lam <= 0:
        raise ValueError("lambda_value must be finite and positive")
    # regularized M integrand. Input: u in [0,1]. Output: float.
    #
    def integrand(u):
        if u == 0:
            # Even convolution may have a right derivative at 0 when its kernel jumps at the endpoint.
            if isinstance(test, dict):
                return -float(test["endpoint_square"])
            return 0.0
        return lam*(surface_test_value(test, u)-1.0)/_ss_math.expm1(lam*u)
    integral, error = _ss_quad(integrand, 0.0, 1.0, points=[0.5],
                               epsabs=2e-11, epsrel=2e-11, limit=120)
    value = 2.0*(_ss_math.log(2.0*_ss_math.pi)+float(_ss_np.euler_gamma)
                 +_ss_math.log(-_ss_math.expm1(-lam))+integral)
    return float(value), float(2*error)


# count potentially visible Newton sums. Input: prime, log cutoff. Output: nonnegative int.
#
def _ss_power_limit(p, cutoff):
    # Include boundary terms; supported tests vanish there. This errs on the side of keeping data.
    return max(0, int(_ss_math.floor(float(cutoff)/_ss_math.log(p)+1e-12)))


# linear explicit-formula row. Input: prepared dict, lambda, test. Output: offset/weight dict.
#
def _ss_analytic_row(prepared, lam, test):
    lam = float(lam)
    if lam > prepared["lambda_max"]+1e-12:
        raise ValueError("A new test exceeds the prepared support; prepare again with larger lambda_max")
    M, error = surface_archimedean_term(lam, test)
    weights = {}
    for p in prepared["primes"]:
        weights[p] = _ss_np.array([2.0*_ss_math.log(p)*surface_test_value(test, m*_ss_math.log(p)/lam)/p**m
                                  for m in range(1, prepared["powers"][p]+1)], dtype=float)
    return {"lambda": lam, "test": test,
            "offset": prepared["dimension"]*M+lam*prepared["analytic_rank"]*surface_test_integral(test),
            "weights": weights, "estimated_integration_error": prepared["dimension"]*error}


# cache common analytic data before scanning conductors.
# Input: list[positive real] (default 1..3 step .1), g=1/2, exact analytic rank,
# growth_from=positive real or None (off), test-name tuple, nonnegative row slack.
# Output: reusable dict, independent of the particular conductor.
# Growth applies ONLY to source_growth on adjacent grid values after the threshold.
#
def prepare_surface_screen(lambda_values=None, dimension=2, analytic_rank=0,
                           growth_from=1.0, tests=("odlyzko", "source_growth"),
                           numerical_slack=1e-8, semistable_exact=True, compact=True):
    g, r = _ss_int(dimension, "dimension"), _ss_int(analytic_rank, "analytic_rank")
    if g not in (1,2) or r < 0:
        raise ValueError("Use dimension=1 or 2 and an exact nonnegative analytic rank")
    grid = sorted(set(float(v) for v in (surface_lambda_grid() if lambda_values is None else lambda_values)))
    if not grid or not all(_ss_math.isfinite(v) and v > 0 for v in grid):
        raise ValueError("lambda_values must be a nonempty list of finite positive values")
    threshold = None if growth_from is None else float(growth_from)
    if threshold is not None and (not _ss_math.isfinite(threshold) or threshold <= 0):
        raise ValueError("growth_from must be positive or None")
    slack = float(numerical_slack)
    if not _ss_math.isfinite(slack) or slack < 0:
        raise ValueError("numerical_slack must be finite and nonnegative")
    if not tests or any(t not in ("odlyzko","source_growth") for t in tests):
        raise ValueError("tests must contain supported standard test names")
    B = _ss_math.exp(grid[-1])
    if B > 1000000:
        raise ValueError("Support above 10^6 is disabled; increase only after estimating the domain sizes")
    primes = surface_primes_below(B*(1.0+2e-15))
    prepared = {"dimension":g, "analytic_rank":r, "lambda_values":grid, "lambda_max":grid[-1],
                "growth_from":threshold, "tests":list(tests), "numerical_slack":slack,
                "semistable_exact":bool(semistable_exact), "compact":bool(compact),
                "primes":primes, "powers":{p:_ss_power_limit(p,grid[-1]) for p in primes}}
    prepared["bound_rows"] = [_ss_analytic_row(prepared, lam, test) for test in tests for lam in grid]
    growth_rows = [_ss_analytic_row(prepared,lam,"source_growth") for lam in grid] if threshold is not None else []
    prepared["growth_rows"] = [
        {"lambda_pair":(grid[j],grid[j+1]),
         "offset":growth_rows[j+1]["offset"]-growth_rows[j]["offset"],
         "weights":{p:growth_rows[j+1]["weights"][p]-growth_rows[j]["weights"][p] for p in primes}}
        for j in range(len(grid)-1) if threshold is not None and grid[j] >= threshold-1e-12]
    return prepared


# evaluate C_F for fixed moments. Input: dict[p,(S1,...)] and parameters. Output: float log bound.
# Missing primes or powers are errors, never silently replaced by zeros.
#
def surface_evaluate_moments(moments, lambda_value, dimension=2, analytic_rank=0, test="odlyzko"):
    lam = float(lambda_value)
    values = {int(p):tuple(float(s) for s in ss) for p,ss in moments.items()}
    M, _ = surface_archimedean_term(lam, test)
    total = int(dimension)*M+lam*int(analytic_rank)*surface_test_integral(test)
    for p in surface_primes_below(_ss_math.exp(lam)):
        mmax = _ss_power_limit(p, lam)
        if p not in values or len(values[p]) < mmax:
            raise ValueError("Missing local moments at p="+str(p))
        total += sum(2.0*_ss_math.log(p)*values[p][m-1]*surface_test_value(test,m*_ss_math.log(p)/lam)/p**m
                     for m in range(1,mmax+1))
    return float(total)
