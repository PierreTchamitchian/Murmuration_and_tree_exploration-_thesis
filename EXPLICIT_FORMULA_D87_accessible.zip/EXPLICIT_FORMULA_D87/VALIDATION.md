# Validation status

This file states exactly what was checked when the clean v2 folder was built.

## Structure and documentation

- All 14 notebooks pass `nbformat` validation.
- All 37 notebook code cells parse as ordinary Python syntax and begin with a short comment explaining the block.
- All 22 shipped `.sage` modules parse as Python-compatible source.
- 158 function/class definitions were checked; every definition has a short explanation immediately before it.
- For 21 of the 22 Sage modules, the executable AST is identical to the supplied v1 source after documentation strings are removed. This includes the two renamed exact-formula files.
- `batch_bounds.sage` is the deliberate interface change: it adds one batch entry point supporting fixed lambda or the existing staged optimizer while calling the same mathematical routines.

## Numerical tests executed under CPython

`tests/test_surface_screen.py` passed **8,854 checks** using the same Python-compatible surface-screen implementation. Its regression values include the baseline survivors `[115,117,119,121]`, the refined survivor `[121]`, and the known-product polynomial bounds at lambda 3 recorded in `VALIDATION.json`.

`tests/check_mestre_convex_relaxation.py` passed exact dual-certificate checks, **60 random models compared with full enumeration**, four edge cases, and the 80-choice elliptic reference with and without monotonicity. The detailed values are recorded in `VALIDATION.json`.

## What was not executed here

Native SageMath is not installed in the packaging environment. Therefore Sage arithmetic and the Jupyter notebooks are **not claimed to have been executed here**. Before a long calculation, run either:

```bash
sage tests/smoke_test.sage
```

or open `notebooks/00_quick_checks.ipynb` with a SageMath kernel.

The LP/MILP and quadrature qualifications stated in the notebooks remain unchanged: numerical MILP infeasibility is not an exact mathematical certificate, and rational LP checks concern the stored finite numerical model.
