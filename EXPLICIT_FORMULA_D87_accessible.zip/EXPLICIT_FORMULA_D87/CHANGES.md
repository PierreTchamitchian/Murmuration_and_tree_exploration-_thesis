# What changed from the supplied v1 folder

This v2 changes organization and explanation, not the intended mathematics of the existing algorithms.

- Old notebooks 01 and 02 are merged into `01_weil_bound_one_field.ipynb`: fixed lambda and staged optimization are one choice.
- Old notebook 03 becomes `03_weil_bounds_by_field.ipynb` and now directly produces the requested root-discriminant/bound plot.
- Old exact-known-curve notebook 07 is separated from unrelated local-factor-search diagnostics.
- Old notebooks 10 and 11 are merged into `10_fixed_local_factor_bounds.ipynb`; the known-conductor cutoff is one optional parameter.
- The two smoke notebooks are replaced by `00_quick_checks.ipynb`; detailed tests remain in `tests/`.
- `exact_formula.sage` is renamed `exact_curve_formula.sage` to say what it does.
- `exact_formula_v2.sage` is renamed `exact_formula_search.sage` because it is only a loader for the local-factor search engine.
- `batch_bounds.sage` gains one clear `compute_field_bounds` entry point supporting either fixed lambda or the existing staged optimizer. `compute_optimal_bounds` remains as a small compatibility wrapper.
- Function explanations in Sage files are moved before the definitions; technical comments remain inside only where they explain a mathematical/numerical step.
- No copy of `original_sources/`, historical `outputs/`, `reference_runs/`, notebook checkpoints, bytecode or nested release archive is included.
- Bulk LMFDB files are not bundled. `data/README.md` says exactly where to place them.
