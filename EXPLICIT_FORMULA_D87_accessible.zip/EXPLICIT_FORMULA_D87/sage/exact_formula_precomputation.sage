"""Precomputation and local-profile database for the exact-formula MILP.

This file creates run directories, enumerates the rational primes required by
the lambda grid, compresses local factors into profiles, and precomputes all
archimedean/local contributions and independent local minima.

Requires: exact_formula_core.sage and exact_formula_local_factors.sage.
"""

# Output directory and local database


# create a fresh output directory for one experiment. Input: ExperimentConfig. Output: pathlib.Path.
#
def make_run_directory(config):
    root = Path(config.output_directory)
    root.mkdir(parents=True, exist_ok=True)
    run_dir = root/config.run_label

    if run_dir.exists():
        if config.overwrite_output:
            shutil.rmtree(run_dir)
        else:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            run_dir = root/(config.run_label+"_"+stamp)
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


# determine all rational primes entering the selected test functions. Input: lambda grid and test
# functions. Output: list of primes.
#
def required_primes(lambdas, tests):
    cutoff = max(RR(max(lambdas))*RR(test.support_radius) for test in tests if test is not None)
    return list(prime_range(ZZ(floor(exp(cutoff)))+1))


# enumerate and compress local candidates into profiles. Input: config, lambda grid, run directory.
# Output: database dictionary; writes candidate/profile CSV files.
#
def build_candidate_database(config, lambdas, run_dir):
    tests = [config.objective_test]
    if config.monotonicity_mode != "off":
        tests.append(config.monotonicity_test)
    primes = required_primes(lambdas, tests)

    raw_path = run_dir/"local_candidates.csv.gz"
    profile_path = run_dir/"local_profiles.csv.gz"
    raw_fields = [
        "p", "raw_id", "profile_id", "signature", "is_bad",
        "conductor_exponent_lower_bound", "toric_indices", "label",
        "characteristic_polynomial", "euler_polynomial", "power_sums",
    ]
    profile_fields = [
        "p", "profile_id", "signature", "is_bad",
        "conductor_exponent_lower_bound", "power_sums", "member_count",
        "representative_characteristic_polynomial", "representative_euler_polynomial",
        "representative_toric_indices", "sample_characteristic_polynomials",
    ]

    database = {"primes": primes, "profiles": {}, "raw_counts": {}, "profile_counts": {}}
    total_profiles = 0

    with gzip.open(raw_path, "wt", encoding="utf-8", newline="") as raw_file:
        raw_writer = csv.DictWriter(raw_file, fieldnames=raw_fields)
        raw_writer.writeheader()

        for p in primes:
            max_power = max(maximum_power(p, max(lambdas), test.support_radius) for test in tests)
            key_to_profile = {}
            profiles = []
            raw_count = 0

            for candidate in validated_candidates(p, config):
                raw_count += 1
                P = candidate["P"]
                sums = power_sums_of_roots(P, max_power)
                signature = tuple(candidate["signature"])
                conductor_exp = ZZ(candidate["conductor_exponent_lower_bound"])

                # Candidates with the same profile are indistinguishable on the chosen grid.
                profile_key = (signature, conductor_exp, tuple(sums[1:]))
                if profile_key not in key_to_profile:
                    profile_index = len(profiles)
                    profile_id = "p{}_q{}".format(p, profile_index)
                    profile = {
                        "p": ZZ(p),
                        "profile_id": profile_id,
                        "signature": signature,
                        "is_bad": signature != (ZZ(config.dimension), ZZ(0), ZZ(0)),
                        "conductor_exponent_lower_bound": conductor_exp,
                        "power_sums": tuple(sums),
                        "P": P,
                        "euler_P": characteristic_to_euler(P),
                        "toric_indices": tuple(candidate["toric_indices"]),
                        "label": candidate["label"],
                        "member_count": 0,
                        "sample_polynomials": [],
                        "contributions": {},
                    }
                    profiles.append(profile)
                    key_to_profile[profile_key] = profile
                else:
                    profile = key_to_profile[profile_key]

                profile["member_count"] += 1
                if len(profile["sample_polynomials"]) < config.max_polynomials_shown_per_profile:
                    profile["sample_polynomials"].append(str(P))

                raw_id = "p{}_r{}".format(p, raw_count-1)
                raw_writer.writerow({
                    "p": int(p),
                    "raw_id": raw_id,
                    "profile_id": profile["profile_id"],
                    "signature": json_text(integer_list(signature)),
                    "is_bad": int(profile["is_bad"]),
                    "conductor_exponent_lower_bound": int(conductor_exp),
                    "toric_indices": json_text(integer_list(candidate["toric_indices"])),
                    "label": candidate["label"],
                    "characteristic_polynomial": str(P),
                    "euler_polynomial": str(characteristic_to_euler(P)),
                    "power_sums": json_text(integer_list(sums)),
                })

            if not profiles:
                raise ValueError("No admissible local factor at p={}.".format(p))

            database["profiles"][ZZ(p)] = profiles
            database["raw_counts"][ZZ(p)] = raw_count
            database["profile_counts"][ZZ(p)] = len(profiles)
            total_profiles += len(profiles)
            if total_profiles > config.max_total_profiles:
                raise ValueError(
                    "Too many local profiles. Increase max_total_profiles or specialize the candidate family."
                )
            print("p={:>3} | candidats bruts={:>7} | profils utiles={:>6} | m_max={}".format(
                p, raw_count, len(profiles), max_power
            ))

    with gzip.open(profile_path, "wt", encoding="utf-8", newline="") as profile_file:
        writer = csv.DictWriter(profile_file, fieldnames=profile_fields)
        writer.writeheader()
        for p in primes:
            for profile in database["profiles"][p]:
                writer.writerow({
                    "p": int(p),
                    "profile_id": profile["profile_id"],
                    "signature": json_text(integer_list(profile["signature"])),
                    "is_bad": int(profile["is_bad"]),
                    "conductor_exponent_lower_bound": int(profile["conductor_exponent_lower_bound"]),
                    "power_sums": json_text(integer_list(profile["power_sums"])),
                    "member_count": profile["member_count"],
                    "representative_characteristic_polynomial": str(profile["P"]),
                    "representative_euler_polynomial": str(profile["euler_P"]),
                    "representative_toric_indices": json_text(integer_list(profile["toric_indices"])),
                    "sample_characteristic_polynomials": json_text(profile["sample_polynomials"]),
                })

    return database


# Precomputation of local contributions and minima


# precompute archimedean and local contributions on the lambda grid. Input: config, grid, candidate
# database, run directory. Output: constants dictionary; writes CSV files.
#
def precompute_contributions(config, lambdas, database, run_dir):
    roles = {"objective": config.objective_test}
    if config.monotonicity_mode != "off":
        roles["monotonicity"] = config.monotonicity_test

    constants = {}
    arch_rows = []
    for role, test in roles.items():
        phi, phi_error = phi_center_with_error(test, config)
        constants[role] = []
        for j, lam in enumerate(lambdas):
            M, M_error = M_lambda_with_error(lam, test, config)
            value = RR(lam)*ZZ(config.analytic_rank)*phi + ZZ(config.dimension)*M
            error = (abs(RR(lam)*ZZ(config.analytic_rank))*phi_error
                     + ZZ(config.dimension)*M_error
                     + RR(config.integration_padding)*(RR(1)+abs(value)))
            constants[role].append({
                "value": value,
                "error": error,
                "phi": phi,
                "phi_error": phi_error,
                "M": M,
                "M_error": M_error,
            })
            arch_rows.append({
                "role": role,
                "lambda_index": j,
                "lambda": rr_text(lam),
                "phi_center": rr_text(phi),
                "phi_error": rr_text(phi_error),
                "M_lambda": rr_text(M),
                "M_error": rr_text(M_error),
                "constant_part": rr_text(value),
                "constant_error": rr_text(error),
            })

    with open(run_dir/"archimedean_terms.csv", "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(arch_rows[0].keys()))
        writer.writeheader()
        writer.writerows(arch_rows)

    contribution_fields = [
        "role", "p", "profile_id", "lambda_index", "lambda",
        "maximum_power", "local_contribution_before_x2", "error_bound",
    ]
    with gzip.open(run_dir/"local_contributions.csv.gz", "wt", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=contribution_fields)
        writer.writeheader()
        for p in database["primes"]:
            for profile in database["profiles"][p]:
                for role, test in roles.items():
                    profile["contributions"][role] = []
                    for j, lam in enumerate(lambdas):
                        value, error, mmax = local_contribution_from_sums(
                            p, profile["power_sums"], lam, test, config
                        )
                        profile["contributions"][role].append({
                            "value": value,
                            "error": error,
                            "maximum_power": mmax,
                        })
                        writer.writerow({
                            "role": role,
                            "p": int(p),
                            "profile_id": profile["profile_id"],
                            "lambda_index": j,
                            "lambda": rr_text(lam),
                            "maximum_power": mmax,
                            "local_contribution_before_x2": rr_text(value),
                            "error_bound": rr_text(error),
                        })

    save_local_minima(config, lambdas, database, roles, run_dir)
    return constants


# save independent local minima for diagnostics. Input: config, grid, database, run directory.
# Output: None; writes CSV.
#
def save_local_minima(config, lambdas, database, roles, run_dir):
    fields = [
        "role", "p", "lambda_index", "lambda", "minimum_value",
        "number_of_tied_profiles", "profile_ids", "representative_polynomials",
    ]
    with open(run_dir/"local_minima.csv", "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for role in roles:
            for p in database["primes"]:
                profiles = database["profiles"][p]
                for j, lam in enumerate(lambdas):
                    active = maximum_power(p, lam, roles[role].support_radius) > 0
                    if not active:
                        continue
                    values = [profile["contributions"][role][j]["value"] for profile in profiles]
                    minimum = min(values)
                    tied = [
                        profile for profile, value in zip(profiles, values)
                        if value <= minimum + RR(config.local_minimum_tolerance)
                    ]
                    writer.writerow({
                        "role": role,
                        "p": int(p),
                        "lambda_index": j,
                        "lambda": rr_text(lam),
                        "minimum_value": rr_text(minimum),
                        "number_of_tied_profiles": len(tied),
                        "profile_ids": json_text([profile["profile_id"] for profile in tied]),
                        "representative_polynomials": json_text([str(profile["P"]) for profile in tied]),
                    })


# Mestre bound with independent local minimizers


# safely round a Sage real downward for the floating-point MILP. Input: value and config. Output:
# Python float.
#
def lower_float(value, config):
    value = RR(value)
    padding = RR(config.float_padding)*(RR(1)+abs(value))
    return float(value-padding)


# safely round a Sage real upward for the floating-point MILP. Input: value and config. Output:
# Python float.
#
def upper_float(value, config):
    value = RR(value)
    padding = RR(config.float_padding)*(RR(1)+abs(value))
    return float(value+padding)


# compute the diagnostic bound with independent local minimizers. Input: config, grid, database,
# constants, run directory. Output: dictionary; writes CSV.
#
def independent_local_bounds(config, lambdas, database, constants, run_dir):
    rows = []
    for j, lam in enumerate(lambdas):
        constant = constants["objective"][j]
        lower_value = constant["value"]-constant["error"]
        central_value = constant["value"]
        selected = {}

        for p in database["primes"]:
            profiles = database["profiles"][p]
            lower_terms = []
            central_terms = []
            for profile in profiles:
                data = profile["contributions"]["objective"][j]
                lower_terms.append(RR(2)*(data["value"]-data["error"]))
                central_terms.append(RR(2)*data["value"])
            index = min(range(len(profiles)), key=lambda k: lower_terms[k])
            lower_value += lower_terms[index]
            central_value += central_terms[index]
            selected[str(p)] = profiles[index]["profile_id"]

        rows.append({
            "lambda_index": j,
            "lambda": lam,
            "central_log_bound": central_value,
            "lower_log_bound": lower_value,
            "central_conductor_bound": exp(central_value),
            "lower_conductor_bound": exp(lower_value),
            "selected_profiles": selected,
        })

    with open(run_dir/"independent_bounds.csv", "w", encoding="utf-8", newline="") as handle:
        fields = [
            "lambda_index", "lambda", "central_log_bound", "lower_log_bound",
            "central_conductor_bound", "lower_conductor_bound", "selected_profiles",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "lambda_index": row["lambda_index"],
                "lambda": rr_text(row["lambda"]),
                "central_log_bound": rr_text(row["central_log_bound"]),
                "lower_log_bound": rr_text(row["lower_log_bound"]),
                "central_conductor_bound": rr_text(row["central_conductor_bound"]),
                "lower_conductor_bound": rr_text(row["lower_conductor_bound"]),
                "selected_profiles": json_text(row["selected_profiles"]),
            })

    global_lower = max(row["lower_log_bound"] for row in rows)
    return {"rows": rows, "global_lower_log_bound": global_lower}


# Min-max MILP with fixed factors and monotonicity constraints


