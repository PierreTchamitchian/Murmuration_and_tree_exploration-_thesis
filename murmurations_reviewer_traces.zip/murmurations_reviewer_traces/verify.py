#!/usr/bin/env python3
"""Check package file hashes and the internal consistency of all compact CSVs."""
import hashlib
import json
from murmurations import ROOT, load_data, require


def sha256_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


if __name__=='__main__':
    checked=0
    for line in (ROOT/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        expected,name=line.split('  ',1)
        path=(ROOT/name).resolve()
        require(path.is_relative_to(ROOT.resolve()),'Checksum path outside package')
        require(sha256_file(path)==expected,f'SHA256 mismatch: {name}')
        checked+=1
    data=load_data()
    print('REVIEW_DATA_OK '+json.dumps({'files_checked':checked,
        'fields':len(data['fields']),'primes':len(data['primes']),
        'orbits':data['meta']['orbit_count'],
        'missing_levels':data['meta']['missing_levels']}))
