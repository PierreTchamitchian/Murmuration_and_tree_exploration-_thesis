"""Load and construct number fields used by the batch notebooks."""

from pathlib import Path
from sage.all import NumberField, PolynomialRing, QQ, ZZ
from sage.repl.load import load as load_sage_file


# load an LMFDB Sage export defining make_data().
# Input: a path to a .sage file.  Output: a list of record dictionaries.
#
def load_lmfdb_number_fields(data_file):
    path = Path(data_file)
    if not path.is_file():
        raise FileNotFoundError('LMFDB data file not found: %s' % path)

    namespace = dict(globals())
    namespace['__name__'] = 'lmfdb_number_field_data'
    load_sage_file(str(path), namespace)
    if 'make_data' not in namespace:
        raise ValueError('the LMFDB Sage file must define make_data()')

    records = namespace['make_data']()
    if not isinstance(records, list):
        raise TypeError('make_data() must return a list')
    return [dict(record) for record in records]


# obtain the Sage number field in one data record.
# Input: a record dictionary.  Output: a Sage number field.
#
def field_from_record(record, generator_name='a'):
    if 'field' in record:
        return record['field']
    if 'poly' in record:
        return NumberField(record['poly'], generator_name)
    if 'coeffs' in record:
        R = PolynomialRing(QQ, 'x')
        return NumberField(R(record['coeffs']), generator_name)
    raise KeyError("record must contain 'field', 'poly', or 'coeffs'")


# build standard records from a list of defining polynomials.
# Input: polynomials and optional labels.  Output: a list of dictionaries.
#
def records_from_polynomials(polynomials, labels=None):
    labels = list(labels) if labels is not None else [None] * len(polynomials)
    if len(labels) != len(polynomials):
        raise ValueError('labels and polynomials must have the same length')

    records = []
    for index, (polynomial, label) in enumerate(zip(polynomials, labels), start=1):
        K = NumberField(polynomial, 'a%s' % index)
        records.append({
            'label': label or 'field_%s' % index,
            'poly': polynomial,
            'coeffs': list(polynomial),
            'disc': K.absolute_discriminant(),
            'field': K,
        })
    return records
