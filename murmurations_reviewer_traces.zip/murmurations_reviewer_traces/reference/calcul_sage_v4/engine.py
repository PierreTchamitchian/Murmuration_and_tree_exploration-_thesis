"""Weight-2 Gamma_0(N) newforms: all quadratic fields, or a prescribed field.

Mathematical source: reference/original_decomposition_code.txt.
The prime sieve comes BEFORE, not after, the exact Sage decomposition.
See ALGORITHM.md for the invariant ensuring that no target orbit is lost.
"""
from __future__ import annotations
import hashlib
import time
from sage.all import QQ, ZZ, Gamma0, ModularSymbols, NumberField, PolynomialRing, set_random_seed
from sage.env import SAGE_VERSION
from common import SCHEMA, first_primes, validate_coefficients, quadratic_field_info
from sieve import hecke_sieve


def target_field(poly):
    R = PolynomialRing(QQ, "x")
    f = R([ZZ(c) for c in poly])
    if f.degree() < 2 or not f.is_monic() or not f.is_irreducible():
        raise ValueError("The target polynomial must be monic, integral, irreducible, degree >= 2")
    K = NumberField(f, "b")
    if tuple(K.signature()) != (int(K.degree()), 0):
        raise ValueError("Weight 2, trivial character: the prescribed coefficient field must be totally real")
    return K


class FieldMatcher:
    def __init__(self, target):
        self.target = target
        self.degree = int(target.degree())
        self.cache = {}

    def polynomial_matches(self, f):
        """f is assumed irreducible of degree d (from a factorization or a field)."""
        if int(f.degree()) != self.degree:
            return False
        key = tuple(str(c) for c in f.list())
        if key not in self.cache:
            if self.degree == 2:
                # Two quadratic fields are equal iff these discriminants have
                # the same square class. Polynomial discriminants are enough.
                ratio = QQ(f.discriminant()) / QQ(self.target.defining_polynomial().discriminant())
                self.cache[key] = bool(ratio.is_square())
            else:
                candidate = NumberField(f, "c")
                self.cache[key] = bool(candidate.is_isomorphic(self.target))
        return self.cache[key]

    def field_matches(self, field):
        if int(field.degree()) != self.degree:
            raise ArithmeticError("Sage eigenvalue field has unexpected degree")
        return self.polynomial_matches(field.defining_polynomial())


def sage_decomposition(block):
    """Full Hecke algebra, default Sage bound, proof enabled; no small-prime cutoff."""
    from sage.all import proof
    proof.linear_algebra(True)
    pieces = list(block.decomposition(bound=None, anemic=False,
                                      sort_by_basis=True, proof=None))
    if sum(int(s.dimension()) for s in pieces) != int(block.dimension()):
        raise ArithmeticError("Sage decomposition failed the dimension check")
    return pieces


def scalar_fricke_sign(space):
    W = space.atkin_lehner_operator(space.level()).matrix()
    d = int(space.dimension())
    if d == 0 or W.nrows() != d or W.ncols() != d:
        raise ArithmeticError("Invalid Fricke matrix size")
    a = W[0, 0]
    if a not in (ZZ(1), ZZ(-1)):
        raise ArithmeticError("Invalid Fricke eigenvalue")
    if any(W[i, j] != (a if i == j else 0) for i in range(d) for j in range(d)):
        raise ArithmeticError("Fricke matrix is not scalar on this component")
    # Weight 2: epsilon(f) = - eigenvalue(W_N).
    return -int(a)


def integral_coeffs(polynomial, degree):
    if int(polynomial.degree()) != degree or not polynomial.is_monic():
        raise ArithmeticError("Incorrect characteristic polynomial degree or leading coefficient")
    # ZZ(c), unlike int(c), rejects nonintegral rational values.
    return [int(ZZ(c)) for c in polynomial.list()]


def charpoly_from_element(a, degree):
    """Norm_{F/QQ}(X-a) even when a lies in a proper subfield of F."""
    h = a.minpoly()
    e = int(h.degree())
    if e < 1 or degree % e:
        raise ArithmeticError("Minimal polynomial degree does not divide the coefficient field degree")
    return h ** (degree // e)


def component_key(space, level):
    # Canonical row-reduced rational subspace, not the unstable Sage factor index.
    B = space.free_module().basis_matrix().echelon_form()
    h = hashlib.sha256(f"{level}:{B.nrows()}:{B.ncols()}:".encode())
    for row in B.rows():
        h.update((",".join(str(c) for c in row) + ";").encode())
    return h.hexdigest()


def compute_level(level, poly=None, prime_count=2000, sieve_primes=12,
                  method="eigenvalues", verify_first=3, progress=None,
                  resume=None, checkpoint=None, checkpoint_every=100):
    # poly=None is deliberately the ALL-quadratic mode, with no field filter.
    level = int(level)
    if level < 1 or prime_count < 1 or sieve_primes < 0 or verify_first < 0 or checkpoint_every < 1:
        raise ValueError("Invalid computation bounds")
    if method not in ("eigenvalues", "matrices", "projected"):
        raise ValueError("Unknown coefficient computation method")
    report = progress if progress is not None else lambda phase, data: None
    start = time.monotonic()
    # Reproducibility of Sage's randomized exact algebra, per level.
    set_random_seed(20261018 + level)
    K = target_field(poly) if poly is not None else None
    d, pp = (int(K.degree()) if K is not None else 2), first_primes(prime_count)
    if method == "projected" and d != 2:
        raise ValueError("The projected method only supports degree-2 coefficient fields")
    matcher = FieldMatcher(K) if K is not None else None
    field_mode = "prescribed" if K is not None else "all_quadratic"
    report("space", {"level": level})
    M = ModularSymbols(Gamma0(ZZ(level)), 2, sign=1)
    new = M.cuspidal_subspace().new_subspace()
    t_space = time.monotonic()
    report("space_ready", {"new_dimension": int(new.dimension())})
    small_primes = first_primes(sieve_primes, coprime_to=level)
    blocks, sieve_stats = hecke_sieve(new, d, small_primes,
                                     matcher.polynomial_matches if matcher else None, report)
    t_sieve = time.monotonic()
    pieces = []
    for j, block in enumerate(blocks):
        report("sage_decomposition", {"block": j + 1, "blocks": len(blocks),
                                      "dimension": int(block.dimension())})
        pieces.extend(sage_decomposition(block))
    t_decomp = time.monotonic()
    targets = [s for s in pieces if int(s.dimension()) == d]
    records, foreign_fields = [], 0
    projected_spaces, projected_records = [], []
    projection_timings = {}
    # Only the coefficient prefix is reused: modular spaces and their field
    # identities are recomputed on restart. Keys are rational subspaces.
    cache = dict(resume or {})
    for j, space in enumerate(targets):
        report("field", {"component": j + 1, "candidates": len(targets)})
        if not space.is_simple():
            raise ArithmeticError("Sage returned a nonsimple target-degree component")
        # The parent of a_1 is the FULL eigenvalue field. Sage can construct a
        # primitive element from a combination of Hecke operators, not just one
        # of a bounded list of a_p. There is no 'generator-tests' cutoff here.
        F = space.eigenvalue(1, name="a").parent()
        if int(F.degree()) != d:
            raise ArithmeticError("Sage eigenvalue field has unexpected degree")
        if matcher is not None and not matcher.field_matches(F):
            foreign_fields += 1
            continue
        field_info = None
        if d == 2:
            # A ring-of-integers discriminant, not disc(minpoly(a_p)).
            # Positive because the character is trivial; fail rather than skip
            # if the arithmetic contradicts the declared setting.
            field_info = dict(quadratic_field_info(int(ZZ(F.discriminant()))))
        key, sign = component_key(space, level), scalar_fricke_sign(space)
        record = cache.get(key)
        if record is not None:
            validate_coefficients(record, d, prime_count, complete=False)
            if record["component_key"] != key or record["root_number"] != sign:
                raise ArithmeticError("Inconsistent partial component checkpoint")
            if field_info is not None and record.get("coefficient_field") != field_info:
                raise ArithmeticError("Partial checkpoint has an inconsistent coefficient field")
        else:
            record = {"component_key": key, "root_number": sign,
                      "hecke_charpolys": [], "traces": [], "norms": [],
                      "matrix_checked_primes": []}
            cache[key] = record
        if field_info is not None:
            record["coefficient_field"] = field_info
        record["field_model"] = [str(c) for c in F.defining_polynomial().list()]
        if method == "projected":
            projected_spaces.append(space)
            projected_records.append(record)
            records.append(record)
            continue
        offset = len(record["hecke_charpolys"])
        # Check a small cached prefix after reconstruction of the Sage space.
        for i in range(min(offset, max(1, verify_first))):
            cp = charpoly_from_element(space.eigenvalue(pp[i], name="a"), d)
            if integral_coeffs(cp, d) != record["hecke_charpolys"][i]:
                raise ArithmeticError("Partial checkpoint disagrees with reconstructed component")
        report("coefficients", {"component": j + 1, "candidates": len(targets),
                                "done": offset, "total": prime_count})
        for i in range(offset, prime_count):
            p = pp[i]
            if method == "matrices":
                cp = space.T(ZZ(p)).charpoly("x")
            else:
                cp = charpoly_from_element(space.eigenvalue(p, name="a"), d)
            coeffs = integral_coeffs(cp, d)
            # Independent matrix checks on a small prefix. Do not construct a
            # huge ambient T_p solely for a check at a large bad prime.
            if method == "eigenvalues" and i < verify_first:
                direct = integral_coeffs(space.T(ZZ(p)).charpoly("x"), d)
                if coeffs != direct:
                    raise ArithmeticError(f"Eigenvalue/matrix disagreement at level={level}, p={p}")
                record["matrix_checked_primes"].append(p)
            record["hecke_charpolys"].append(coeffs)
            record["traces"].append(-coeffs[-2])
            record["norms"].append((-1) ** d * coeffs[0])
            if (i + 1) % checkpoint_every == 0 or i + 1 == prime_count:
                if checkpoint:
                    checkpoint(cache)
                report("coefficients", {"component": j + 1, "candidates": len(targets),
                                        "done": i + 1, "total": prime_count, "prime": p})
        validate_coefficients(record, d, prime_count)
        records.append(record)
    if method == "projected" and set(cache) != {rec["component_key"] for rec in projected_records}:
        raise ArithmeticError("Reconstructed components do not cover the saved partial checkpoint")
    if method == "projected" and projected_spaces:
        from projection import ProjectedQuadraticCoefficients
        from projected_collection import collect_projected
        t_fields = time.monotonic()
        report("projection", {"candidates": len(projected_spaces)})
        projection = ProjectedQuadraticCoefficients(projected_spaces)
        t_projection = time.monotonic()
        # Reference values come from the existing Sage path, not the projection.
        def reference_poly(j, p, matrix=False):
            S = projected_spaces[j]
            cp = S.T(ZZ(p)).charpoly("x") if matrix else charpoly_from_element(S.eigenvalue(p, name="a"), 2)
            return integral_coeffs(cp, 2)
        collect_projected(projection, projected_records, pp, level,
                          reference_poly=reference_poly, verify_first=verify_first,
                          checkpoint_every=checkpoint_every,
                          checkpoint=(lambda: checkpoint(cache)) if checkpoint else None,
                          report=report)
        projection_timings = {"fields_and_signs": t_fields - t_decomp,
                              "projection_setup": t_projection - t_fields,
                              "projected_coefficients_and_checks": time.monotonic() - t_projection,
                              "projection_groups": len(projection.groups)}
    records.sort(key=lambda rec: rec["component_key"])
    end = time.monotonic()
    return {"schema": SCHEMA, "level": level, "complete": True,
            "sage_version": str(SAGE_VERSION), "field_mode": field_mode,
            "field_polynomial": [int(c) for c in poly] if poly is not None else None,
            "prime_count": prime_count, "largest_prime": pp[-1],
            "new_dimension": int(new.dimension()), "sieve": sieve_stats,
            "coefficient_method": method, "projection_timings_seconds": projection_timings,
            "simple_dimensions_after_sieve": [int(s.dimension()) for s in pieces],
            "foreign_fields_after_sieve": foreign_fields, "records": records,
            "timings_seconds": {"space": t_space - start, "sieve": t_sieve - t_space,
                                "sage_decomposition": t_decomp - t_sieve,
                                "fields_and_coefficients": end - t_decomp,
                                "total": end - start}}
