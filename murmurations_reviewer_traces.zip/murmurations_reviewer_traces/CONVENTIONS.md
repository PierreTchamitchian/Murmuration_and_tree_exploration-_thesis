# Conventions numériques

## Formes modulaires

Un enregistrement correspond à une orbite galoisienne [f] de degré 2, et non à une
courbe elliptique sur le corps de coefficients. Le signe `root_number` est le signe
fonctionnel epsilon ; en poids 2 il est l'opposé de la valeur propre de Fricke.

Pour un corps K, un signe epsilon et un premier p, on ne retient que les orbites
calculées de niveau N non divisible par p. Si n est `orbit_count` et S est
`sum_trace`, la moyenne est **S/(2n)**. Pour n=0, la moyenne est absente, pas nulle.
Les cinq colonnes conservées sont :

```text
field_discriminant,root_number,prime,orbit_count,sum_trace
```

Toutes les moyennes décimales de l'ancien CSV sont déductibles de ces colonnes.
Pour regrouper les corps, on additionne les S et les n avant de diviser :
`sum(S)/(2*sum(n))`. Une moyenne non pondérée des moyennes par corps est incorrecte.
Pour la moyenne signée : `sum(epsilon*S)/(2*sum(n))`. La moyenne sans séparation
par signe est différente : `sum(S)/(2*sum(n))`.

Le discriminant est celui du **corps**, pas celui d'un polynôme de coefficient.
`metadata/fields.csv` distingue discriminant et radicand ; par exemple D=8 donne
Q(sqrt(2)) et D=12 donne Q(sqrt(3)).

## Courbes

La moyenne Q est `sum_Q/n_Q`, les courbes de mauvaise réduction étant exclues.
Les groupes `even`/`odd` proviennent des rangs fournis, non d'un nouveau calcul de
signe fonctionnel. `weighted` est la moyenne de (-1)^rang * a_p, avec dénominateur
le nombre total de courbes valides ; ce n'est pas la demi-différence non pondérée
des moyennes paires et impaires.

Pour Q(sqrt(5)), les comparaisons utilisent seulement les **984 premiers rationnels
décomposés**, p congru à 1 ou 4 modulo 5. `mean_K_per_place` est déjà la moyenne de
(a_P1+a_P2)/2 sur les courbes valides aux deux places. Ne pas la diviser une seconde
fois par 2. Ne pas sommer deux moyennes locales avec populations différentes.
Les premiers inertes et le premier ramifié ne sont pas remplacés par zéro.
Les moyennes Q/K sont conservées avec la précision décimale des fichiers sources;
les traces individuelles K ne sont pas fournies.

Les familles Q et K ont la même fenêtre numérique de conducteurs / normes de
conducteurs, pas des conducteurs analytiques nécessairement appariés. La sélection
K par classe d'isogénie ne peut pas être vérifiée avec ces seules données agrégées.
Les six niveaux modulaires manquants ne sont pas retirés de la famille des courbes Q :
la superposition compare les populations disponibles, pas un appariement niveau par
niveau. La campagne porte sur Gamma_0, poids 2, caractère trivial ; pas sur tous les
caractères ni tous les degrés de corps de coefficients.

## Axe horizontal

La jointure des séries se fait par **la valeur de p**. Deux affichages sont proposés :
p, ou son indice global n=pi(p) avec 2->1, 3->2, 5->3, 11->5. On ne renumérote jamais
les seuls premiers décomposés ; 11,19,29 correspondent aux indices globaux 5,8,10.
Les deux tracés utilisent les mêmes ordonnées et le même ensemble de premiers.
Le choix d'axe ne doit pas servir à appliquer des décalages ou ajustements séparés.
Les fichiers ne sont pas classés par l'indice d'un idéal premier.

## Effectifs réduits et limites

Les figures ne comportent pas de barre de confiance reconstruite arbitrairement.
Les traces modulaires individuelles du complément permettent d'autres analyses,
mais une hypothèse d'indépendance entre orbites n'est pas établie par ces données.
Les données agrégées K ne permettent pas de recalculer leurs seconds moments.
La faible taille de certains corps (35 orbites pour Q(sqrt(73))) doit être indiquée.
