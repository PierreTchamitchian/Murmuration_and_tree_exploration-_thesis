#!/usr/bin/env python3
"""Bounded parallel supervision of independent Sage processes (one per level)."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
import traceback
from common import (ROOT, SCHEMA, VERSION, atomic_json, first_primes, read_json,
                    settings_hash, single_thread_env, source_digest,
                    validate_label, validate_result)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--label", required=True)
    selection = p.add_mutually_exclusive_group(required=True)
    selection.add_argument("--all-quadratic", action="store_true",
                           help="Keep every coefficient field of degree exactly 2")
    selection.add_argument("--poly", help="Prescribed field only; ascending coefficients: --poly=-5,0,1")
    p.add_argument("--min-level", type=int, default=11)
    p.add_argument("--max-level", type=int, default=20000, help="Inclusive; no hard upper cap")
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--primes", type=int, default=2000, help="Number of primes, not largest prime")
    p.add_argument("--sieve-primes", type=int, default=12, help="Maximum good primes in the preliminary sieve; 0 = reference")
    p.add_argument("--coefficient-method", choices=("projected", "eigenvalues", "matrices"), default="projected")
    p.add_argument("--verify-first", type=int, default=3)
    p.add_argument("--checkpoint-every", type=int, default=100)
    p.add_argument("--timeout-seconds", type=float, default=0, help="Per level, 0 = unlimited")
    p.add_argument("--keep-going", action="store_true", help="Do not stop scheduling after the first error")
    p.add_argument("--check-only", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--run-prefix", type=Path, help=argparse.SUPPRESS)
    return p


def build_settings(ns):
    validate_label(ns.label)
    if (ns.min_level < 1 or ns.max_level < ns.min_level or ns.workers < 1 or ns.primes < 1
            or ns.sieve_primes < 0 or ns.verify_first < 0 or ns.checkpoint_every < 1
            or ns.timeout_seconds < 0):
        raise ValueError("Invalid bounds or worker count")
    poly = None if ns.all_quadratic else [int(c.strip()) for c in ns.poly.split(",")]
    probe = """import json, sys
from sage.env import SAGE_VERSION
from engine import target_field
poly = json.loads(sys.argv[1])
K = target_field(poly) if poly is not None else None
print(json.dumps({'sage_version': str(SAGE_VERSION), 'degree': int(K.degree()) if K is not None else 2}))
"""
    result = subprocess.run([sys.executable, "-c", probe, json.dumps(poly)], cwd=ROOT,
                            env=single_thread_env(), text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError("Sage/field preflight failed:\n" + result.stderr)
    info = json.loads(result.stdout.strip().splitlines()[-1])
    digest = source_digest()
    report_path = ROOT / "tests" / "sage_validation.json"
    if not report_path.exists():
        raise RuntimeError("First run: python -u tests/sage_smoke.py")
    validation = read_json(report_path)
    if not validation.get("success") or validation.get("source_digest") != digest or validation.get("sage_version") != info["sage_version"]:
        raise RuntimeError("Code/Sage validation is missing or stale. Run: python -u tests/sage_smoke.py")
    if ns.coefficient_method == "projected":
        if info["degree"] != 2:
            raise ValueError("Projection requires degree 2; use --coefficient-method eigenvalues otherwise")
        if not validation.get("projected_engine_tested"):
            raise RuntimeError("Integrated projection validation is missing; run tests/sage_smoke.py")
    settings = {"schema": SCHEMA, "version": VERSION, "source_digest": digest,
                "weight": 2, "character": "trivial", "modular_symbols_sign": 1,
                "field_mode": "all_quadratic" if ns.all_quadratic else "prescribed",
                "poly": poly, "degree": info["degree"], "sage_version": info["sage_version"],
                "primes": ns.primes, "prime_indices": first_primes(ns.primes),
                "sieve_primes": ns.sieve_primes, "coefficient_method": ns.coefficient_method,
                "verify_first": ns.verify_first, "checkpoint_every": ns.checkpoint_every}
    settings["settings_hash"] = settings_hash(settings)
    return settings


def check_existing(base, settings, lo, hi):
    meta = base / "settings.json"
    if meta.exists() and read_json(meta) != settings:
        raise ValueError("Existing label has different settings/code/Sage. Use a NEW label; do not mix results.")
    todo, done = [], []
    for level in range(lo, hi + 1):
        path = base / f"{level}.json"
        if path.exists():
            validate_result(read_json(path), settings, level)
            done.append(level)
        else:
            todo.append(level)
    return todo, done


def terminate_process(proc, grace=8.0):
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait()


def supervise_job(level, settings, base, logdir, stop, timeout, command=None):
    """command is injectable for standard-library integration tests only."""
    if stop.is_set():
        return level, "stopped", 0
    command = command or [sys.executable, "-u", str(ROOT / "worker.py"),
                          "--settings", str(base / "settings.json"), "--level", str(level)]
    started = time.monotonic()
    logfile = logdir / f"{level}.log"
    logfile.parent.mkdir(parents=True, exist_ok=True)
    proc = None
    try:
        with logfile.open("w", encoding="utf-8") as output:
            if stop.is_set():
                return level, "stopped", 0
            proc = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, env=single_thread_env(), cwd=ROOT)
            # Inherit the launcher's dedicated process group, so stop.sh stops
            # both the supervisor and every independent Sage worker.
            while proc.poll() is None:
                if stop.is_set():
                    terminate_process(proc)
                    return level, "stopped", 0
                if timeout and time.monotonic() - started > timeout:
                    terminate_process(proc)
                    raise TimeoutError(f"Per-level timeout ({timeout}s) at level {level}")
                try:
                    proc.wait(timeout=0.25)
                except subprocess.TimeoutExpired:
                    pass
            if stop.is_set() and proc.returncode != 0:
                return level, "stopped", 0
        if proc.returncode != 0:
            raise RuntimeError(f"Worker exit={proc.returncode}; see {logfile}")
        result = read_json(base / f"{level}.json")
        validate_result(result, settings, level)
        return level, "ok", len(result["records"])
    except Exception:
        if proc and proc.poll() is None:
            terminate_process(proc)
        error = base / f"{level}.error.json"
        if not error.exists():
            atomic_json(error, {"level": level, "settings_hash": settings["settings_hash"],
                                "time": time.time(), "traceback": traceback.format_exc(),
                                "log": str(logfile)})
        return level, "error", 0


def campaign_summary(base, settings, lo, hi):
    summary = {"requested": hi - lo + 1, "complete": 0, "matches": 0, "error_levels": []}
    fields = set()
    for level in range(lo, hi + 1):
        final = base / f"{level}.json"
        if final.exists():
            result = read_json(final)
            validate_result(result, settings, level)
            summary["complete"] += 1
            summary["matches"] += len(result["records"])
            if settings["degree"] == 2:
                fields.update(record["coefficient_field"]["discriminant"] for record in result["records"])
        elif (base / f"{level}.error.json").exists():
            summary["error_levels"].append(level)
    summary["missing"] = summary["requested"] - summary["complete"]
    if settings["degree"] == 2:
        summary["quadratic_field_count"] = len(fields)
        summary["quadratic_discriminants"] = sorted(fields)
    return summary


def execute(ns, settings, base):
    todo, done = check_existing(base, settings, ns.min_level, ns.max_level)
    atomic_json(base / "settings.json", settings)
    run = ns.run_prefix or ROOT / "logs" / f"{ns.label}_{time.strftime('%Y%m%d_%H%M%S')}_{os.getpid()}"
    logdir = Path(str(run) + ".levels")
    logdir.mkdir(parents=True, exist_ok=True)
    atomic_json(base / "request.json", {"min_level": ns.min_level, "max_level": ns.max_level,
                                       "workers": ns.workers, "run_prefix": str(run),
                                       "time": time.time()})
    stop = threading.Event()
    old_handlers = {}
    for sig in (signal.SIGTERM, signal.SIGINT):
        old_handlers[sig] = signal.signal(sig, lambda *_: stop.set())
    print(f"queued={len(todo)} already_complete={len(done)} workers={ns.workers} "
          f"primes={ns.primes} largest_prime={settings['prime_indices'][-1]} "
          f"sieve_primes={ns.sieve_primes}", flush=True)
    had_error, next_job = False, iter(todo)
    try:
        with ThreadPoolExecutor(max_workers=ns.workers) as pool:
            futures = {}
            def submit_one():
                try:
                    level = next(next_job)
                except StopIteration:
                    return False
                future = pool.submit(supervise_job, level, settings, base, logdir,
                                     stop, ns.timeout_seconds)
                futures[future] = level
                return True
            for _ in range(ns.workers):
                if not submit_one():
                    break
            while futures:
                ready, _ = wait(futures, timeout=0.5, return_when=FIRST_COMPLETED)
                for future in ready:
                    level, status, matches = future.result()
                    del futures[future]
                    if status == "error":
                        had_error = True
                    print(f"level={level} {status} matches={matches}", flush=True)
                if not stop.is_set() and (not had_error or ns.keep_going):
                    while len(futures) < ns.workers and submit_one():
                        pass
    finally:
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
    summary = campaign_summary(base, settings, ns.min_level, ns.max_level)
    summary.update({"interrupted": stop.is_set(), "run_prefix": str(run),
                    "min_level": ns.min_level, "max_level": ns.max_level,
                    "settings_hash": settings["settings_hash"], "time": time.time()})
    code = 130 if stop.is_set() else (1 if summary["missing"] else 0)
    summary["exit_code"] = code
    atomic_json(base / "last_summary.json", summary)
    print("SUMMARY " + json.dumps(summary, sort_keys=True), flush=True)
    return code


def main():
    ns = parser().parse_args()
    code = 1
    try:
        validate_label(ns.label)
        base = ROOT / "results" / ns.label
        base.mkdir(parents=True, exist_ok=True)
        # A kernel lock, not a stale PID file: released on crashes/signals too.
        with (base / ".campaign.lock").open("a+") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError("A campaign with this label is already running") from None
            if ns.run_prefix is not None and not ns.check_only:
                atomic_json(str(ns.run_prefix) + ".started.json", {"pid": os.getpid(), "time": time.time()})
            settings = build_settings(ns)
            if ns.check_only:
                check_existing(base, settings, ns.min_level, ns.max_level)
                print("PREFLIGHT_OK", flush=True)
                code = 0
            else:
                code = execute(ns, settings, base)
    except Exception:
        traceback.print_exc()
    finally:
        if ns.run_prefix is not None and not ns.check_only:
            ns.run_prefix.parent.mkdir(parents=True, exist_ok=True)
            atomic_json(str(ns.run_prefix) + ".exitcode", code)
    return code


if __name__ == "__main__":
    sys.exit(main())
