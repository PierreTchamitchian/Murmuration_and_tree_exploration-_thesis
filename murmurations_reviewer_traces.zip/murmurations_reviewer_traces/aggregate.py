#!/usr/bin/env python3
"""Rebuild all reported means from exact aggregated sums (no Sage required)."""
import argparse
from pathlib import Path
from murmurations import load_data, export_means

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('outputs/means.csv'))
    args = parser.parse_args()
    count = export_means(load_data(), args.out)
    print(f'MEANS_OK rows={count} output={args.out}')
