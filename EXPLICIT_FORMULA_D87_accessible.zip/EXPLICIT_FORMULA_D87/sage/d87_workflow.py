"""D87 : interface courte pour démonstration, recalcul et exports.

Les formules et le compteur sont ceux de d87_core.py, conservés du calcul
archivé. Ce module organise les étapes; il ne fait appel à aucun solveur.
"""
from __future__ import annotations
import csv
import itertools
import json
import math
import platform
from pathlib import Path
from functools import lru_cache
from importlib.metadata import version
import numpy as np
import d87_core as core

PROJECT_ROOT = Path(__file__).resolve().parents[1]
REFERENCE = PROJECT_ROOT / 'data/examples/D87/reference'

# Lire une table sans changer la représentation des grands nombres entiers.
def read_csv(path: str | Path) -> list[dict]:
    with Path(path).open(encoding='utf8', newline='') as f:
        return list(csv.DictReader(f))

# Préparer une destination séparée des références; refuser une confusion de grilles.
def output_directory(path: str | Path, step: float) -> Path:
    out = Path(path).resolve()
    if out == REFERENCE.resolve() or REFERENCE.resolve() in out.parents:
        raise ValueError('Les références archivées ne doivent pas être écrasées.')
    out.mkdir(parents=True, exist_ok=True)
    config = dict(discriminant=-87,lambda_max=4.0,step=float(step),
                  numerical_margin=core.EPS,interval_certified=False,
                  growth_is_additional_assumption=True)
    p = out / 'configuration.json'
    if p.exists() and json.loads(p.read_text()) != config:
        raise ValueError('Configuration différente : choisir un autre dossier de sortie.')
    core.save_json(p, config)
    core.save_json(out/'environnement.json',dict(python=platform.python_version(),
        packages={name:version(name) for name in ('numpy','scipy','sympy','mpmath')}))
    return out

# Construire une fois les données de l’exemple fixe, avec toutes les puissances locales visibles.
@lru_cache(maxsize=4)
def prepare(step: float = 0.01) -> dict:
    step = float(step)
    if not math.isfinite(step) or not 0.001 <= step <= 0.1:
        raise ValueError('Le pas doit être compris entre 0.001 et 0.1.')
    ideals = core.verify_field()
    grid = core.make_grid(step, ideals)
    groups = [(q,len(list(g))) for q,g in itertools.groupby(ideals[3:], key=lambda r:r['norm'])]
    if any(2*math.log(q) <= 4 for q,_ in groups):
        raise ValueError('La simplification par sommes de traces n’est plus applicable.')
    base = {k:core.DEGREE*np.array([core.arch(float(t),k) for t in grid]) + sum(
        np.array([core.local(q,a,float(t),k) for t in grid])
        for q,a in zip(core.BASE_NORMS, core.BASE)) for k in ('O','G')}
    columns = {k:{q:np.array([core.local(q,1,float(t),k) for t in grid])
                  for q,_ in groups} for k in ('O','G')}
    return dict(step=step, ideals=ideals, grid=grid, groups=groups,
                base=base,columns=columns,log_Q=2*math.log(core.D))

# Parcourir explicitement les 441 triplets au support publié, en conservant les signes numériques.
def initial_branches() -> list[dict]:
    rows=[]
    for b in itertools.product(range(-3,4),range(-3,4),range(-4,5)):
        r=2*math.log(core.D)-core.DEGREE*core.arch(core.INITIAL,'O')-sum(
            core.local(q,a,core.INITIAL,'O') for q,a in zip(core.BASE_NORMS,b))
        rows.append(dict(a_3_1=b[0],a_3_2=b[1],a_5=b[2],residual_O=r,
                         survives=r>=-core.EPS,borderline=abs(r)<core.EPS))
    survivors=[(r['a_3_1'],r['a_3_2'],r['a_5']) for r in rows if r['survives']]
    if survivors != [core.BASE]:
        raise RuntimeError('La branche initiale archivée ne se reproduit pas.')
    return rows

# Énumérer les 187 prolongements à q=8,19, et leurs valeurs aux points de la grille.
def early_branches(model: dict) -> tuple[list[dict],list[dict],list[dict]]:
    sel = model['grid'] <= math.log(23)+1e-12
    grid = model['grid'][sel]
    records,curves=[],[]
    for a8,a19 in itertools.product(range(-5,6),range(-8,9)):
        co=model['base']['O'][sel]+a8*model['columns']['O'][8][sel]+a19*model['columns']['O'][19][sel]
        cg=model['base']['G'][sel]+a8*model['columns']['G'][8][sel]+a19*model['columns']['G'][19][sel]
        residual=model['log_Q']-co
        increments=np.diff(cg)
        io,ig=int(np.argmin(residual)),int(np.argmin(increments))
        passes_o=bool(np.all(residual >= core.EPS))
        passes_g=bool(np.all(increments >= core.EPS))
        rejected_o=bool(np.any(residual < -core.EPS))
        rejected_g=bool(np.any(increments < -core.EPS))
        status='rejet' if rejected_o or rejected_g else ('passe' if passes_o and passes_g else 'indecis')
        records.append(dict(a_3_1=-3,a_3_2=-3,a_5=-4,a_8=a8,a_19=a19,
            lambda_max=float(grid[-1]),passes_O=passes_o,passes_growth=passes_g,status=status,
            min_R_O=float(residual[io]),lambda_min_R_O=float(grid[io]),
            min_increment_G2=float(increments[ig]),lambda_left=float(grid[ig]),lambda_right=float(grid[ig+1])))
        curves.extend(dict(a_8=a8,a_19=a19,index=i,lambda_value=float(t),
            C_O=float(co[i]),R_O=float(residual[i]),C_G2=float(cg[i])) for i,t in enumerate(grid))
    tree=[]
    for a8 in range(-5,6):
        rows=[r for r in records if r['a_8']==a8]
        allowed=[r['a_19'] for r in rows if r['status']=='passe']
        tree.append(dict(a_8=a8,total=17,O_survivors=sum(r['passes_O'] for r in rows),
            OG_survivors=len(allowed),growth_rejections=sum(r['passes_O'] and r['status']=='rejet' for r in rows),
            borderline=sum(r['status']=='indecis' for r in rows),a19_survivants=';'.join(map(str,allowed))))
    return records,curves,tree

# Préparer un palier du même problème entier; les colonnes sont des sommes de traces, pas des poids LP.
def stage_problem(model: dict, end: float) -> dict:
    groups=[(q,m) for q,m in model['groups'] if math.log(q)<end-1e-12]
    select=model['grid']<=end+1e-12
    grid=model['grid'][select]
    O=np.column_stack([model['columns']['O'][q][select] for q,m in groups])
    G=np.column_stack([model['columns']['G'][q][select] for q,m in groups])
    A=np.vstack([O,-np.diff(G,axis=0)])
    rhs=np.r_[model['log_Q']-model['base']['O'][select],np.diff(model['base']['G'][select])]
    sizes,cumulative=core.weights(groups)
    return dict(groups=groups,grid=grid,A=A,rhs=rhs,sizes=sizes,cumulative=cumulative)

# Calculer un palier et produire une couverture de rejets si le domaine entier est fermé.
def run_stage(model: dict, end: float, seconds: float = 60.0) -> tuple[dict,dict | None]:
    if not math.isfinite(seconds) or seconds <= 0:
        raise ValueError('Le budget par palier doit être strictement positif.')
    problem=stage_problem(model,end)
    result=core.count_boxes(problem['A'],problem['rhs'],problem['sizes'],problem['cumulative'],
                            problem['grid'],seconds=seconds)
    record=dict(lambda_max=float(end),
        normes_nouvelles=';'.join(str(q) for q,m in problem['groups'] for _ in range(m)),
        **{k:result[k] for k in ('total','accepted','rejected','borderline','pending','nodes','complete')})
    certificate=None
    if result['complete'] and result['accepted']==0 and result['borderline']==0:
        certificate=dict(field='x^3-x^2+2*x+1',discriminant=-87,base_norms=core.BASE_NORMS,
            base_traces=core.BASE,groups=problem['groups'],end=float(end),step=model['step'],
            grid=problem['grid'].tolist(),nodes=result['nodes'],leaves=result['leaves'])
    return record,certificate

# Exporter les constantes et coefficients nécessaires à la reproduction indépendante des inégalités.
def export_model(model: dict, out: Path) -> None:
    core.save_csv(out/'ideaux.csv',model['ideals'])
    core.save_csv(out/'grille_complete.csv',[dict(index=i,lambda_value=float(t)) for i,t in enumerate(model['grid'])])
    coeff=[]
    for i,t in enumerate(model['grid']):
        row=dict(index=i,lambda_value=float(t),C_O_base=float(model['base']['O'][i]),
            R_O_base=float(model['log_Q']-model['base']['O'][i]),C_G2_base=float(model['base']['G'][i]))
        for q,_ in model['groups']:
            row[f'w_O_q{q}']=float(model['columns']['O'][q][i])
            row[f'w_G2_q{q}']=float(model['columns']['G'][q][i])
        coeff.append(row)
    core.save_csv(out/'coefficients_lambda4.csv',coeff)
    core.save_csv(out/'exemple_zero.csv',[
        dict(lambda_value=float(t),C_O=float(o),R_O=float(model['log_Q']-o),C_G2=float(g))
        for t,o,g in zip(model['grid'],model['base']['O'],model['base']['G'])])

# Regrouper les tables calculées dans un fichier; les chaînes CSV préservent les chiffres et grands entiers.
def consolidate(out: Path) -> Path:
    tables={p.name:read_csv(p) for p in sorted(out.glob('*.csv'))}
    documents={p.name:json.loads(p.read_text(encoding='utf8')) for p in sorted(out.glob('*.json'))
               if p.name!='donnees_numeriques.json'}
    p=out/'donnees_numeriques.json'
    core.save_json(p,dict(origin='recalcule',tables=tables,documents=documents,
        note='Les entrées CSV sont conservées en chaînes pour ne perdre aucun chiffre.'))
    return p

# Exécuter la démonstration courte ou tous les paliers; ne jamais lire les références pour calculer le résultat.
def run_example(out: str | Path, *, full: bool = False, step: float = 0.01,
                seconds_per_stage: float = 60.0, verbose: bool = True) -> dict:
    model=prepare(step)
    out=output_directory(out,float(step))
    if verbose: print('Corps, idéaux et grille vérifiés. Recalcul des 441 choix initiaux.',flush=True)
    initial=initial_branches()
    early,curves,tree=early_branches(model)
    core.save_csv(out/'441_branches_initiales.csv',initial)
    core.save_csv(out/'187_prolongements_norm19.csv',early)
    core.save_csv(out/'187_courbes_norm19.csv',curves)
    core.save_csv(out/'arbre_partiel_norm19.csv',tree)
    export_model(model,out)
    if verbose:
        print(f"187 prolongements : {sum(r['passes_O'] for r in early)} passent O ; "
              f"{sum(r['status']=='passe' for r in early)} passent O + croissance.",flush=True)
    ends=([math.log(q) for q,_ in model['groups'][1:]]+[4.0]) if full else [math.log(41)]
    records=[]; certificate=None
    # Effacer un ancien rejet final pour ne pas le réutiliser après une exécution incomplète.
    old=out/'certificate_float.json'
    if old.exists(): old.unlink()
    for end in ends:
        record,certificate=run_stage(model,end,seconds_per_stage)
        records.append(record)
        core.save_csv(out/'progression.csv',records)
        if verbose: print(f"lambda={end:.9f} : {record['accepted']} acceptées, "
            f"{record['borderline']} limites, {record['pending']} en attente",flush=True)
        if certificate is not None:
            core.save_json(old,certificate)
            break
    closure=certificate['end'] if certificate else None
    summary=dict(mode='reproduction_complete' if full else 'demonstration_courte',origin='recalcule',
        discriminant=-87,degree=3,initial_support=1.97,initial_total=len(initial),
        initial_survivors=sum(r['survives'] for r in initial),base_traces=list(core.BASE),
        early_total=len(early),early_O_survivors=sum(r['passes_O'] for r in early),
        early_OG_survivors=sum(r['status']=='passe' for r in early),
        requested_lambda_max=4.0,step=float(step),closure_lambda=closure,
        no_branch_to_4=closure is not None,
        progression_complete=bool(full and all(r['complete'] for r in records)),
        final_boxes=len(certificate['leaves']) if certificate else None,
        final_covered_extensions=sum(r['weight'] for r in certificate['leaves']) if certificate else None,
        interval_certified=False,growth_is_additional_assumption=True,
        zero_extension_min_O_residual=float(np.min(model['log_Q']-model['base']['O'])),
        zero_extension_min_G_increment=float(np.min(np.diff(model['base']['G']))))
    core.save_json(out/'bilan.json',summary)
    if full and abs(float(step)-0.01)<1e-14:
        reference=read_csv(REFERENCE/'progression.csv')
        keys=('normes_nouvelles','total','accepted','rejected','borderline','pending','nodes','complete')
        match=len(records)==len(reference) and all(
            all(str(row[k])==ref[k] for k in keys) for row,ref in zip(records,reference))
        core.save_json(out/'comparaison_reference.json',dict(matches_reference=match,
            reference='data/examples/D87/reference/progression.csv',
            note='Un écart doit être examiné; les anciens nombres ne remplacent jamais les valeurs recalculées.'))
    consolidate(out)
    return summary

# Afficher une petite table dans un notebook, sans dépendance pandas.
def table(rows: list[dict], columns: list[str] | None = None):
    from html import escape
    from IPython.display import HTML
    if not rows: return HTML('<p>Aucune ligne.</p>')
    cols=columns or list(rows[0])
    head=''.join('<th>'+escape(c)+'</th>' for c in cols)
    body=''.join('<tr>'+''.join('<td>'+escape(str(r.get(c,'')))+'</td>' for c in cols)+'</tr>' for r in rows)
    return HTML('<table style="border-collapse:collapse"><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table>')
