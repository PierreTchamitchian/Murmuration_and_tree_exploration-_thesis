# D87 — rôle des algorithmes et conventions

## 1. Présentation reprise du dossier fourni

Les notebooks servent à exposer l’objectif, charger les modules, fixer les
paramètres et inspecter les objets renvoyés. Les algorithmes réutilisables
restent dans `sage/`. Les petites données sont dans `data/examples/`, les
nouveaux résultats dans `outputs/`, et les tests dans `tests/`.

L’extension D87 **n’utilise pas** les modules LP/MILP des notebooks 10, 12 ou
13. Elle ajoute un parcours entier par blocs. Les routines numériques du
calcul D87 antérieur sont conservées dans `d87_core.py` : comparaison des
arbres syntaxiques exécutables de chacune des dix fonctions avec la source
antérieure, identiques. Les nouveaux modules organisent l’interface, les
exports et les contrôles. Les fichiers du projet fourni sont inchangés.

## 2. Entrée mathématique fixe

- Corps : K = Q[x]/(x³ − x² + 2x + 1), degré 3, discriminant −87.
- Bonne réduction partout dans le modèle; Q = 87² = 7569.
- Normes au support 4 : 3, 3, 5, 8, 19, 23, 25, 29, 29, 31, 37,
  41, 41, 41, 43, 53. Les idéaux répétés restent distincts.
- Domaine local conservateur : toutes les traces entières |a| ≤ floor(2√q).
  Ce n’est pas une classification de la réalisabilité locale des courbes.
- Facteur local : 1 − aT + qT². Puissances : b₀ = 2, b₁ = a,
  bₘ = a bₘ₋₁ − q bₘ₋₂.
- Grille : [1,4], pas 0,01, complétée par 1,97 et tous les seuils m log q.
  Le résultat de référence utilise 315 points.

Pour u = |x| < 1, les noyaux du calcul archivé sont :

```text
O(x)  = (1-u) cos(pi*u) + sin(pi*u)/pi
G2(x) = 1 - (40/3)u² + (80/3)u³ - (40/3)u⁴ - (8/3)u⁵   si u <= 1/2
        (8/3)(1-u)^5                                      si 1/2 <= u < 1
```

Ils sont nuls hors du support. Les deux expressions de G₂ coïncident à 1/2.
Le noyau G₂ est celui des calculs D87 fournis, non un remplacement du noyau
par défaut du projet général.

Pour un noyau F :

```text
C_F(lambda) = 3 M_(lambda,F)
            + 2 sum_(prime ideals p, m>=1) log(q) b_m(p) / q^m * F(m log(q)/lambda)
```

M est le terme archimédien de la formule. L’implémentation double précision
utilise son expression régularisée; le contrôle mpmath réintègre l’expression
originale. La correspondance avec `archimedean_term` du projet Sage est
exposée dans `tests/smoke_d87.sage`, à exécuter dans Sage.

## 3. Les deux règles, et seulement elles

1. **Odlyzko :** R_O(λ) = log Q − C_O(λ) ≥ 0 à chaque point.
2. **Croissance :** ΔG₂ = C_G₂(λ_droite) − C_G₂(λ_gauche) ≥ 0 entre points
   consécutifs.

La première utilise les hypothèses analytiques/GRH du calcul archivé. La
seconde est une condition supplémentaire imposée sur la grille. Elle n’est
pas présentée comme un théorème universel. Aucun test FKL, aucune pente
spectrale, aucun test LP/MILP et **aucune vitesse de convergence** n’entrent
ici. La condition de positivité de G₂ n’est pas ajoutée séparément.

La marge EPS = 10^−10 sert à séparer les signes flottants : elle n’est
ni un taux de convergence ni une borne certifiée d’erreur de quadrature.
Un cas près de zéro reste `borderline`; une branche non visitée reste
`pending`.

## 4. Algorithme A — montrer l’arbre initial

**Entrée :** les domaines aux normes 3, 3, 5 et λ = 1,97.

```text
pour chaque triplet de traces dans [-3,3] × [-3,3] × [-4,4] :
    calculer R_O(1,97)
    enregistrer la marge et le statut
conserver le triplet (-3,-3,-4)
```

**Sortie :** les 441 lignes, dont une survivante. Aucun résultat initial
n’est chargé du fichier de référence pour décider du statut.

## 5. Algorithme B — montrer l’apport propre de la croissance

**Entrée :** le préfixe unique; a₈ ∈ [-5,5], a₁₉ ∈ [-8,8].

```text
pour chacun des 187 prolongements :
    calculer C_O et C_G2 sur la grille jusqu'à log(23)
    tester séparément la positivité O et les accroissements G2
    enregistrer toutes les courbes et les valeurs critiques
```

**Sortie de référence :** 187 passent O; 136 échouent à la croissance;
51 passent les deux. Les survivantes ont a₈ = 3,4,5 et tout a₁₉ ∈ [-8,8].
Cet étage fournit un exemple où le rejet est dû exclusivement au deuxième
critère. La règle choisie pour un bloc du rejet final ne suffit pas, à elle
seule, à établir que les branches du bloc passent l’autre règle.

## 6. Algorithme C — terminer le parcours entier sans énumérer chaque feuille

Tous les nouveaux idéaux ont q ≥ 8, et q² > exp(4). Leurs contributions sont
donc **linéaires en leur trace entière**. On peut regrouper les idéaux de
même norme par somme des traces, avec la multiplicité exacte de chaque somme.
Les puissances des trois idéaux initiaux sont, elles, conservées explicitement.

À un palier donné, les règles s’écrivent A z ≤ b. Cela **ne constitue pas
une relaxation linéaire** : z parcourt seulement des valeurs entières.
Sur une boîte entière l ≤ z ≤ h, chaque ligne a des extrema additifs :

```text
minimum = somme_j A_j * (l_j si A_j >= 0, sinon h_j)
maximum = somme_j A_j * (h_j si A_j >= 0, sinon l_j)
```

```text
empiler le domaine entier complet
jusqu'à épuisement de la pile ou du budget :
    prendre une boîte
    si une ligne viole la condition même à son minimum : rejeter toute la boîte
    sinon, si toutes les lignes passent même à leur maximum : accepter toute la boîte
    sinon, si la boîte est un point : conserver le cas comme numériquement limite
    sinon : partager un intervalle entier en deux et empiler les deux enfants
compter les éléments restés dans la pile comme pending
vérifier accepted + rejected + borderline + pending = total
```

Les sommes de traces de deux idéaux q=29, par exemple, ne représentent pas
chacune le même nombre de feuilles. Le poids est calculé par convolution
des domaines entiers. Le vérificateur recompte les poids indépendamment,
vérifie l’absence de recouvrement, puis la couverture totale.

**Sortie :** comptes par palier et boîtes de rejet. À λ = log(41), 34 boîtes
disjointes rejettent 18 919 991 475 prolongements, sans cas limite ni pending.
La contribution d’une norme plus grande est nulle aux points de rejet déjà
utilisés : une extension jusqu’à λ=4 ne peut pas les réparer.

## 7. Deux modes de reproduction

- `demo` refait A, B, puis C au palier final. Ce n’est pas une reproduction
  des comptes intermédiaires. Le rejet final est bien recalculé.
- `reproduire` refait A, B et tous les paliers de C. La comparaison aux
  comptes archivés se fait **après** le calcul, sans les imposer.

Le `total` de chaque palier est le produit de tous les domaines après le
préfixe initial. Le compteur recalcule ce domaine avec toutes les contraintes
antérieures; il ne s’agit pas du nombre de feuilles effectivement visitées.
Le champ `nodes` compte les boîtes examinées, pas les branches individuelles.

## 8. Données, lecture et validation

La table `progression.csv` distingue `accepted`, `rejected`, `borderline`
et `pending`. `complete=True` signifie que le budget n’a pas laissé de boîte
en attente; cela ne supprime pas les `borderline`. Pour conclure au rejet
numérique d’un domaine : accepted = borderline = pending = 0.

Les références dans `data/examples/D87/reference/` restent intactes.
`outputs/` reçoit uniquement de nouvelles exécutions. Le fichier consolidé
JSON préserve les chaînes des CSV pour ne pas arrondir les grands entiers.
`certificate_float.json` est le nom historique : c’est une **couverture
numérique de rejets**, pas un certificat mathématique par intervalles.

Le contrôle à 70 chiffres utilise mpmath et une autre expression de
l’intégrande. Il confirme les signes avec une précision de travail élevée;
il ne fournit pas d’encadrements certifiés. Les limites de l’interprétation
scientifique demeurent celles du rapport d’origine.
