"""Optimize the Mestre test function for fixed local prime-power moments.

Mathematical reduction:
1. Appendix A of Tchamitchian proves that polynomial convolution tests are dense in the chosen space of test functions.
2. Write the even kernel h in a finite basis. The explicit-formula value becomes a quadratic form v^T A v.
3. The normalization F(0)=1 is v^T Q v=1, where Q is the positive Gram matrix of the kernel basis.
4. Maximizing the bound is therefore the generalized Rayleigh-quotient problem max (v^T A v)/(v^T Q v).
5. Its maximum is the largest generalized eigenvalue of A v = mu Q v.

Numerical algorithm: scipy.linalg.eigh(A,Q) solves the real symmetric-definite generalized eigenproblem. For the full generalized spectrum SciPy uses the LAPACK gvd driver by default; LAPACK DSYGVD uses a divide-and-conquer eigensolver when eigenvectors are requested.

References: Tchamitchian, Appendix A, arXiv:2410.12922v3; SciPy scipy.linalg.eigh documentation; LAPACK DSYGVD documentation."""
from numpy.polynomial import Polynomial as _ss_Polynomial, Legendre as _ss_Legendre
from scipy.linalg import eigh as _ss_eigh


# reuse Gauss nodes. Input: positive int. Output: (nodes, weights) arrays on [-1,1].
#
@_ss_cache(maxsize=None)
def _ss_gauss(order):
    return _ss_leggauss(int(order))


# build the even polynomial space. Input: even degree<=12, endpoint order>=0. Output: basis dict.
# h_i(t)=(1-4t^2)^endpoint_order * Legendre_{2i}(2t), supported on [-1/2,1/2].
# endpoint_order=0 is exactly the even-polynomial space used in Appendix A.
# Positive endpoint_order is a different, explicitly selected subspace.
#
@_ss_cache(maxsize=None)
def _ss_polynomial_basis(degree, endpoint_order=0):
    degree, order = _ss_int(degree), _ss_int(endpoint_order)
    if degree < 0 or degree % 2 or degree > 12 or order < 0 or order > 3:
        raise ValueError("Use even degree between 0 and 12, and endpoint_order between 0 and 3")
    envelope = _ss_Polynomial([1,0,-4])**order
    polynomials = []
    for i in range(degree//2+1):
        c = _ss_Legendre.basis(2*i).convert(kind=_ss_Polynomial).coef
        polynomials.append(_ss_Polynomial([float(v)*2.0**j for j,v in enumerate(c)])*envelope)
    basis = {"polynomials":polynomials, "degree":degree, "endpoint_order":order,
             "order":max(16,degree+2*order+2)}
    nodes, weights = _ss_gauss(basis["order"])
    values = _ss_np.array([h(nodes/2) for h in polynomials])
    basis["G"] = (values*(weights/2))@values.T
    basis["integrals"] = values@(weights/2)
    return basis


# exact-polynomial Gauss evaluation of cross-convolutions. Input: basis, |x|<=1. Output: symmetric
# matrix.
# Gauss order exceeds the integrand polynomial degree requirement; arithmetic remains floating
# point.
#
def _ss_correlation_matrix(basis, x):
    u = abs(float(x)); d = len(basis["polynomials"])
    if u >= 1.0:
        return _ss_np.zeros((d,d))
    nodes,weights = _ss_gauss(basis["order"])
    t = u/2+(1-u)*nodes/2
    left = _ss_np.array([h(t) for h in basis["polynomials"]])
    right = _ss_np.array([h(t-u) for h in basis["polynomials"]])
    matrix = (left*(weights*(1-u)/2))@right.T
    return (matrix+matrix.T)/2


# evaluate F=(h*h)/integral(h^2). Input: test dict, real x. Output: float.
#
def surface_polynomial_test_value(test, x):
    u = abs(float(x))
    if u >= 1:
        return 0.0
    coefficients = _ss_np.asarray(test["kernel_coefficients"],dtype=float)
    nodes,weights = _ss_gauss(max(16,len(coefficients)+1))
    t = u/2+(1-u)*nodes/2
    h1 = _ss_np.polynomial.polynomial.polyval(t,coefficients)
    h2 = _ss_np.polynomial.polynomial.polyval(t-u,coefficients)
    return float(_ss_np.dot(weights,h1*h2)*(1-u)/2/test["kernel_norm_squared"])


# precompute the quadratic-form matrices. Input: basis parameters, lambda,g,r, quadrature order.
# Output: (base matrix, dict[(p,m), local matrix], Gram matrix).
#
@_ss_cache(maxsize=256)
def _ss_polynomial_matrices(degree, endpoint_order, lambda_value, dimension, analytic_rank, quadrature_order):
    basis = _ss_polynomial_basis(degree,endpoint_order)
    lam,g,r = float(lambda_value),int(dimension),int(analytic_rank)
    nodes,weights = _ss_gauss(int(quadrature_order))
    u,w = (nodes+1)/2,weights/2
    G = basis["G"]
    integral = _ss_np.zeros_like(G)
    for t,weight in zip(u,w):
        integral += weight*lam*(_ss_correlation_matrix(basis,t)-G)/_ss_math.expm1(lam*t)
    scalar = _ss_math.log(2*_ss_math.pi)+float(_ss_np.euler_gamma)+_ss_math.log(-_ss_math.expm1(-lam))
    base = 2*g*(scalar*G+integral)+lam*r*_ss_np.outer(basis["integrals"],basis["integrals"])
    local = {(p,m):2*_ss_math.log(p)/p**m*_ss_correlation_matrix(basis,m*_ss_math.log(p)/lam)
             for p in surface_primes_below(_ss_math.exp(lam)) for m in range(1,_ss_power_limit(p,lam)+1)}
    return base,local,G


# maximize the exact-local expression within an Appendix-A polynomial space.
# Input: moments dict[p,(S1,...)], lambda>0, g/r, even degree, endpoint order, quadrature order.
# Output: dict with test, kernel_coefficients, log_bound, conductor_bound, odlyzko_bound,
# eigen_residual and a doubled-quadrature discrepancy. No global optimality over all tests is
# claimed.
#
def optimize_surface_polynomial_test(moments, lambda_value, dimension=2, analytic_rank=0,
                                     degree=4, endpoint_order=0, quadrature_order=96):
    lam = float(lambda_value)
    g,r,d,order,qorder = map(_ss_int,(dimension,analytic_rank,degree,endpoint_order,quadrature_order))
    if not _ss_math.isfinite(lam) or lam <= 0 or g not in (1,2) or r < 0 or qorder < 24:
        raise ValueError("Require lambda>0, g=1/2, r>=0 and quadrature_order>=24")
    values = {int(p):tuple(float(s) for s in sums) for p,sums in moments.items()}
    base,local,G = _ss_polynomial_matrices(d,order,lam,g,r,qorder)
    A = base.copy()
    # Add the contribution of every prime power required by this value of lambda.
    for (p,m),matrix in local.items():
        if p not in values or len(values[p]) < m:
            raise ValueError("Missing moments at p="+str(p)+" for the requested support")
        A += values[p][m-1]*matrix
    # Generalized Rayleigh quotient: maximize v^T A v / v^T G v.
    # scipy.linalg.eigh solves A v = mu G v; the last eigenpair gives the maximum.
    eigenvalues,vectors = _ss_eigh((A+A.T)/2,G,check_finite=True)
    vector = vectors[:,-1]
    if vector[0] < 0:
        vector = -vector
    basis = _ss_polynomial_basis(d,order)
    kernel = sum((float(v)*h for v,h in zip(vector,basis["polynomials"])),_ss_Polynomial([0]))
    norm = float(vector@G@vector)
    test = {"kind":"polynomial_convolution", "kernel_coefficients":[float(c) for c in kernel.coef],
            "kernel_norm_squared":norm, "phi_center":float((vector@basis["integrals"])**2/norm),
            "endpoint_square":float(kernel(0.5)**2/norm), "degree":d, "endpoint_order":order}
    refined_base,_,_ = _ss_polynomial_matrices(d,order,lam,g,r,2*qorder)
    refined = float(vector@(A+refined_base-base)@vector/norm)
    eigen = float(eigenvalues[-1])
    return {"lambda_value":lam,"test":test,"kernel_coefficients":test["kernel_coefficients"],
            "log_bound":refined,"conductor_bound":float(_ss_np.exp(refined)),
            "odlyzko_bound":float(_ss_np.exp(surface_evaluate_moments(values,lam,g,r,"odlyzko"))),
            "basis_coefficients":[float(v) for v in vector],
            "eigen_residual":float(_ss_np.linalg.norm(A@vector-eigen*G@vector)),
            "quadrature_discrepancy":abs(refined-eigen)}


# known-curve reference moments. Input: Sage elliptic curve/Q, cutoff, number of copies.
# Output: dict[p,tuple[int]] for E^copies. Calls curve.ap and curve.conductor; not the database.
#
def surface_curve_moments(curve, lambda_max=3.0, copies=1):
    copies = _ss_int(copies)
    if copies < 1:
        raise ValueError("copies must be positive")
    conductor = int(curve.conductor())
    moments = {}
    for p in surface_primes_below(_ss_math.exp(float(lambda_max))):
        a = int(curve.ap(p)); m = _ss_power_limit(p,lambda_max)
        sums = tuple(a**k for k in range(1,m+1)) if conductor%p == 0 else surface_newton_sums((1,-a,p),m)
        moments[p] = tuple(copies*s for s in sums)
    return moments
