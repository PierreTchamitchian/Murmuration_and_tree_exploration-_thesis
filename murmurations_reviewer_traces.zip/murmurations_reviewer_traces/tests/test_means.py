import unittest
from murmurations import global_prime_indices, means, pool_fields, require


class ExactMeansTests(unittest.TestCase):
    def test_two_embeddings(self):
        self.assertEqual(means({(1,11):(8,2)}), {11:2.0})

    def test_pool_weights(self):
        # Individual means 1 and 3; correct pooled mean 2.8, not 2.
        pooled=pool_fields({5:{(1,11):(2,1)},8:{(1,11):(54,9)}})
        self.assertEqual(means(pooled)[11], 2.8)

    def test_signed_denominator(self):
        block={(1,11):(12,2),(-1,11):(-8,3)}
        self.assertEqual(means(block,signed=True)[11], 2.)
        self.assertEqual(means(block)[11], .4)

    def test_sign_selection(self):
        block={(1,11):(12,2),(-1,11):(-8,3)}
        self.assertEqual(means(block,sign=1)[11],3.)
        self.assertEqual(means(block,sign=-1)[11],-4/3)

    def test_missing_denominator_not_zero(self):
        self.assertEqual(means({(1,11):(0,0)}), {})

    def test_actual_zero_mean_is_retained(self):
        self.assertEqual(means({(1,11):(0,2)}), {11:0.})

    def test_global_index_not_split_index(self):
        idx=global_prime_indices(31)
        self.assertEqual([idx[p] for p in [11,19,29]], [5,8,10])

    def test_require_active(self):
        with self.assertRaises(ValueError):
            require(False,'bad data')


if __name__=='__main__':unittest.main()
