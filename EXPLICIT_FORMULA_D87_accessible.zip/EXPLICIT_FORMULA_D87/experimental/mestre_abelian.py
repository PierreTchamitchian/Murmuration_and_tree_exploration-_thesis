"""Exact Mestre conductor bounds over Q for truncated L-functions of abelian varieties.

This module is intended to be imported from a SageMath kernel.  It has two
main entry points:

* ``evaluate_truncated_l_function`` evaluates the exact explicit-formula
  lower bound for user-supplied local Euler factors.
* ``search_minimal_local_factors`` exhaustively searches the local candidate
  factors at every prime ``p`` with ``log(p) <= lambda`` and chooses the one
  giving the smallest local contribution.

The search is separable prime by prime.  It returns a *formal* truncated Euler
product.  Independent local minimizers need not come from one global abelian
variety.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple
import gzip
import json
import shutil
import unicodedata

from sage.all import (
    Infinity,
    ZZ,
    ComplexField,
    PolynomialRing,
    RealField,
    cos,
    cyclotomic_polynomial,
    euler_phi,
    exp,
    floor,
    log,
    numerical_integral,
    pi,
    prime_range,
    sin,
)


# ---------------------------------------------------------------------------
# Polynomial conventions
# ---------------------------------------------------------------------------

CHARACTERISTIC_RING = PolynomialRing(ZZ, "X")
X = CHARACTERISTIC_RING.gen()
EULER_RING = PolynomialRing(ZZ, "T")
T = EULER_RING.gen()

__version__ = "1.0.0"

__all__ = [
    "__version__",
    "CHARACTERISTIC_RING",
    "X",
    "EULER_RING",
    "T",
    "polynomial_coefficients",
    "characteristic_to_euler",
    "euler_to_characteristic",
    "coerce_local_factor",
    "odlyzko_test_function",
    "relevant_primes",
    "maximum_prime_power_exponent",
    "phi_at_one_half",
    "mestre_archimedean_term",
    "power_sums_of_roots",
    "local_mestre_weights",
    "local_mestre_sum_from_power_sums",
    "exact_local_mestre_sum",
    "LocalFactorCandidate",
    "LocalReductionCondition",
    "normalize_reduction_condition",
    "reduction_condition_to_dict",
    "reduction_condition_from_dict",
    "reduction_condition_for_prime",
    "allowed_reduction_signatures",
    "good_reduction_candidates",
    "cyclotomic_indices_with_degree_at_most",
    "toric_characteristic_polynomial_from_indices",
    "toric_characteristic_polynomials",
    "structural_local_candidates",
    "all_structural_local_candidates",
    "custom_local_factor_candidates",
    "local_candidates_for_condition",
    "candidate_matches_reduction_condition",
    "validate_local_factor_candidate",
    "candidate_provider_from_mode",
    "CandidateEvaluation",
    "PrimeSearchResult",
    "PartialLFunction",
    "MestreBoundResult",
    "evaluate_truncated_l_function",
    "search_minimal_local_factors",
    "recompute_from_retained_candidates",
    "recompute_from_candidate_cache",
    "best_local_factors_table",
    "save_best_local_factors_json",
]


def polynomial_coefficients(poly: Any) -> Tuple[int, ...]:
    """Return coefficients in increasing degree order, including zeroes."""
    degree = int(poly.degree())
    if degree < 0:
        return tuple()
    return tuple(int(poly[i]) for i in range(degree + 1))


def characteristic_to_euler(characteristic_polynomial: Any):
    r"""Convert ``chi(X)=prod(X-alpha_i)`` to ``P(T)=prod(1-alpha_i*T)``.

    Coefficients are reversed.  A monic characteristic polynomial therefore
    becomes an Euler polynomial with constant coefficient one.
    """
    chi = CHARACTERISTIC_RING(characteristic_polynomial)
    if chi.degree() < 0:
        raise ValueError("The zero polynomial is not a local factor.")
    degree = int(chi.degree())
    return EULER_RING([chi[degree - i] for i in range(degree + 1)])


def euler_to_characteristic(euler_polynomial: Any):
    r"""Convert ``P(T)=prod(1-alpha_i*T)`` to ``chi(X)=prod(X-alpha_i)``."""
    local_factor = EULER_RING(euler_polynomial)
    if local_factor.degree() < 0:
        raise ValueError("The zero polynomial is not a local factor.")
    degree = int(local_factor.degree())
    return CHARACTERISTIC_RING(
        [local_factor[degree - i] for i in range(degree + 1)]
    )


def coerce_local_factor(
    factor: Any,
    *,
    convention: str = "euler",
) -> Tuple[Any, Any]:
    """Return a pair ``(characteristic_polynomial, euler_polynomial)``.

    A sequence is interpreted as coefficients in increasing degree order.
    For example, ``[1, -a, p]`` means ``1 - a*T + p*T^2`` in Euler
    convention.
    """
    normalized_convention = convention.lower().strip()
    if normalized_convention == "euler":
        euler_polynomial = EULER_RING(factor)
        if euler_polynomial[0] != 1:
            raise ValueError(
                "An Euler polynomial must have constant coefficient 1."
            )
        characteristic_polynomial = euler_to_characteristic(euler_polynomial)
    elif normalized_convention in {"characteristic", "frobenius"}:
        characteristic_polynomial = CHARACTERISTIC_RING(factor)
        if characteristic_polynomial.leading_coefficient() != 1:
            raise ValueError("A Frobenius characteristic polynomial must be monic.")
        euler_polynomial = characteristic_to_euler(characteristic_polynomial)
    else:
        raise ValueError("convention must be 'euler' or 'characteristic'.")

    if characteristic_polynomial.leading_coefficient() != 1:
        raise ValueError("The resulting characteristic polynomial is not monic.")
    if euler_polynomial[0] != 1:
        raise ValueError("The resulting Euler polynomial is not normalized at T=0.")
    return characteristic_polynomial, euler_polynomial


# ---------------------------------------------------------------------------
# Compact Mestre test functions and archimedean term
# ---------------------------------------------------------------------------


def odlyzko_test_function(x: Any):
    r"""The compact test function used in the original notebook.

    .. math::

        F(x)= (1-|x|)\cos(\pi|x|)+\frac{\sin(\pi|x|)}{\pi}

    for ``|x| <= 1``, and zero outside ``[-1,1]``.
    """
    absolute_x = abs(x)
    if absolute_x > 1:
        return 0
    return (1 - absolute_x) * cos(pi * absolute_x) + sin(pi * absolute_x) / pi


def relevant_primes(lambda_value: Any, *, precision: int = 128) -> List[Any]:
    r"""Return all primes ``p`` satisfying ``log(p) <= lambda``.

    Equivalently, these are the primes ``p <= exp(lambda)``.  The final
    filtering avoids losing a boundary prime because of numerical rounding.
    """
    real_field = RealField(precision)
    lambda_real = real_field(lambda_value)
    if lambda_real <= 0:
        raise ValueError("lambda must be strictly positive.")

    upper_bound = ZZ(floor(exp(lambda_real))) + 2
    return [
        ZZ(p)
        for p in prime_range(upper_bound)
        if log(real_field(p)) <= lambda_real
    ]


def maximum_prime_power_exponent(
    p: Any,
    lambda_value: Any,
    *,
    precision: int = 128,
) -> int:
    r"""Largest integer ``m >= 0`` such that ``m*log(p) <= lambda``."""
    real_field = RealField(precision)
    lambda_real = real_field(lambda_value)
    log_p = log(real_field(p))
    if log_p <= 0:
        raise ValueError("p must be greater than one.")

    m_max = int(floor(lambda_real / log_p))
    # Correct a possible one-unit floating-point error at the boundary.
    while (m_max + 1) * log_p <= lambda_real:
        m_max += 1
    while m_max > 0 and m_max * log_p > lambda_real:
        m_max -= 1
    return m_max


def phi_at_one_half(
    test_function: Callable[[Any], Any],
    *,
    precision: int = 128,
):
    r"""Return ``Phi_F(1/2) = integral_R F(x) dx`` for an even compact ``F``."""
    real_field = RealField(precision)
    integral_value, _ = numerical_integral(
        lambda x: test_function(x),
        0,
        1,
    )
    return 2 * real_field(integral_value)


def mestre_archimedean_term(
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    *,
    precision: int = 128,
):
    r"""Compute the term ``M_{lambda,F}`` in Mestre's exact formula.

    This is the regularized form used in the uploaded notebook:

    .. math::

       M_{\lambda,F}=2\left(\lambda a-F(0)b+F(0)\log(2\pi)\right),

    where

    .. math::

       a=\int_0^1\left(\frac{F(u)e^{-\lambda u}}
       {1-e^{-\lambda u}}-\frac{F(0)e^{-\lambda u}}{\lambda u}\right)du,
       \qquad b=\int_\lambda^\infty \frac{e^{-x}}{x}\,dx.

    The value at ``u=0`` is filled by continuity; for an even differentiable
    test function it is ``F(0)/2``.
    """
    real_field = RealField(precision)
    lambda_real = real_field(lambda_value)
    if lambda_real <= 0:
        raise ValueError("lambda must be strictly positive.")
    f_zero = real_field(test_function(real_field(0)))

    def regularized_integrand(u):
        u_real = real_field(u)
        if u_real == 0:
            return f_zero / 2
        y = lambda_real * u_real
        return (
            real_field(test_function(u_real)) / (exp(y) - 1)
            - f_zero * exp(-y) / y
        )

    a_value, _ = numerical_integral(regularized_integrand, 0, 1)
    b_value, _ = numerical_integral(
        lambda x: exp(-real_field(x)) / real_field(x),
        lambda_real,
        Infinity,
    )
    a_real = real_field(a_value)
    b_real = real_field(b_value)
    return 2 * (
        lambda_real * a_real
        - f_zero * b_real
        + f_zero * log(2 * real_field(pi))
    )


# ---------------------------------------------------------------------------
# Exact Newton sums and local contribution
# ---------------------------------------------------------------------------


def power_sums_of_roots(monic_polynomial: Any, maximum_power: int) -> List[Any]:
    r"""Compute exact root power sums with Newton identities.

    If ``P(X)=prod_i (X-alpha_i)``, the returned list is
    ``[s_0,...,s_M]`` with ``s_m=sum_i alpha_i^m`` and ``s_0=deg(P)``.
    No numerical root approximation is used.
    """
    if maximum_power < 0:
        raise ValueError("maximum_power must be nonnegative.")

    polynomial = CHARACTERISTIC_RING(monic_polynomial)
    if polynomial == 0:
        raise ValueError("The zero polynomial has no usable Newton sums.")
    polynomial = polynomial.monic()
    degree = int(polynomial.degree())

    if degree == 0:
        return [ZZ(0)] * (maximum_power + 1)

    # P(X) = X^d + c_1 X^(d-1) + ... + c_d.
    coefficients = [polynomial[degree - j] for j in range(1, degree + 1)]
    sums = [ZZ(degree)]

    for power in range(1, maximum_power + 1):
        if power <= degree:
            newton_term = sum(
                coefficients[j - 1] * sums[power - j]
                for j in range(1, power)
            )
            newton_term += power * coefficients[power - 1]
        else:
            newton_term = sum(
                coefficients[j - 1] * sums[power - j]
                for j in range(1, degree + 1)
            )
        sums.append(ZZ(-newton_term))

    return sums


def local_mestre_weights(
    p: Any,
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    *,
    precision: int = 128,
) -> List[Any]:
    r"""Weights ``w_m`` such that the local contribution is ``sum b_m w_m``."""
    real_field = RealField(precision)
    lambda_real = real_field(lambda_value)
    p_integer = ZZ(p)
    log_p = log(real_field(p_integer))
    maximum_power = maximum_prime_power_exponent(
        p_integer,
        lambda_real,
        precision=precision,
    )

    weights = [real_field(0)]
    for power in range(1, maximum_power + 1):
        argument = power * log_p / lambda_real
        weights.append(
            log_p
            * real_field(test_function(argument))
            / (real_field(p_integer) ** power)
        )
    return weights


def local_mestre_sum_from_power_sums(
    power_sums: Sequence[Any],
    weights: Sequence[Any],
    *,
    precision: int = 128,
):
    """Evaluate a local sum from exact power sums and precomputed weights."""
    if len(power_sums) != len(weights):
        raise ValueError("power_sums and weights must have the same length.")
    real_field = RealField(precision)
    return sum(
        real_field(power_sums[power]) * real_field(weights[power])
        for power in range(1, len(weights))
    )


def exact_local_mestre_sum(
    p: Any,
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    characteristic_polynomial: Any,
    *,
    precision: int = 128,
):
    r"""Compute the exact local prime sum, without the global factor two."""
    weights = local_mestre_weights(
        p,
        lambda_value,
        test_function,
        precision=precision,
    )
    sums = power_sums_of_roots(characteristic_polynomial, len(weights) - 1)
    return local_mestre_sum_from_power_sums(
        sums,
        weights,
        precision=precision,
    )


# ---------------------------------------------------------------------------
# Local candidate generation and reduction conditions
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LocalFactorCandidate:
    """A candidate Frobenius characteristic polynomial and its provenance.

    ``reduction_signature`` is ``(g_ab, g_toric, g_unipotent)``.  A custom
    provider should supply this signature whenever the search is asked to
    enforce a nontrivial reduction condition.
    """

    characteristic_polynomial: Any
    reduction_signature: Optional[Tuple[int, int, int]] = None
    toric_cyclotomic_indices: Tuple[int, ...] = tuple()
    source: str = "custom"


@dataclass(frozen=True)
class LocalReductionCondition:
    r"""Restriction imposed on the local reduction at one prime.

    Canonical values of ``kind`` are:

    ``"any"``
        No information is imposed; enumerate every structural signature.
    ``"good"``
        Force the signature ``(g, 0, 0)``.
    ``"bad"``
        Exclude the good-reduction signature.
    ``"semistable"``
        Force ``g_unipotent = 0``; good reduction remains allowed.
    ``"semistable_bad"``
        Force ``g_unipotent = 0`` and ``g_toric > 0``.
    ``"non_semistable"``
        Force ``g_unipotent > 0``.
    ``"custom"``
        Use an explicit finite list of local factors.

    Any of the three dimensions may additionally be fixed.  Supplying all
    three is the exact reduction type used in the paper.  Cyclotomic indices
    can be prescribed to fix the toric Frobenius polynomial more precisely.
    """

    kind: str = "any"
    abelian_dimension: Optional[int] = None
    toric_dimension: Optional[int] = None
    unipotent_dimension: Optional[int] = None
    toric_cyclotomic_indices: Optional[Tuple[int, ...]] = None
    custom_factors: Tuple[Any, ...] = tuple()
    factor_convention: str = "euler"
    label: Optional[str] = None


_REDUCTION_KIND_ALIASES = {
    "any": "any",
    "all": "any",
    "all_structural": "any",
    "structural": "any",
    "unknown": "any",
    "unspecified": "any",
    "indifferent": "any",
    "indifferente": "any",
    "good": "good",
    "good_reduction": "good",
    "bonne": "good",
    "bonne_reduction": "good",
    "bad": "bad",
    "bad_reduction": "bad",
    "mauvaise": "bad",
    "mauvaise_reduction": "bad",
    "semistable": "semistable",
    "semi_stable": "semistable",
    "semistable_bad": "semistable_bad",
    "bad_semistable": "semistable_bad",
    "mauvaise_semistable": "semistable_bad",
    "non_semistable": "non_semistable",
    "nonsemistable": "non_semistable",
    "unipotent_bad": "non_semistable",
    "custom": "custom",
    "supplied": "custom",
    "user_supplied": "custom",
}


def _normalized_keyword(value: Any) -> str:
    """Normalize accents, spaces and hyphens in a user-facing keyword."""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(character for character in text if not unicodedata.combining(character))
    text = text.lower().replace("-", " ").replace("/", " ")
    return "_".join(text.split())


def _canonical_reduction_kind(value: Any) -> str:
    token = _normalized_keyword(value)
    try:
        return _REDUCTION_KIND_ALIASES[token]
    except KeyError as exc:
        allowed = sorted(set(_REDUCTION_KIND_ALIASES.values()))
        raise ValueError(
            f"Unknown reduction kind {value!r}. Canonical values are: "
            + ", ".join(allowed)
        ) from exc


def _optional_nonnegative_integer(value: Any, name: str) -> Optional[int]:
    if value is None:
        return None
    integer = int(value)
    if integer < 0:
        raise ValueError(f"{name} must be nonnegative or None.")
    return integer


def normalize_reduction_condition(
    condition: Any,
    dimension: int,
) -> LocalReductionCondition:
    r"""Normalize a string, a type triple, a mapping or a condition object.

    Convenient accepted inputs include::

        "good"
        "bad"
        (1, 1, 0)
        {"kind": "semistable_bad", "toric_dimension": 1}
        {"kind": "custom", "factors": [[1, -1], [1, 1]]}

    A type triple means ``(g_ab, g_toric, g_unipotent)``.
    """
    if dimension < 1:
        raise ValueError("dimension must be a positive integer.")

    if condition is None:
        raw: Dict[str, Any] = {"kind": "any"}
    elif isinstance(condition, LocalReductionCondition):
        raw = {
            "kind": condition.kind,
            "abelian_dimension": condition.abelian_dimension,
            "toric_dimension": condition.toric_dimension,
            "unipotent_dimension": condition.unipotent_dimension,
            "toric_cyclotomic_indices": condition.toric_cyclotomic_indices,
            "custom_factors": condition.custom_factors,
            "factor_convention": condition.factor_convention,
            "label": condition.label,
        }
    elif isinstance(condition, str):
        raw = {"kind": condition}
    elif isinstance(condition, Mapping):
        raw = dict(condition)
    elif isinstance(condition, (tuple, list)) and len(condition) == 3:
        raw = {"signature": tuple(condition)}
    else:
        raise TypeError(
            "A reduction condition must be a string, a length-three signature, "
            "a mapping, LocalReductionCondition, or None."
        )

    signature = raw.get("signature", raw.get("reduction_signature"))
    type_value = raw.get("type")
    if signature is None and isinstance(type_value, (tuple, list)):
        signature = type_value
    if signature is not None:
        if len(signature) != 3:
            raise ValueError("A reduction signature must have exactly three entries.")
        signature = tuple(int(value) for value in signature)
        if any(value < 0 for value in signature):
            raise ValueError("Reduction-signature entries must be nonnegative.")

    abelian_dimension = raw.get(
        "abelian_dimension",
        raw.get("g_ab", raw.get("gab")),
    )
    toric_dimension = raw.get(
        "toric_dimension",
        raw.get("g_m", raw.get("gm")),
    )
    unipotent_dimension = raw.get(
        "unipotent_dimension",
        raw.get("g_u", raw.get("gu")),
    )
    if signature is not None:
        values = (abelian_dimension, toric_dimension, unipotent_dimension)
        for supplied, from_signature, name in zip(
            values,
            signature,
            ("abelian_dimension", "toric_dimension", "unipotent_dimension"),
        ):
            if supplied is not None and int(supplied) != from_signature:
                raise ValueError(f"{name} conflicts with the supplied signature.")
        abelian_dimension, toric_dimension, unipotent_dimension = signature

    abelian_dimension = _optional_nonnegative_integer(
        abelian_dimension, "abelian_dimension"
    )
    toric_dimension = _optional_nonnegative_integer(
        toric_dimension, "toric_dimension"
    )
    unipotent_dimension = _optional_nonnegative_integer(
        unipotent_dimension, "unipotent_dimension"
    )

    raw_indices = raw.get(
        "toric_cyclotomic_indices",
        raw.get("cyclotomic_indices"),
    )
    indices: Optional[Tuple[int, ...]]
    if raw_indices is None:
        indices = None
    else:
        indices = tuple(sorted(int(index) for index in raw_indices))
        if any(index < 1 for index in indices):
            raise ValueError("Cyclotomic indices must be positive integers.")
        implied_toric_dimension = sum(int(euler_phi(index)) for index in indices)
        if toric_dimension is None:
            toric_dimension = implied_toric_dimension
        elif toric_dimension != implied_toric_dimension:
            raise ValueError(
                "toric_dimension does not equal the total degree of the "
                "prescribed cyclotomic factors."
            )

    if "custom_factors" in raw:
        custom_factors_raw = raw["custom_factors"]
        custom_factors = (
            tuple(custom_factors_raw)
            if custom_factors_raw is not None
            else tuple()
        )
    elif "factors" in raw:
        custom_factors_raw = raw["factors"]
        custom_factors = (
            tuple(custom_factors_raw)
            if custom_factors_raw is not None
            else tuple()
        )
    elif "factor" in raw:
        custom_factors = (raw["factor"],)
    else:
        custom_factors = tuple()
    factor_convention = _normalized_keyword(raw.get("factor_convention", "euler"))
    if factor_convention in {"characteristic", "frobenius"}:
        factor_convention = "characteristic"
    elif factor_convention == "euler":
        pass
    else:
        raise ValueError("factor_convention must be 'euler' or 'characteristic'.")

    kind_value = raw.get("kind", raw.get("reduction"))
    if kind_value is None and not isinstance(type_value, (tuple, list)):
        kind_value = type_value
    if kind_value is None:
        if custom_factors:
            kind = "custom"
        elif all(
            value is not None
            for value in (abelian_dimension, toric_dimension, unipotent_dimension)
        ):
            kind = (
                "good"
                if (abelian_dimension, toric_dimension, unipotent_dimension)
                == (dimension, 0, 0)
                else "bad"
            )
        else:
            kind = "any"
    else:
        kind = _canonical_reduction_kind(kind_value)

    dimensions = (abelian_dimension, toric_dimension, unipotent_dimension)
    if any(value is not None and value > dimension for value in dimensions):
        raise ValueError("A reduction dimension cannot exceed g.")
    specified_sum = sum(value for value in dimensions if value is not None)
    if specified_sum > dimension:
        raise ValueError("The specified reduction dimensions have sum greater than g.")
    if all(value is not None for value in dimensions) and specified_sum != dimension:
        raise ValueError("An exact reduction signature must have sum g.")

    if kind == "good":
        required = (dimension, 0, 0)
        for supplied, expected, name in zip(
            dimensions,
            required,
            ("abelian_dimension", "toric_dimension", "unipotent_dimension"),
        ):
            if supplied is not None and supplied != expected:
                raise ValueError(f"A good-reduction condition requires {name}={expected}.")
    elif kind == "bad":
        if dimensions == (dimension, 0, 0):
            raise ValueError("The exact good-reduction signature is incompatible with kind='bad'.")
    elif kind == "semistable":
        if unipotent_dimension is not None and unipotent_dimension != 0:
            raise ValueError("Semistable reduction requires unipotent_dimension=0.")
    elif kind == "semistable_bad":
        if unipotent_dimension is not None and unipotent_dimension != 0:
            raise ValueError("Semistable bad reduction requires unipotent_dimension=0.")
        if toric_dimension is not None and toric_dimension == 0:
            raise ValueError("Semistable bad reduction requires positive toric dimension.")
    elif kind == "non_semistable":
        if unipotent_dimension is not None and unipotent_dimension == 0:
            raise ValueError("Non-semistable reduction requires positive unipotent dimension.")
    elif kind == "custom":
        if not custom_factors:
            raise ValueError("kind='custom' requires a nonempty 'factors' list.")
    if kind != "custom" and custom_factors:
        raise ValueError("Explicit factors are only accepted with kind='custom'.")

    label = raw.get("label")
    return LocalReductionCondition(
        kind=kind,
        abelian_dimension=abelian_dimension,
        toric_dimension=toric_dimension,
        unipotent_dimension=unipotent_dimension,
        toric_cyclotomic_indices=indices,
        custom_factors=custom_factors,
        factor_convention=factor_convention,
        label=str(label) if label is not None else None,
    )


def reduction_condition_to_dict(
    condition: LocalReductionCondition,
) -> Dict[str, Any]:
    """Return JSON-compatible condition metadata.

    Custom factors themselves are stored in the per-prime candidate file; the
    manifest records their count and convention.
    """
    return {
        "kind": condition.kind,
        "abelian_dimension": condition.abelian_dimension,
        "toric_dimension": condition.toric_dimension,
        "unipotent_dimension": condition.unipotent_dimension,
        "toric_cyclotomic_indices": (
            list(condition.toric_cyclotomic_indices)
            if condition.toric_cyclotomic_indices is not None
            else None
        ),
        "custom_factor_count": len(condition.custom_factors),
        "factor_convention": condition.factor_convention,
        "label": condition.label,
    }


def reduction_condition_from_dict(
    payload: Mapping[str, Any],
) -> LocalReductionCondition:
    """Restore condition metadata from a candidate-cache manifest."""
    indices = payload.get("toric_cyclotomic_indices")
    return LocalReductionCondition(
        kind=str(payload.get("kind", "any")),
        abelian_dimension=(
            int(payload["abelian_dimension"])
            if payload.get("abelian_dimension") is not None
            else None
        ),
        toric_dimension=(
            int(payload["toric_dimension"])
            if payload.get("toric_dimension") is not None
            else None
        ),
        unipotent_dimension=(
            int(payload["unipotent_dimension"])
            if payload.get("unipotent_dimension") is not None
            else None
        ),
        toric_cyclotomic_indices=(
            tuple(int(index) for index in indices) if indices is not None else None
        ),
        custom_factors=tuple(),
        factor_convention=str(payload.get("factor_convention", "euler")),
        label=(str(payload["label"]) if payload.get("label") is not None else None),
    )


def reduction_condition_for_prime(
    p: Any,
    dimension: int,
    reduction_conditions: Optional[Mapping[int, Any]] = None,
    default_reduction: Any = "any",
) -> LocalReductionCondition:
    """Resolve and normalize the condition applying at ``p``."""
    p_integer = int(ZZ(p))
    raw_condition = default_reduction
    if reduction_conditions is not None and p_integer in reduction_conditions:
        raw_condition = reduction_conditions[p_integer]
    return normalize_reduction_condition(raw_condition, dimension)


def allowed_reduction_signatures(
    dimension: int,
    condition: Any = "any",
) -> List[Tuple[int, int, int]]:
    r"""List all ``(g_ab,g_toric,g_unipotent)`` allowed by a condition."""
    normalized = normalize_reduction_condition(condition, dimension)
    if normalized.kind == "custom":
        return []

    signatures: List[Tuple[int, int, int]] = []
    for abelian_dimension in range(dimension + 1):
        for toric_dimension in range(dimension - abelian_dimension + 1):
            unipotent_dimension = dimension - abelian_dimension - toric_dimension

            if normalized.kind == "good" and (toric_dimension != 0 or unipotent_dimension != 0):
                continue
            if normalized.kind == "bad" and toric_dimension == 0 and unipotent_dimension == 0:
                continue
            if normalized.kind == "semistable" and unipotent_dimension != 0:
                continue
            if normalized.kind == "semistable_bad" and not (
                unipotent_dimension == 0 and toric_dimension > 0
            ):
                continue
            if normalized.kind == "non_semistable" and unipotent_dimension == 0:
                continue

            if (
                normalized.abelian_dimension is not None
                and abelian_dimension != normalized.abelian_dimension
            ):
                continue
            if (
                normalized.toric_dimension is not None
                and toric_dimension != normalized.toric_dimension
            ):
                continue
            if (
                normalized.unipotent_dimension is not None
                and unipotent_dimension != normalized.unipotent_dimension
            ):
                continue
            signatures.append(
                (abelian_dimension, toric_dimension, unipotent_dimension)
            )

    if not signatures:
        raise ValueError(
            "The reduction condition admits no signature in dimension "
            f"g={dimension}: {reduction_condition_to_dict(normalized)}"
        )
    return signatures


def good_reduction_candidates(p: Any, dimension: int) -> Iterator[LocalFactorCandidate]:
    r"""Enumerate degree ``2g`` monic ``p``-Weil polynomials using SageMath."""
    if dimension < 0:
        raise ValueError("dimension must be nonnegative.")
    if dimension == 0:
        yield LocalFactorCandidate(
            CHARACTERISTIC_RING.one(),
            reduction_signature=(0, 0, 0),
            source="trivial",
        )
        return

    for polynomial in CHARACTERISTIC_RING.weil_polynomials(2 * dimension, ZZ(p)):
        yield LocalFactorCandidate(
            CHARACTERISTIC_RING(polynomial),
            reduction_signature=(dimension, 0, 0),
            source="sage.weil_polynomials",
        )


def cyclotomic_indices_with_degree_at_most(maximum_degree: int) -> List[int]:
    r"""Return all ``n`` such that ``phi(n) <= maximum_degree``.

    The finite search bound ``n <= 2*maximum_degree^2`` follows from
    ``phi(n)^2 >= n/2``.
    """
    if maximum_degree < 0:
        raise ValueError("maximum_degree must be nonnegative.")
    if maximum_degree == 0:
        return []
    search_bound = 2 * maximum_degree * maximum_degree
    return [
        n
        for n in range(1, search_bound + 1)
        if int(euler_phi(n)) <= maximum_degree
    ]


def toric_characteristic_polynomial_from_indices(
    indices: Sequence[int],
):
    """Return the product of the requested cyclotomic polynomials."""
    polynomial = CHARACTERISTIC_RING.one()
    for index in indices:
        index_integer = int(index)
        if index_integer < 1:
            raise ValueError("Cyclotomic indices must be positive integers.")
        polynomial *= CHARACTERISTIC_RING(cyclotomic_polynomial(index_integer))
    return polynomial


def toric_characteristic_polynomials(
    toric_dimension: int,
) -> Iterator[Tuple[Any, Tuple[int, ...]]]:
    r"""Enumerate products of cyclotomic polynomials of total degree ``t``."""
    if toric_dimension < 0:
        raise ValueError("toric_dimension must be nonnegative.")
    if toric_dimension == 0:
        yield CHARACTERISTIC_RING.one(), tuple()
        return

    indices = cyclotomic_indices_with_degree_at_most(toric_dimension)
    degrees = [int(euler_phi(index)) for index in indices]

    def recurse(
        remaining_degree: int,
        first_position: int,
        current_polynomial: Any,
        selected_indices: Tuple[int, ...],
    ):
        if remaining_degree == 0:
            yield current_polynomial, selected_indices
            return
        for position in range(first_position, len(indices)):
            degree = degrees[position]
            if degree > remaining_degree:
                continue
            index = indices[position]
            factor = CHARACTERISTIC_RING(cyclotomic_polynomial(index))
            yield from recurse(
                remaining_degree - degree,
                position,
                current_polynomial * factor,
                selected_indices + (index,),
            )

    yield from recurse(
        toric_dimension,
        0,
        CHARACTERISTIC_RING.one(),
        tuple(),
    )


def structural_local_candidates(
    p: Any,
    dimension: int,
    condition: Any = "any",
) -> Iterator[LocalFactorCandidate]:
    r"""Enumerate structural factors satisfying a local reduction condition.

    For each allowed decomposition

    ``g_abelian + g_toric + g_unipotent = g``,

    this combines a ``p``-Weil polynomial of degree ``2*g_abelian`` with a
    product of cyclotomic polynomials of degree ``g_toric``.  The unipotent
    part contributes the trivial factor.
    """
    normalized = normalize_reduction_condition(condition, dimension)
    if normalized.kind == "custom":
        raise ValueError("Use custom_local_factor_candidates for kind='custom'.")

    signatures = allowed_reduction_signatures(dimension, normalized)
    signatures_by_abelian_dimension: Dict[int, List[Tuple[int, int]]] = {}
    for abelian_dimension, toric_dimension, unipotent_dimension in signatures:
        signatures_by_abelian_dimension.setdefault(abelian_dimension, []).append(
            (toric_dimension, unipotent_dimension)
        )

    p_integer = ZZ(p)
    for abelian_dimension, toric_unipotent_pairs in sorted(
        signatures_by_abelian_dimension.items()
    ):
        if abelian_dimension == 0:
            abelian_candidates = [CHARACTERISTIC_RING.one()]
        else:
            # Sage currently materializes this finite list internally.  We keep
            # one copy per abelian dimension and reuse it for all compatible
            # toric/unipotent signatures.
            abelian_candidates = CHARACTERISTIC_RING.weil_polynomials(
                2 * abelian_dimension,
                p_integer,
            )

        for toric_dimension, unipotent_dimension in sorted(toric_unipotent_pairs):
            if normalized.toric_cyclotomic_indices is not None:
                indices = normalized.toric_cyclotomic_indices
                toric_candidates = [
                    (toric_characteristic_polynomial_from_indices(indices), indices)
                ]
            else:
                toric_candidates = toric_characteristic_polynomials(toric_dimension)

            for toric_polynomial, indices in toric_candidates:
                if int(toric_polynomial.degree()) != toric_dimension:
                    raise RuntimeError(
                        "Internal error: toric polynomial degree does not match "
                        "the reduction signature."
                    )
                for abelian_polynomial in abelian_candidates:
                    yield LocalFactorCandidate(
                        CHARACTERISTIC_RING(abelian_polynomial) * toric_polynomial,
                        reduction_signature=(
                            abelian_dimension,
                            toric_dimension,
                            unipotent_dimension,
                        ),
                        toric_cyclotomic_indices=tuple(indices),
                        source="proposition_4_1_structural_superset",
                    )


def all_structural_local_candidates(
    p: Any,
    dimension: int,
) -> Iterator[LocalFactorCandidate]:
    """Backward-compatible wrapper for unrestricted structural enumeration."""
    yield from structural_local_candidates(p, dimension, "any")


def custom_local_factor_candidates(
    p: Any,
    dimension: int,
    condition: Any,
) -> Iterator[LocalFactorCandidate]:
    """Convert explicit factors in a ``kind='custom'`` condition."""
    normalized = normalize_reduction_condition(condition, dimension)
    if normalized.kind != "custom":
        raise ValueError("The condition must have kind='custom'.")

    complete_signature: Optional[Tuple[int, int, int]] = None
    dimensions = (
        normalized.abelian_dimension,
        normalized.toric_dimension,
        normalized.unipotent_dimension,
    )
    if all(value is not None for value in dimensions):
        complete_signature = tuple(int(value) for value in dimensions)  # type: ignore[arg-type]

    for factor in normalized.custom_factors:
        characteristic_polynomial, _ = coerce_local_factor(
            factor,
            convention=normalized.factor_convention,
        )
        candidate = LocalFactorCandidate(
            characteristic_polynomial=characteristic_polynomial,
            reduction_signature=complete_signature,
            toric_cyclotomic_indices=(
                normalized.toric_cyclotomic_indices or tuple()
            ),
            source="user_supplied_reduction_condition",
        )
        validate_local_factor_candidate(p, candidate, dimension)
        yield candidate


def local_candidates_for_condition(
    p: Any,
    dimension: int,
    condition: Any,
) -> Iterator[LocalFactorCandidate]:
    """Dispatch to the appropriate built-in local candidate generator."""
    normalized = normalize_reduction_condition(condition, dimension)
    if normalized.kind == "custom":
        yield from custom_local_factor_candidates(p, dimension, normalized)
    elif (
        normalized.kind == "good"
        and normalized.abelian_dimension in {None, dimension}
        and normalized.toric_dimension in {None, 0}
        and normalized.unipotent_dimension in {None, 0}
        and normalized.toric_cyclotomic_indices is None
    ):
        yield from good_reduction_candidates(p, dimension)
    else:
        yield from structural_local_candidates(p, dimension, normalized)


def validate_local_factor_candidate(
    p: Any,
    candidate: LocalFactorCandidate,
    dimension: int,
) -> None:
    r"""Validate degree and reduction metadata for one local candidate.

    A factor attached to a signature ``(g_ab,g_toric,g_unipotent)`` must have
    characteristic degree ``2*g_ab + g_toric``.  The unipotent part contributes
    no Euler factor.  This check is especially useful for custom providers.
    """
    if dimension < 0:
        raise ValueError("dimension must be nonnegative.")

    characteristic_polynomial = CHARACTERISTIC_RING(
        candidate.characteristic_polynomial
    )
    if characteristic_polynomial.leading_coefficient() != 1:
        raise ValueError(
            f"Candidate at p={p} is not monic: {characteristic_polynomial}"
        )
    degree = int(characteristic_polynomial.degree())
    if degree > 2 * dimension:
        raise ValueError(
            f"Candidate at p={p} has degree {degree}, greater than 2g={2*dimension}."
        )

    signature = candidate.reduction_signature
    if signature is None:
        return
    if len(signature) != 3:
        raise ValueError(
            f"Candidate at p={p} has a reduction signature of length other than 3."
        )
    abelian_dimension, toric_dimension, unipotent_dimension = (
        int(value) for value in signature
    )
    if (
        abelian_dimension < 0
        or toric_dimension < 0
        or unipotent_dimension < 0
        or abelian_dimension + toric_dimension + unipotent_dimension != dimension
    ):
        raise ValueError(
            f"Candidate at p={p} has invalid reduction signature {signature} "
            f"for g={dimension}."
        )

    expected_degree = 2 * abelian_dimension + toric_dimension
    if degree != expected_degree:
        raise ValueError(
            f"Candidate at p={p} has degree {degree}, but signature {signature} "
            f"requires degree {expected_degree}."
        )

    if candidate.toric_cyclotomic_indices:
        toric_degree = sum(
            int(euler_phi(index))
            for index in candidate.toric_cyclotomic_indices
        )
        if toric_degree != toric_dimension:
            raise ValueError(
                f"Candidate at p={p} has cyclotomic degree {toric_degree}, "
                f"but signature {signature} has toric dimension {toric_dimension}."
            )


def candidate_matches_reduction_condition(
    candidate: LocalFactorCandidate,
    condition: LocalReductionCondition,
    dimension: int,
    *,
    require_signature_for_restricted_condition: bool = True,
) -> bool:
    """Test a candidate against a normalized condition.

    This is mainly used to filter custom providers.  Built-in generators
    already construct only admissible signatures.
    """
    has_signature_restriction = (
        condition.kind not in {"any", "custom"}
        or condition.abelian_dimension is not None
        or condition.toric_dimension is not None
        or condition.unipotent_dimension is not None
        or condition.toric_cyclotomic_indices is not None
    )
    signature = candidate.reduction_signature
    if signature is None:
        if has_signature_restriction and require_signature_for_restricted_condition:
            raise ValueError(
                "A custom candidate provider must attach reduction_signature="
                "(g_ab,g_toric,g_unipotent) when reduction conditions are imposed."
            )
        return not has_signature_restriction

    abelian_dimension, toric_dimension, unipotent_dimension = (
        int(value) for value in signature
    )
    if (
        abelian_dimension < 0
        or toric_dimension < 0
        or unipotent_dimension < 0
        or abelian_dimension + toric_dimension + unipotent_dimension != dimension
    ):
        raise ValueError(
            "A candidate provider returned an invalid reduction signature: "
            f"{signature} for g={dimension}."
        )

    if condition.kind == "good" and (toric_dimension != 0 or unipotent_dimension != 0):
        return False
    if condition.kind == "bad" and toric_dimension == 0 and unipotent_dimension == 0:
        return False
    if condition.kind == "semistable" and unipotent_dimension != 0:
        return False
    if condition.kind == "semistable_bad" and not (
        unipotent_dimension == 0 and toric_dimension > 0
    ):
        return False
    if condition.kind == "non_semistable" and unipotent_dimension == 0:
        return False

    if (
        condition.abelian_dimension is not None
        and abelian_dimension != condition.abelian_dimension
    ):
        return False
    if (
        condition.toric_dimension is not None
        and toric_dimension != condition.toric_dimension
    ):
        return False
    if (
        condition.unipotent_dimension is not None
        and unipotent_dimension != condition.unipotent_dimension
    ):
        return False
    if (
        condition.toric_cyclotomic_indices is not None
        and tuple(sorted(candidate.toric_cyclotomic_indices))
        != tuple(condition.toric_cyclotomic_indices)
    ):
        return False
    return True

def candidate_provider_from_mode(
    mode: str,
) -> Callable[[Any, int], Iterable[LocalFactorCandidate]]:
    """Resolve the two legacy candidate modes."""
    normalized_mode = _normalized_keyword(mode)
    if normalized_mode in {"good", "good_reduction"}:
        return good_reduction_candidates
    if normalized_mode in {"all", "all_structural", "structural"}:
        return all_structural_local_candidates
    raise ValueError(
        "candidate_mode must be 'good' or 'all_structural', "
        "unless a custom candidate_provider is supplied."
    )


def default_reduction_from_candidate_mode(
    candidate_mode: str,
    *,
    custom_provider_supplied: bool = False,
) -> str:
    """Translate the legacy mode into the new default-reduction interface."""
    normalized_mode = _normalized_keyword(candidate_mode)
    if normalized_mode in {"good", "good_reduction"}:
        return "good"
    if normalized_mode in {"all", "all_structural", "structural"}:
        return "any"
    if custom_provider_supplied:
        return "any"
    raise ValueError(
        "Unknown candidate_mode. Use 'good' or 'all_structural', or supply "
        "candidate_provider."
    )


# ---------------------------------------------------------------------------
# Result objects
# ---------------------------------------------------------------------------


@dataclass
class CandidateEvaluation:
    """Exact data and weighted Mestre sum for one local factor candidate."""

    p: int
    characteristic_polynomial: Any
    euler_polynomial: Any
    power_sums: Tuple[Any, ...]
    local_sum: Any
    reduction_signature: Optional[Tuple[int, int, int]] = None
    toric_cyclotomic_indices: Tuple[int, ...] = tuple()
    source: str = "custom"

    def compact_dict(self) -> Dict[str, Any]:
        return {
            "p": self.p,
            "characteristic_coefficients": list(
                polynomial_coefficients(self.characteristic_polynomial)
            ),
            "euler_coefficients": list(polynomial_coefficients(self.euler_polynomial)),
            "power_sums": [int(value) for value in self.power_sums],
            "local_sum": str(self.local_sum),
            "reduction_signature": (
                list(self.reduction_signature)
                if self.reduction_signature is not None
                else None
            ),
            "toric_cyclotomic_indices": list(self.toric_cyclotomic_indices),
            "source": self.source,
        }


@dataclass
class PrimeSearchResult:
    """Admissible-candidate count and minimizer at one prime."""

    p: int
    maximum_power: int
    candidate_count: int
    minimum: CandidateEvaluation
    reduction_condition: LocalReductionCondition = field(
        default_factory=LocalReductionCondition
    )
    rejected_candidate_count: int = 0
    all_candidates: Optional[List[CandidateEvaluation]] = None


@dataclass
class PartialLFunction:
    r"""A finite Euler product ``prod_p P_p(p^{-s})^{-1}``."""

    dimension: int
    lambda_value: Any
    euler_factors: Dict[int, Any]
    characteristic_polynomials: Dict[int, Any]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def local_euler_factor(self, p: int):
        return self.euler_factors[int(p)]

    def formal_euler_product(self) -> str:
        pieces = [
            f"({self.euler_factors[p]})^(-1) at T={p}^(-s)"
            for p in sorted(self.euler_factors)
        ]
        return " * ".join(pieces) if pieces else "1"

    def value(self, s: Any, *, precision: int = 128):
        """Numerically evaluate the finite Euler product at ``s``."""
        complex_field = ComplexField(precision)
        s_complex = complex_field(s)
        value = complex_field(1)
        for p, polynomial in sorted(self.euler_factors.items()):
            argument = complex_field(p) ** (-s_complex)
            value /= complex_field(polynomial(argument))
        return value


@dataclass
class MestreBoundResult:
    """Global conductor bound together with all selected local information."""

    lambda_value: Any
    dimension: int
    analytic_rank: int
    phi_at_half: Any
    archimedean_term: Any
    local_sum_without_factor_two: Any
    log_conductor_lower_bound: Any
    conductor_lower_bound: Any
    partial_l_function: PartialLFunction
    prime_results: Dict[int, PrimeSearchResult]
    candidate_mode: str
    precision: int
    cache_directory: Optional[str] = None

    def summary(self) -> str:
        condition_counts: Dict[str, int] = {}
        for prime_result in self.prime_results.values():
            kind = prime_result.reduction_condition.kind
            condition_counts[kind] = condition_counts.get(kind, 0) + 1
        condition_summary = ", ".join(
            f"{kind}:{count}" for kind, count in sorted(condition_counts.items())
        ) or "none"

        lines = [
            f"dimension g             : {self.dimension}",
            f"analytic rank r         : {self.analytic_rank}",
            f"lambda                  : {self.lambda_value}",
            f"number of primes        : {len(self.prime_results)}",
            f"reduction conditions    : {condition_summary}",
            f"local sum (before x2)   : {self.local_sum_without_factor_two}",
            f"M_lambda,F              : {self.archimedean_term}",
            f"log(N) lower bound      : {self.log_conductor_lower_bound}",
            f"N lower bound           : {self.conductor_lower_bound}",
            f"candidate mode          : {self.candidate_mode}",
        ]
        if self.cache_directory:
            lines.append(f"candidate cache         : {self.cache_directory}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Shared evaluation helpers
# ---------------------------------------------------------------------------


def _candidate_evaluation(
    p: Any,
    candidate: LocalFactorCandidate,
    weights: Sequence[Any],
    *,
    precision: int,
) -> CandidateEvaluation:
    characteristic_polynomial = CHARACTERISTIC_RING(
        candidate.characteristic_polynomial
    )
    if characteristic_polynomial.leading_coefficient() != 1:
        raise ValueError(
            f"Candidate at p={p} is not monic: {characteristic_polynomial}"
        )
    power_sums = tuple(
        power_sums_of_roots(characteristic_polynomial, len(weights) - 1)
    )
    local_sum = local_mestre_sum_from_power_sums(
        power_sums,
        weights,
        precision=precision,
    )
    return CandidateEvaluation(
        p=int(p),
        characteristic_polynomial=characteristic_polynomial,
        euler_polynomial=characteristic_to_euler(characteristic_polynomial),
        power_sums=power_sums,
        local_sum=local_sum,
        reduction_signature=candidate.reduction_signature,
        toric_cyclotomic_indices=candidate.toric_cyclotomic_indices,
        source=candidate.source,
    )


def _build_bound_result(
    *,
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    dimension: int,
    analytic_rank: int,
    prime_results: Dict[int, PrimeSearchResult],
    candidate_mode: str,
    precision: int,
    cache_directory: Optional[str] = None,
) -> MestreBoundResult:
    real_field = RealField(precision)
    lambda_real = real_field(lambda_value)
    phi_value = phi_at_one_half(test_function, precision=precision)
    archimedean_value = mestre_archimedean_term(
        lambda_real,
        test_function,
        precision=precision,
    )
    local_total = sum(
        (result.minimum.local_sum for result in prime_results.values()),
        real_field(0),
    )
    log_bound = (
        lambda_real * analytic_rank * phi_value
        + 2 * local_total
        + dimension * archimedean_value
    )
    conductor_bound = exp(log_bound)

    supplied_factor_mode = candidate_mode == "user_supplied" or (
        candidate_mode.endswith(":user_supplied")
    )

    partial_l_function = PartialLFunction(
        dimension=dimension,
        lambda_value=lambda_real,
        euler_factors={
            p: result.minimum.euler_polynomial
            for p, result in prime_results.items()
        },
        characteristic_polynomials={
            p: result.minimum.characteristic_polynomial
            for p, result in prime_results.items()
        },
        metadata={
            "candidate_mode": candidate_mode,
            "analytic_rank": analytic_rank,
            "truncated_euler_product": True,
            "independent_local_minimizers": not supplied_factor_mode,
            "global_realizability_not_checked": not supplied_factor_mode,
            "reduction_conditions": {
                p: reduction_condition_to_dict(result.reduction_condition)
                for p, result in prime_results.items()
            },
        },
    )

    return MestreBoundResult(
        lambda_value=lambda_real,
        dimension=dimension,
        analytic_rank=analytic_rank,
        phi_at_half=phi_value,
        archimedean_term=archimedean_value,
        local_sum_without_factor_two=local_total,
        log_conductor_lower_bound=log_bound,
        conductor_lower_bound=conductor_bound,
        partial_l_function=partial_l_function,
        prime_results=prime_results,
        candidate_mode=candidate_mode,
        precision=precision,
        cache_directory=cache_directory,
    )


# ---------------------------------------------------------------------------
# Evaluation of a user-supplied truncated L-function
# ---------------------------------------------------------------------------


def evaluate_truncated_l_function(
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    dimension: int,
    local_factors: Mapping[int, Any],
    *,
    analytic_rank: int = 0,
    factor_convention: str = "euler",
    require_all_relevant_primes: bool = True,
    precision: int = 128,
) -> MestreBoundResult:
    r"""Evaluate the exact conductor lower bound for supplied local factors.

    Parameters
    ----------
    lambda_value:
        Positive real ``lambda``.  Only factors with ``p^m <= exp(lambda)``
        enter the formula.
    test_function:
        A compact Mestre test function supported in ``[-1,1]``.
    dimension:
        Dimension ``g`` of the abelian variety.
    local_factors:
        Mapping ``p -> P_p(T)`` by default.  A coefficient list is in
        increasing degree order.  Use ``factor_convention='characteristic'``
        for ``chi_p(X)`` instead.
    analytic_rank:
        The exact formula contains ``lambda*r*Phi_F(1/2)``.  It defaults to
        zero because the requested minimization has inputs ``lambda,F,g``.
    """
    if dimension < 1:
        raise ValueError("dimension must be a positive integer.")
    if analytic_rank < 0:
        raise ValueError("analytic_rank must be nonnegative.")

    primes = relevant_primes(lambda_value, precision=precision)
    missing_primes = [int(p) for p in primes if int(p) not in local_factors]
    if missing_primes and require_all_relevant_primes:
        raise ValueError(
            "Missing local factors for relevant primes: "
            + ", ".join(map(str, missing_primes))
        )

    prime_results: Dict[int, PrimeSearchResult] = {}
    for p in primes:
        p_int = int(p)
        if p_int not in local_factors:
            continue
        characteristic_polynomial, _ = coerce_local_factor(
            local_factors[p_int],
            convention=factor_convention,
        )
        if characteristic_polynomial.degree() > 2 * dimension:
            raise ValueError(
                f"The factor at p={p_int} has degree "
                f"{characteristic_polynomial.degree()}, greater than 2g={2*dimension}."
            )
        weights = local_mestre_weights(
            p,
            lambda_value,
            test_function,
            precision=precision,
        )
        candidate = LocalFactorCandidate(
            characteristic_polynomial,
            source="user_supplied_truncated_L_function",
        )
        validate_local_factor_candidate(p, candidate, dimension)
        evaluation = _candidate_evaluation(
            p,
            candidate,
            weights,
            precision=precision,
        )
        prime_results[p_int] = PrimeSearchResult(
            p=p_int,
            maximum_power=len(weights) - 1,
            candidate_count=1,
            minimum=evaluation,
            reduction_condition=LocalReductionCondition(
                kind="custom",
                label="user-supplied local factor",
            ),
            all_candidates=[evaluation],
        )

    return _build_bound_result(
        lambda_value=lambda_value,
        test_function=test_function,
        dimension=dimension,
        analytic_rank=analytic_rank,
        prime_results=prime_results,
        candidate_mode="user_supplied",
        precision=precision,
    )


# ---------------------------------------------------------------------------
# Exhaustive local minimization
# ---------------------------------------------------------------------------


def _prepare_cache_directory(
    cache_directory: Path,
    *,
    overwrite: bool,
) -> None:
    if cache_directory.exists() and any(cache_directory.iterdir()):
        if not overwrite:
            raise FileExistsError(
                f"Cache directory is not empty: {cache_directory}. "
                "Pass overwrite_cache=True to replace it."
            )
        shutil.rmtree(cache_directory)
    cache_directory.mkdir(parents=True, exist_ok=True)


def search_minimal_local_factors(
    lambda_value: Any,
    test_function: Callable[[Any], Any],
    dimension: int,
    *,
    analytic_rank: int = 0,
    candidate_mode: str = "all_structural",
    reduction_conditions: Optional[Mapping[int, Any]] = None,
    default_reduction: Optional[Any] = None,
    candidate_provider: Optional[
        Callable[[Any, int], Iterable[LocalFactorCandidate]]
    ] = None,
    keep_all_candidates: bool = False,
    cache_directory: Optional[Any] = None,
    overwrite_cache: bool = False,
    max_candidates_per_prime: Optional[int] = None,
    precision: int = 128,
    verbose: bool = True,
) -> MestreBoundResult:
    r"""Minimize the exact formula independently at every relevant prime.

    ``reduction_conditions`` is a mapping ``p -> condition``.  The simplest
    conditions are the strings ``"good"``, ``"bad"`` and ``"any"``.  One may
    instead give an exact type ``(g_ab,g_toric,g_unipotent)`` or a mapping such
    as ``{"kind": "semistable_bad", "toric_dimension": 1}``.

    ``default_reduction`` applies to every relevant prime not listed in the
    mapping.  Setting ``default_reduction="good"`` asserts that the list of bad
    primes in the relevant range is exhaustive.  With only partial information,
    use ``default_reduction="any"`` and mark the primes known to be bad.  For
    backward compatibility, when it is
    omitted, ``candidate_mode="good"`` means a good default and
    ``candidate_mode="all_structural"`` means an unrestricted default.

    The local choices minimize the sum over the Cartesian product of the local
    candidate sets.  The resulting finite Euler product is formal: independent
    local minimizers need not globalize to one abelian variety.

    ``keep_all_candidates=True`` retains every evaluation in memory.
    ``cache_directory=...`` writes gzip JSONL candidate files containing the
    exact Newton sums, allowing reweighting at the same ``lambda`` without
    rerunning the Weil-polynomial enumeration.
    """
    if dimension < 1:
        raise ValueError("dimension must be a positive integer.")
    if analytic_rank < 0:
        raise ValueError("analytic_rank must be nonnegative.")
    if max_candidates_per_prime is not None and max_candidates_per_prime < 1:
        raise ValueError("max_candidates_per_prime must be positive or None.")

    if default_reduction is None:
        default_reduction = default_reduction_from_candidate_mode(
            candidate_mode,
            custom_provider_supplied=candidate_provider is not None,
        )
    normalized_default = normalize_reduction_condition(
        default_reduction,
        dimension,
    )

    normalized_explicit_conditions: Dict[int, LocalReductionCondition] = {}
    if reduction_conditions is not None:
        for raw_prime, raw_condition in reduction_conditions.items():
            prime_integer = int(ZZ(raw_prime))
            if not ZZ(prime_integer).is_prime():
                raise ValueError(
                    f"A reduction condition was supplied for non-prime {raw_prime!r}."
                )
            if prime_integer in normalized_explicit_conditions:
                raise ValueError(
                    f"Duplicate reduction condition after normalizing p={prime_integer}."
                )
            normalized_explicit_conditions[prime_integer] = (
                normalize_reduction_condition(raw_condition, dimension)
            )

    primes = relevant_primes(lambda_value, precision=precision)
    relevant_prime_integers = {int(p) for p in primes}
    ignored_condition_primes = sorted(
        set(normalized_explicit_conditions) - relevant_prime_integers
    )
    if ignored_condition_primes and verbose:
        suffix = (
            " They are recorded in the cache manifest."
            if cache_directory is not None
            else ""
        )
        print(
            "Reduction conditions outside p <= exp(lambda) are not evaluated: "
            + ", ".join(map(str, ignored_condition_primes))
            + suffix
        )

    cache_path = Path(cache_directory) if cache_directory is not None else None
    if cache_path is not None:
        _prepare_cache_directory(cache_path, overwrite=overwrite_cache)

    manifest: Dict[str, Any] = {
        "format": "mestre-local-candidate-cache",
        "format_version": 2,
        "lambda": str(RealField(precision)(lambda_value)),
        "dimension": int(dimension),
        "analytic_rank_at_creation": int(analytic_rank),
        "candidate_mode": candidate_mode,
        "default_reduction_condition": reduction_condition_to_dict(
            normalized_default
        ),
        "explicit_reduction_conditions": {
            str(p): reduction_condition_to_dict(condition)
            for p, condition in sorted(normalized_explicit_conditions.items())
        },
        "ignored_condition_primes": ignored_condition_primes,
        "precision_at_creation": int(precision),
        "primes": [int(p) for p in primes],
        "prime_files": {},
        "description": (
            "Each line stores one local characteristic polynomial, its Euler "
            "polynomial, and exact Newton power sums up to floor(lambda/log(p))."
        ),
    }

    prime_results: Dict[int, PrimeSearchResult] = {}

    for p in primes:
        p_int = int(p)
        condition = normalized_explicit_conditions.get(
            p_int,
            normalized_default,
        )
        weights = local_mestre_weights(
            p,
            lambda_value,
            test_function,
            precision=precision,
        )
        all_evaluations: Optional[List[CandidateEvaluation]] = (
            [] if keep_all_candidates else None
        )
        best_evaluation: Optional[CandidateEvaluation] = None
        candidate_count = 0
        rejected_candidate_count = 0

        cache_file = None
        cache_handle = None
        if cache_path is not None:
            cache_file = cache_path / f"prime_{p_int}.jsonl.gz"
            cache_handle = gzip.open(cache_file, "wt", encoding="utf-8")

        if condition.kind == "custom":
            candidate_iterator: Iterable[Any] = custom_local_factor_candidates(
                p,
                dimension,
                condition,
            )
            should_filter_provider = False
        elif candidate_provider is None:
            candidate_iterator = local_candidates_for_condition(
                p,
                dimension,
                condition,
            )
            should_filter_provider = False
        else:
            candidate_iterator = candidate_provider(p, dimension)
            should_filter_provider = True

        try:
            for raw_candidate in candidate_iterator:
                if isinstance(raw_candidate, LocalFactorCandidate):
                    candidate = raw_candidate
                else:
                    candidate = LocalFactorCandidate(raw_candidate)

                validate_local_factor_candidate(p, candidate, dimension)

                if should_filter_provider and not candidate_matches_reduction_condition(
                    candidate,
                    condition,
                    dimension,
                ):
                    rejected_candidate_count += 1
                    continue

                candidate_count += 1
                if (
                    max_candidates_per_prime is not None
                    and candidate_count > max_candidates_per_prime
                ):
                    raise RuntimeError(
                        f"More than {max_candidates_per_prime} admissible candidates "
                        f"at p={p_int}. The search was stopped rather than silently "
                        "truncated."
                    )

                evaluation = _candidate_evaluation(
                    p,
                    candidate,
                    weights,
                    precision=precision,
                )
                if all_evaluations is not None:
                    all_evaluations.append(evaluation)
                if cache_handle is not None:
                    cache_handle.write(
                        json.dumps(evaluation.compact_dict(), sort_keys=True)
                        + "\n"
                    )
                if (
                    best_evaluation is None
                    or evaluation.local_sum < best_evaluation.local_sum
                ):
                    best_evaluation = evaluation
        finally:
            if cache_handle is not None:
                cache_handle.close()

        if best_evaluation is None:
            raise RuntimeError(
                f"No admissible local factor at p={p_int} for condition "
                f"{reduction_condition_to_dict(condition)}."
            )

        prime_results[p_int] = PrimeSearchResult(
            p=p_int,
            maximum_power=len(weights) - 1,
            candidate_count=candidate_count,
            minimum=best_evaluation,
            reduction_condition=condition,
            rejected_candidate_count=rejected_candidate_count,
            all_candidates=all_evaluations,
        )

        if cache_path is not None and cache_file is not None:
            manifest["prime_files"][str(p_int)] = {
                "file": cache_file.name,
                "candidate_count": candidate_count,
                "rejected_candidate_count": rejected_candidate_count,
                "maximum_power": len(weights) - 1,
                "reduction_condition": reduction_condition_to_dict(condition),
            }
            (cache_path / "manifest.json").write_text(
                json.dumps(manifest, indent=2, sort_keys=True),
                encoding="utf-8",
            )

        if verbose:
            signature = best_evaluation.reduction_signature
            print(
                f"p={p_int:>4} | condition={condition.kind:<15} | "
                f"candidates={candidate_count:>8} | "
                f"minimum={best_evaluation.local_sum} | signature={signature}"
            )

    result = _build_bound_result(
        lambda_value=lambda_value,
        test_function=test_function,
        dimension=dimension,
        analytic_rank=analytic_rank,
        prime_results=prime_results,
        candidate_mode=candidate_mode,
        precision=precision,
        cache_directory=str(cache_path) if cache_path is not None else None,
    )
    if cache_path is not None:
        manifest["completed"] = True
        manifest["log_conductor_lower_bound_at_creation"] = str(
            result.log_conductor_lower_bound
        )
        manifest["conductor_lower_bound_at_creation"] = str(
            result.conductor_lower_bound
        )
        (cache_path / "manifest.json").write_text(
            json.dumps(manifest, indent=2, sort_keys=True),
            encoding="utf-8",
        )
    return result

# ---------------------------------------------------------------------------
# Recompute from retained candidate data
# ---------------------------------------------------------------------------


def _reweight_candidate_evaluation(
    evaluation: CandidateEvaluation,
    weights: Sequence[Any],
    *,
    precision: int,
) -> CandidateEvaluation:
    """Recompute one local sum from retained exact power sums."""
    if len(evaluation.power_sums) != len(weights):
        raise RuntimeError(
            "Retained power sums do not match the powers required at this lambda."
        )
    return CandidateEvaluation(
        p=evaluation.p,
        characteristic_polynomial=evaluation.characteristic_polynomial,
        euler_polynomial=evaluation.euler_polynomial,
        power_sums=evaluation.power_sums,
        local_sum=local_mestre_sum_from_power_sums(
            evaluation.power_sums,
            weights,
            precision=precision,
        ),
        reduction_signature=evaluation.reduction_signature,
        toric_cyclotomic_indices=evaluation.toric_cyclotomic_indices,
        source=evaluation.source,
    )


def recompute_from_retained_candidates(
    retained_result: MestreBoundResult,
    test_function: Callable[[Any], Any],
    *,
    analytic_rank: Optional[int] = None,
    keep_all_candidates: bool = True,
    precision: Optional[int] = None,
    verbose: bool = True,
) -> MestreBoundResult:
    r"""Reweight candidates retained in memory at the same ``lambda``.

    The original search must have used ``keep_all_candidates=True``.  No local
    polynomial is regenerated; only the Mestre weights and local sums change.
    """
    chosen_precision = retained_result.precision if precision is None else int(precision)
    chosen_rank = (
        retained_result.analytic_rank if analytic_rank is None else int(analytic_rank)
    )
    if chosen_rank < 0:
        raise ValueError("analytic_rank must be nonnegative.")

    prime_results: Dict[int, PrimeSearchResult] = {}
    for p, old_prime_result in sorted(retained_result.prime_results.items()):
        if old_prime_result.all_candidates is None:
            raise RuntimeError(
                f"Candidates at p={p} were not retained. Run the original search "
                "with keep_all_candidates=True or use a disk cache."
            )
        weights = local_mestre_weights(
            p,
            retained_result.lambda_value,
            test_function,
            precision=chosen_precision,
        )
        reevaluated = [
            _reweight_candidate_evaluation(
                evaluation,
                weights,
                precision=chosen_precision,
            )
            for evaluation in old_prime_result.all_candidates
        ]
        if not reevaluated:
            raise RuntimeError(f"No retained candidate at p={p}.")
        best = min(reevaluated, key=lambda evaluation: evaluation.local_sum)
        prime_results[p] = PrimeSearchResult(
            p=p,
            maximum_power=len(weights) - 1,
            candidate_count=len(reevaluated),
            minimum=best,
            reduction_condition=old_prime_result.reduction_condition,
            rejected_candidate_count=old_prime_result.rejected_candidate_count,
            all_candidates=reevaluated if keep_all_candidates else None,
        )
        if verbose:
            print(
                f"p={p:>4} | retained candidates={len(reevaluated):>8} | "
                f"minimum={best.local_sum}"
            )

    return _build_bound_result(
        lambda_value=retained_result.lambda_value,
        test_function=test_function,
        dimension=retained_result.dimension,
        analytic_rank=chosen_rank,
        prime_results=prime_results,
        candidate_mode=f"memory:{retained_result.candidate_mode}",
        precision=chosen_precision,
    )




def _evaluation_from_cache_record(
    record: Mapping[str, Any],
    p: int,
    weights: Sequence[Any],
    *,
    precision: int,
) -> CandidateEvaluation:
    characteristic_polynomial = CHARACTERISTIC_RING(
        record["characteristic_coefficients"]
    )
    euler_polynomial = EULER_RING(record["euler_coefficients"])
    power_sums = tuple(ZZ(value) for value in record["power_sums"])
    local_sum = local_mestre_sum_from_power_sums(
        power_sums,
        weights,
        precision=precision,
    )
    signature_value = record.get("reduction_signature")
    signature = (
        tuple(int(value) for value in signature_value)
        if signature_value is not None
        else None
    )
    return CandidateEvaluation(
        p=p,
        characteristic_polynomial=characteristic_polynomial,
        euler_polynomial=euler_polynomial,
        power_sums=power_sums,
        local_sum=local_sum,
        reduction_signature=signature,
        toric_cyclotomic_indices=tuple(
            int(value) for value in record.get("toric_cyclotomic_indices", [])
        ),
        source=str(record.get("source", "candidate_cache")),
    )


def recompute_from_candidate_cache(
    cache_directory: Any,
    test_function: Callable[[Any], Any],
    *,
    analytic_rank: int = 0,
    keep_all_candidates: bool = False,
    precision: int = 128,
    verbose: bool = True,
) -> MestreBoundResult:
    r"""Re-evaluate every retained candidate without regenerating polynomials.

    The cached exact power sums can be combined with a different compact test
    function at the same ``lambda``.  Increasing ``lambda`` can require more
    powers and therefore requires a new candidate cache.
    """
    cache_path = Path(cache_directory)
    manifest_path = cache_path / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Missing cache manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not manifest.get("completed", False):
        raise RuntimeError("The candidate cache is marked as incomplete.")

    lambda_value = manifest["lambda"]
    dimension = int(manifest["dimension"])
    candidate_mode = str(manifest.get("candidate_mode", "cached"))
    format_version = int(manifest.get("format_version", 1))
    prime_results: Dict[int, PrimeSearchResult] = {}

    for p in [int(value) for value in manifest["primes"]]:
        weights = local_mestre_weights(
            p,
            lambda_value,
            test_function,
            precision=precision,
        )
        file_info = manifest["prime_files"][str(p)]
        data_file = cache_path / file_info["file"]
        all_evaluations: Optional[List[CandidateEvaluation]] = (
            [] if keep_all_candidates else None
        )
        best_evaluation: Optional[CandidateEvaluation] = None
        candidate_count = 0

        with gzip.open(data_file, "rt", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                record = json.loads(line)
                evaluation = _evaluation_from_cache_record(
                    record,
                    p,
                    weights,
                    precision=precision,
                )
                if len(evaluation.power_sums) != len(weights):
                    raise RuntimeError(
                        f"Cache at p={p} does not contain the powers required "
                        "for its recorded lambda."
                    )
                candidate_count += 1
                if all_evaluations is not None:
                    all_evaluations.append(evaluation)
                if (
                    best_evaluation is None
                    or evaluation.local_sum < best_evaluation.local_sum
                ):
                    best_evaluation = evaluation

        if best_evaluation is None:
            raise RuntimeError(f"No cached candidates found at p={p}.")

        if format_version >= 2 and "reduction_condition" in file_info:
            condition = reduction_condition_from_dict(
                file_info["reduction_condition"]
            )
        else:
            legacy_default = (
                "good"
                if _normalized_keyword(candidate_mode) in {"good", "good_reduction"}
                else "any"
            )
            condition = normalize_reduction_condition(legacy_default, dimension)

        prime_results[p] = PrimeSearchResult(
            p=p,
            maximum_power=len(weights) - 1,
            candidate_count=candidate_count,
            minimum=best_evaluation,
            reduction_condition=condition,
            rejected_candidate_count=int(
                file_info.get("rejected_candidate_count", 0)
            ),
            all_candidates=all_evaluations,
        )
        if verbose:
            print(
                f"p={p:>4} | condition={condition.kind:<15} | "
                f"cached candidates={candidate_count:>8} | "
                f"minimum={best_evaluation.local_sum}"
            )

    return _build_bound_result(
        lambda_value=lambda_value,
        test_function=test_function,
        dimension=dimension,
        analytic_rank=analytic_rank,
        prime_results=prime_results,
        candidate_mode=f"cached:{candidate_mode}",
        precision=precision,
        cache_directory=str(cache_path),
    )

# ---------------------------------------------------------------------------
# Small reporting/export helpers
# ---------------------------------------------------------------------------


def best_local_factors_table(result: MestreBoundResult) -> List[Dict[str, Any]]:
    """Return one plain-Python row per selected prime factor."""
    rows: List[Dict[str, Any]] = []
    for p, prime_result in sorted(result.prime_results.items()):
        best = prime_result.minimum
        rows.append(
            {
                "p": p,
                "maximum_power": prime_result.maximum_power,
                "candidate_count": prime_result.candidate_count,
                "rejected_candidate_count": prime_result.rejected_candidate_count,
                "reduction_condition": reduction_condition_to_dict(
                    prime_result.reduction_condition
                ),
                "minimum_local_sum": str(best.local_sum),
                "characteristic_polynomial": str(best.characteristic_polynomial),
                "euler_polynomial": str(best.euler_polynomial),
                "reduction_signature": best.reduction_signature,
                "toric_cyclotomic_indices": best.toric_cyclotomic_indices,
            }
        )
    return rows


def save_best_local_factors_json(
    result: MestreBoundResult,
    destination: Any,
) -> None:
    """Save the selected local factors and global bound as readable JSON."""
    payload = {
        "summary": {
            "lambda": str(result.lambda_value),
            "dimension": result.dimension,
            "analytic_rank": result.analytic_rank,
            "phi_at_half": str(result.phi_at_half),
            "archimedean_term": str(result.archimedean_term),
            "local_sum_without_factor_two": str(
                result.local_sum_without_factor_two
            ),
            "log_conductor_lower_bound": str(
                result.log_conductor_lower_bound
            ),
            "conductor_lower_bound": str(result.conductor_lower_bound),
            "candidate_mode": result.candidate_mode,
        },
        "best_local_factors": best_local_factors_table(result),
    }
    Path(destination).write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=str),
        encoding="utf-8",
    )
