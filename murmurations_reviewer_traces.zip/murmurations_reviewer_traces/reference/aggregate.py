#!/usr/bin/env python3
"""Export prime-wise means; refuses missing/error levels unless explicitly allowed.

No graphs are generated. All integer sums and denominators are exported, so the
later choice of murmuration normalization remains visible and reversible.
"""
from __future__ import annotations
import argparse
import csv
import math
import os
from pathlib import Path
import tempfile
from common import ROOT, atomic_json, read_json, validate_label, validate_result


MEAN_COLUMNS = ["field_id", "field_discriminant", "field_radicand", "root_number", "prime",
                "orbit_count", "embedding_count", "sum_trace", "sum_norm", "mean_orbit_trace",
                "mean_a_over_embeddings", "mean_a_over_embeddings_div_sqrt_p", "mean_norm"]


def mean_rows(results, settings, include_bad=False):
    """Separate each field and root number: NEVER pool different quadratic fields."""
    primes, degree = settings["prime_indices"], settings["degree"]
    accum, metadata = {}, {}
    for result in results:
        for record in result["records"]:
            info = record.get("coefficient_field")
            if degree == 2 and info is None:
                raise ValueError("Quadratic record has no field classification")
            D = info["discriminant"] if info else 0
            if D not in accum:
                accum[D] = {(sign, p): [0, 0, 0] for sign in (-1, 1) for p in primes}
                metadata[D] = {"field_id": info["id"] if info else "prescribed",
                               "field_discriminant": D if info else "",
                               "field_radicand": info["radicand"] if info else ""}
            sign = record["root_number"]
            for i, p in enumerate(primes):
                if not include_bad and result["level"] % p == 0:
                    continue
                item = accum[D][sign, p]
                item[0] += 1; item[1] += record["traces"][i]; item[2] += record["norms"][i]
    for D in sorted(accum):
        for sign in (-1, 1):
            for p in primes:
                count, traces, norms = accum[D][sign, p]
                yield {**metadata[D], "root_number": sign, "prime": p, "orbit_count": count,
                       "embedding_count": degree * count, "sum_trace": traces, "sum_norm": norms,
                       "mean_orbit_trace": traces / count if count else "",
                       "mean_a_over_embeddings": traces / (degree * count) if count else "",
                       "mean_a_over_embeddings_div_sqrt_p": traces / (degree * count * math.sqrt(p)) if count else "",
                       "mean_norm": norms / count if count else ""}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("label")
    p.add_argument("--min-level", type=int, required=True)
    p.add_argument("--max-level", type=int, required=True)
    p.add_argument("--include-bad-primes", action="store_true")
    p.add_argument("--allow-incomplete", action="store_true")
    ns = p.parse_args()
    validate_label(ns.label)
    if ns.min_level < 1 or ns.max_level < ns.min_level:
        p.error("Invalid interval")
    base = ROOT / "results" / ns.label
    settings = read_json(base / "settings.json")
    missing, paths = [], []
    for level in range(ns.min_level, ns.max_level + 1):
        path = base / f"{level}.json"
        if not path.exists():
            missing.append(level)
        else:
            validate_result(read_json(path), settings, level)
            paths.append(path)
    if missing and not ns.allow_incomplete:
        p.error(f"{len(missing)} missing/error levels; no means exported. First missing: {missing[:20]}")
    def results():
        for path in paths:
            obj = read_json(path)
            validate_result(obj, settings, int(path.stem))
            yield obj
    stem = f"means_N{ns.min_level}_{ns.max_level}" + ("_with_bad_primes" if ns.include_bad_primes else "_good_primes")
    if missing:
        stem += "_INCOMPLETE"
    output = base / (stem + ".csv")
    fd, tmp = tempfile.mkstemp(prefix=".means.", suffix=".tmp", dir=base)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=MEAN_COLUMNS)
            writer.writeheader()
            writer.writerows(mean_rows(results(), settings, ns.include_bad_primes))
            stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp, output)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    atomic_json(base / (stem + ".json"), {"complete": not missing, "missing_levels": missing,
                "settings_hash": settings["settings_hash"], "min_level": ns.min_level,
                "max_level": ns.max_level, "include_bad_primes": ns.include_bad_primes,
                "csv": str(output), "levels_used": len(paths), "grouped_by_field": True})
    print(output)
    return 0 if not missing else 2


if __name__ == "__main__":
    raise SystemExit(main())
