# D87 — un exemple d’élagage par formules explicites

**Commencer par `LIRE_D87.html` pour lire les résultats, ou par
`notebooks/16_D87_tree_pruning.ipynb` pour les recalculer.**

Ce dossier reprend le projet `EXPLICIT_FORMULA_WELL_ORGANIZED_v2` fourni,
**sans modifier ses fichiers existants**. Il y ajoute un exemple autonome :
le corps défini par `x^3-x^2+2*x+1`, de discriminant **−87**.
Les 14 anciens notebooks et leurs modules Sage restent disponibles.

## Recalculer en une commande

Depuis ce dossier, dans l’environnement Conda/Sage habituel :

```bash
python D87.py demo
```

Cette commande recalcule les 441 triplets initiaux, les 187 prolongements
précoces et la couverture de rejet final à 34 blocs. Elle ne remplace pas
les calculs par une lecture des résultats archivés. Elle écrit les nouvelles
données dans `outputs/D87_demo/`. Les sept dénombrements intermédiaires ne
sont pas exécutés dans ce mode court.

Si une dépendance manque :

```bash
python -m pip install -r requirements_D87.txt
```

Le module D87 fonctionne sous Python ≥ 3.10 et dans un environnement Sage
contenant ces bibliothèques. **Aucun solveur LP/MILP et aucun fichier LMFDB ne
sont nécessaires pour cet exemple.** Les anciens notebooks continuent à
nécessiter Sage comme indiqué dans leur documentation.

## Ouvrir le notebook

Dans Jupyter, ouvrir `notebooks/16_D87_tree_pruning.ipynb` et exécuter les
cellules dans l’ordre. Sa présentation suit les notebooks fournis :
**objectif → méthode → paramètres → court appel → résultats**.
Le notebook est fourni avec des sorties exécutées sous Python 3.
Il peut aussi être utilisé avec un noyau Sage disposant des dépendances;
le lancement natif sous Sage n’a pas été exécuté lors de ce conditionnement.

## Les deux commandes complémentaires

Recalculer **tous les paliers** et comparer leurs comptages aux références :

```bash
python D87.py reproduire --out outputs/D87
```

Recalculer les 34 rejets à **70 chiffres de précision de travail** et
recompter indépendamment leur couverture entière :

```bash
python D87.py verifier --source outputs/D87 --out outputs/D87_precision --digits 70
```

Un manque de temps laisse des `pending`; ils ne sont pas comptés comme
rejetés. Le budget est réglable par `--seconds-per-stage 60`.
Une relance recalcule les paliers : ce programme n’annonce pas de reprise
à partir d’un checkpoint. Un autre pas exige un autre dossier de sortie.

Pour simplement lire le bilan archivé, sans calcul : `python D87.py reference`.

## Ce que l’exemple montre

| Étape | Résultat |
|---|---:|
| Triplets aux normes 3, 3, 5 à λ = 1,97 | 1 survivant sur 441 : (−3, −3, −4) |
| Ajout des normes 8 et 19 : Odlyzko seul | 187 sur 187 |
| Même étape : Odlyzko + croissance de G₂ | 51 sur 187 |
| Valeurs de a₈ encore possibles | 3, 4, 5 |
| Rejet final, à λ = log 41 | 0 survivant, 0 cas limite, 0 en attente |
| Prolongements représentés dans le rejet final | 18 919 991 475 |
| Blocs disjoints de la couverture finale | 34 |

Les 18,9 milliards de feuilles ne sont pas parcourues individuellement.
Chaque bloc est rejeté à l’aide d’une borne additive valable pour toutes
ses traces entières, et les multiplicités des idéaux de même norme sont
comptées exactement. Il ne s’agit ni d’une relaxation LP ni d’un MILP.

**Portée :** rejet numérique sous analyticité/GRH pour Odlyzko et sous le
**critère supplémentaire de croissance sur la grille**. La croissance n’est
pas démontrée ici pour toute courbe. Une précision de travail de 70 chiffres
n’est pas une certification par intervalles. Aucun taux de convergence
vers le conducteur n’est imposé.

## Où est chaque chose ?

| Usage | Fichier ou dossier |
|---|---|
| Lire sans installer | `LIRE_D87.html` |
| Démonstration interactive | `notebooks/16_D87_tree_pruning.ipynb` |
| Entrée en ligne de commande | `D87.py` |
| Noyaux, contributions locales, comptage entier | `sage/d87_core.py` |
| Étapes, exports et interface pédagogique | `sage/d87_workflow.py` |
| Contrôle indépendant haute précision | `sage/d87_precision.py` |
| Figures reproductibles | `sage/d87_figures.py` |
| Chargement facultatif depuis Sage | `sage/d87_pruning.sage` |
| Données archivées, distinctes des nouveaux calculs | `data/examples/D87/reference/` |
| **Toutes les données numériques archivées en un fichier** | `data/examples/D87/reference/toutes_les_donnees_numeriques.json` |
| Tous les exports d’une nouvelle exécution | `outputs/D87_demo/donnees_numeriques.json` ou `outputs/D87/donnees_numeriques.json` |
| Explication des algorithmes et des signes | `docs/D87/ALGORITHMES.md` |
| Rapport et texte prêt à rédiger | `docs/D87/` |
| Vérifications réellement exécutées | `VALIDATION_D87.md`, `VALIDATION_D87.json` |
| Tests courts | `python -m unittest discover -s tests -p test_d87.py -v` |

La documentation du projet initial reste dans `README.md` et
`README_DETAILED.md`. Ses déclarations de validation ne sont pas remplacées
par celles de l’ajout D87. Le nouveau manifeste d’intégrité couvre le dossier
complet; l’ancien manifeste est conservé comme pièce du projet initial.
