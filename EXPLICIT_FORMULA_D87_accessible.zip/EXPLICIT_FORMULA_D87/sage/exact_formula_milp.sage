"""Min-max MILP and high-level workflow for exact-formula conductor bounds.

This file solves the fixed-factor min-max problem, optionally adds monotonicity
constraints, optionally uses a known conductor as an upper cutoff, writes the
solver outputs, and exposes run_exact_formula_search(...) for notebooks.

Requires: exact_formula_core.sage, exact_formula_local_factors.sage, and
exact_formula_precomputation.sage.
"""

# select adjacent lambda pairs on which monotonicity is imposed. Input: grid and threshold. Output:
# list of indices.
#
def active_monotonicity_pairs(lambdas, threshold):
    if threshold is None:
        return []
    return [j for j in range(len(lambdas)-1) if lambdas[j] >= RR(threshold)]


# solve the fixed-factor min-max MILP, optionally with monotonicity and a known-conductor cutoff.
# Input: config, grid, database, constants, run directory, flags. Output: solver-result dictionary.
#
def build_and_solve_minmax(config, lambdas, database, constants, run_dir,
                           enforce_monotonicity=False, tag="common"):
    mip = MixedIntegerLinearProgram(maximization=False, solver=config.solver)
    mip.set_problem_name("Mestre_exact_{}".format(tag))
    choose = mip.new_variable(binary=True, name="choose")
    z_variables = mip.new_variable(real=True, nonnegative=False, name="z")
    z = z_variables[0]

    cutoff_log = None
    if config.use_known_conductor_cutoff:
        cutoff_log = log(RR(config.known_conductor_upper_bound))
        mip.add_constraint(
            z,
            max=upper_float(cutoff_log, config),
            name="known_conductor_upper_cutoff",
        )

    for p in database["primes"]:
        profiles = database["profiles"][p]
        mip.add_constraint(
            sum(choose[p, k] for k in range(len(profiles))) == 1,
            name="one_factor_p{}".format(p),
        )

    # z dominates a lower-rounded version of C_F(lambda) for every lambda.
    for j, lam in enumerate(lambdas):
        constant = constants["objective"][j]
        rhs = lower_float(constant["value"]-constant["error"], config)
        expression = z
        for p in database["primes"]:
            for k, profile in enumerate(database["profiles"][p]):
                data = profile["contributions"]["objective"][j]
                coefficient = RR(2)*(data["value"]-data["error"])
                expression -= lower_float(coefficient, config)*choose[p, k]
        mip.add_constraint(expression, min=rhs, name="bound_lambda_{}".format(j))

    # Elementary information: every bad-reduction prime divides the conductor.
    if config.use_bad_prime_divisibility:
        expression = z
        for p in database["primes"]:
            logp_lower = lower_float(log(RR(p)), config)
            for k, profile in enumerate(database["profiles"][p]):
                exponent = ZZ(profile["conductor_exponent_lower_bound"])
                expression -= float(exponent)*logp_lower*choose[p, k]
        mip.add_constraint(expression, min=0, name="bad_prime_divisibility")

    threshold, threshold_note = monotonicity_threshold(config)
    active_pairs = []
    if enforce_monotonicity:
        if config.monotonicity_mode == "off":
            raise ValueError("Monotonicity cannot be imposed when monotonicity_mode='off'.")
        active_pairs = active_monotonicity_pairs(lambdas, threshold)

        # Use an error-relaxed monotonicity constraint:
        # if the exact difference is positive, its upper enclosure must be nonnegative.
        for j in active_pairs:
            c1 = constants["monotonicity"][j]
            c2 = constants["monotonicity"][j+1]
            constant_upper_delta = ((c2["value"]+c2["error"])
                                    -(c1["value"]-c1["error"]))
            expression = upper_float(constant_upper_delta, config)

            for p in database["primes"]:
                for k, profile in enumerate(database["profiles"][p]):
                    d1 = profile["contributions"]["monotonicity"][j]
                    d2 = profile["contributions"]["monotonicity"][j+1]
                    upper_delta = RR(2)*((d2["value"]+d2["error"])
                                         -(d1["value"]-d1["error"]))
                    expression += upper_float(upper_delta, config)*choose[p, k]

            mip.add_constraint(
                expression,
                min=-float(RR(config.monotonicity_slack)),
                name="monotonicity_{}_{}".format(j, j+1),
            )

    mip.set_objective(z)
    mip.write_mps(str(run_dir/(tag+".mps")))
    mip.write_lp(str(run_dir/(tag+".lp")))

    started = time.time()
    try:
        objective = RR(mip.solve())
    except Exception as exc:
        return {
            "status": "infeasible_or_solver_error",
            "message": str(exc),
            "tag": tag,
            "active_pairs": active_pairs,
            "threshold": threshold,
            "threshold_note": threshold_note,
            "elapsed_seconds": time.time()-started,
            "known_conductor_upper_bound": config.known_conductor_upper_bound,
            "cutoff_log": cutoff_log,
        }

    elapsed = time.time()-started
    values = mip.get_values(choose)
    selection = {}
    for p in database["primes"]:
        profiles = database["profiles"][p]
        index = max(range(len(profiles)), key=lambda k: values[p, k])
        selection[p] = profiles[index]

    # The margin below only protects against ordinary floating-point solver tolerances
    # and the LP/MPS model is retained for external certification.
    safe_model_lower = objective-RR(config.solver_safety_margin)
    result = {
        "status": "optimal_reported_by_solver",
        "tag": tag,
        "solver_objective": objective,
        "safe_model_lower_log_bound": safe_model_lower,
        "selection": selection,
        "active_pairs": active_pairs,
        "threshold": threshold,
        "threshold_note": threshold_note,
        "elapsed_seconds": elapsed,
        "number_of_variables": mip.number_of_variables(),
        "number_of_constraints": mip.number_of_constraints(),
        "known_conductor_upper_bound": config.known_conductor_upper_bound,
        "cutoff_log": cutoff_log,
    }

    save_solution(config, lambdas, database, constants, result, run_dir)
    return result


# evaluate a fixed local-factor selection on the lambda grid. Input: config, grid, database,
# constants, selection, role. Output: list of curve rows.
#
def curve_for_selection(config, lambdas, database, constants, selection, role):
    rows = []
    for j, lam in enumerate(lambdas):
        constant = constants[role][j]
        central = constant["value"]
        lower = constant["value"]-constant["error"]
        upper = constant["value"]+constant["error"]
        for p in database["primes"]:
            data = selection[p]["contributions"][role][j]
            central += RR(2)*data["value"]
            lower += RR(2)*(data["value"]-data["error"])
            upper += RR(2)*(data["value"]+data["error"])
        rows.append({
            "lambda_index": j,
            "lambda": lam,
            "central": central,
            "lower": lower,
            "upper": upper,
        })
    return rows


# write a MILP selection and its curves to disk. Input: experiment objects and solver result.
# Output: None.
#
def save_solution(config, lambdas, database, constants, result, run_dir):
    tag = result["tag"]
    selection = result["selection"]

    selection_fields = [
        "p", "profile_id", "signature", "is_bad",
        "conductor_exponent_lower_bound", "member_count",
        "representative_characteristic_polynomial", "representative_euler_polynomial",
        "power_sums", "sample_characteristic_polynomials",
    ]
    with open(run_dir/(tag+"_selection.csv"), "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=selection_fields)
        writer.writeheader()
        for p in database["primes"]:
            profile = selection[p]
            writer.writerow({
                "p": int(p),
                "profile_id": profile["profile_id"],
                "signature": json_text(integer_list(profile["signature"])),
                "is_bad": int(profile["is_bad"]),
                "conductor_exponent_lower_bound": int(profile["conductor_exponent_lower_bound"]),
                "member_count": profile["member_count"],
                "representative_characteristic_polynomial": str(profile["P"]),
                "representative_euler_polynomial": str(profile["euler_P"]),
                "power_sums": json_text(integer_list(profile["power_sums"])),
                "sample_characteristic_polynomials": json_text(profile["sample_polynomials"]),
            })

    roles = ["objective"]
    if config.monotonicity_mode != "off":
        roles.append("monotonicity")
    curve_fields = ["role", "lambda_index", "lambda", "lower", "central", "upper", "delta_central"]
    with open(run_dir/(tag+"_curves.csv"), "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=curve_fields)
        writer.writeheader()
        for role in roles:
            rows = curve_for_selection(config, lambdas, database, constants, selection, role)
            previous = None
            for row in rows:
                delta = None if previous is None else row["central"]-previous
                writer.writerow({
                    "role": role,
                    "lambda_index": row["lambda_index"],
                    "lambda": rr_text(row["lambda"]),
                    "lower": rr_text(row["lower"]),
                    "central": rr_text(row["central"]),
                    "upper": rr_text(row["upper"]),
                    "delta_central": "" if delta is None else rr_text(delta),
                })
                previous = row["central"]


# print a short solver summary. Input: solver-result dictionary. Output: None.
#
def print_solution(result):
    print("Status:", result["status"])
    if result["status"] != "optimal_reported_by_solver":
        print(result.get("message", ""))
        return
    print("Solver objective:", result["solver_objective"].n(14))
    print("Logarithmic bound after safety margin:", result["safe_model_lower_log_bound"].n(14))
    real_bound = exp(result["safe_model_lower_log_bound"])
    print("Conductor bound after safety margin:", real_bound.n(14))
    print("Corresponding integer lower bound:", ceil(real_bound))
    print("Variables / constraints:", result["number_of_variables"], "/", result["number_of_constraints"])
    print("Solver time: {:.3f} s".format(result["elapsed_seconds"]))
    if result.get("known_conductor_upper_bound") is not None:
        print("Known-conductor cutoff:", result["known_conductor_upper_bound"])
    if result["active_pairs"]:
        print("Active monotonicity constraints:", result["active_pairs"])


# Full workflow


# execute the full exact-formula workflow and write all reproducibility files. Input:
# ExperimentConfig. Output: detailed result dictionary.
#
def run_experiment(config):
    lambdas, threshold, threshold_note = validate_config(config)
    run_dir = make_run_directory(config)
    print("Run directory:", run_dir.resolve())

    with open(run_dir/"configuration.json", "w", encoding="utf-8") as handle:
        json.dump(
            serializable_config(config, lambdas, threshold, threshold_note),
            handle, ensure_ascii=False, indent=int(2),
        )

    grid_rows = lambda_grid_report(
        lambdas,
        support_radius=max(
            RR(config.objective_test.support_radius),
            RR(config.monotonicity_test.support_radius) if config.monotonicity_test else RR(0),
        ),
    )
    with open(run_dir/"lambda_grid.csv", "w", encoding="utf-8", newline="") as handle:
        fields = ["index", "lambda", "prime_bound", "number_of_primes", "new_primes"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in grid_rows:
            writer.writerow({
                "index": row["index"],
                "lambda": rr_text(row["lambda"]),
                "prime_bound": row["prime_bound"],
                "number_of_primes": row["number_of_primes"],
                "new_primes": json_text(integer_list(row["new_primes"])),
            })

    print("\n--- Build and compress local factors ---")
    database = build_candidate_database(config, lambdas, run_dir)

    print("\n--- Exact contributions on the lambda grid ---")
    constants = precompute_contributions(config, lambdas, database, run_dir)

    print("\n--- Independent local minima ---")
    independent = independent_local_bounds(config, lambdas, database, constants, run_dir)
    print("Independent global lower bound for log(N):",
          independent["global_lower_log_bound"].n(14))
    print("Independent global lower bound for N:",
          exp(independent["global_lower_log_bound"]).n(14))

    print("\n--- Same local factor for every lambda value ---")
    common = build_and_solve_minmax(
        config, lambdas, database, constants, run_dir,
        enforce_monotonicity=False, tag="common_fixed_factors",
    )
    print_solution(common)

    monotone = None
    if config.monotonicity_mode != "off":
        print("\n--- Fixed factors with monotonicity test ---")
        print("Threshold:", threshold.n(12), "-", threshold_note)
        monotone = build_and_solve_minmax(
            config, lambdas, database, constants, run_dir,
            enforce_monotonicity=True, tag="with_monotonicity",
        )
        print_solution(monotone)

    summary = {
        "run_directory": str(run_dir.resolve()),
        "candidate_family_certified_complete": bool(config.candidate_family_certified_complete),
        "independent_lower_log_bound": rr_text(independent["global_lower_log_bound"]),
        "independent_lower_conductor_bound": rr_text(exp(independent["global_lower_log_bound"])),
        "independent_integer_lower_bound": int(ceil(exp(independent["global_lower_log_bound"]))),
        "common_status": common["status"],
        "common_lower_log_bound": None if common["status"] != "optimal_reported_by_solver" else rr_text(common["safe_model_lower_log_bound"]),
        "common_lower_conductor_bound": None if common["status"] != "optimal_reported_by_solver" else rr_text(exp(common["safe_model_lower_log_bound"])),
        "common_integer_lower_bound": None if common["status"] != "optimal_reported_by_solver" else int(ceil(exp(common["safe_model_lower_log_bound"]))),
        "use_known_conductor_cutoff": bool(config.use_known_conductor_cutoff),
        "known_conductor_upper_bound": (
            None if config.known_conductor_upper_bound is None
            else rr_text(config.known_conductor_upper_bound)
        ),
        "monotonicity_mode": config.monotonicity_mode,
        "monotonicity_threshold": None if threshold is None else rr_text(threshold),
        "monotonicity_threshold_note": threshold_note,
        "monotone_status": None if monotone is None else monotone["status"],
        "monotone_lower_log_bound": None if monotone is None or monotone["status"] != "optimal_reported_by_solver" else rr_text(monotone["safe_model_lower_log_bound"]),
        "monotone_lower_conductor_bound": None if monotone is None or monotone["status"] != "optimal_reported_by_solver" else rr_text(exp(monotone["safe_model_lower_log_bound"])),
        "monotone_integer_lower_bound": None if monotone is None or monotone["status"] != "optimal_reported_by_solver" else int(ceil(exp(monotone["safe_model_lower_log_bound"]))),
        "rigour_note": (
            "The common-factor bound is conditional on the analytic hypotheses, GRH, "
            "validity of the local candidate family, and numerical certification of the MILP. "
            "The monotonicity bound additionally requires the exact rank and a lower bound for gamma_1; "
            "in heuristic mode it is only heuristic."
        ),
    }
    with open(run_dir/"summary.json", "w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=int(2))

    print("\nAll intermediate files were written to:", run_dir.resolve())
    return {
        "config": config,
        "lambdas": lambdas,
        "threshold": threshold,
        "run_dir": run_dir,
        "database": database,
        "constants": constants,
        "independent": independent,
        "common": common,
        "monotone": monotone,
        "summary": summary,
    }


# Diagnostic: changes of local minimizers


# report lambda values where local minimizers change. Input: detailed result, role, display limit.
# Output: None.
#
def show_local_minimizer_changes(result, role="objective", max_polynomials=3):
    config = result["config"]
    lambdas = result["lambdas"]
    database = result["database"]
    tolerance = RR(config.local_minimum_tolerance)

    if role not in ("objective", "monotonicity"):
        raise ValueError("role must be 'objective' or 'monotonicity'.")

    for p in database["primes"]:
        previous_ids = None
        print("\np =", p)
        for j, lam in enumerate(lambdas):
            profiles = database["profiles"][p]
            if role not in profiles[0]["contributions"]:
                continue
            values = [profile["contributions"][role][j]["value"] for profile in profiles]
            minimum = min(values)
            tied = [
                profile for profile, value in zip(profiles, values)
                if value <= minimum+tolerance
            ]
            ids = tuple(profile["profile_id"] for profile in tied)
            if ids != previous_ids:
                polynomials = [str(profile["P"]) for profile in tied[:max_polynomials]]
                suffix = " ..." if len(tied) > max_polynomials else ""
                print("  lambda={} | min={} | profiles={} | {}{}".format(
                    lam.n(9), minimum.n(12), len(tied), polynomials, suffix
                ))
                previous_ids = ids


# run the exact-formula MILP through a short public interface.
# Input: dimension, analytic rank, lambda grid, optional local/monotonicity data and cutoff.
# Output: a small dictionary containing the three main conductor bounds and the run directory.
#
def run_exact_formula_search(
    dimension,
    analytic_rank,
    lambda_values,
    objective_test=ODLYZKO_TEST,
    monotonicity_test=MONOTONE_TEST,
    default_reduction="any",
    reduction_conditions=None,
    monotonicity_mode="heuristic",
    lambda_start=1.0,
    gamma_lower_bound=None,
    rank_is_exact=True,
    use_bad_prime_divisibility=False,
    known_conductor_upper_bound=None,
    solver="GLPK",
    output_directory="outputs",
    run_label="exact_formula",
    overwrite_output=False,
    candidate_provider=None,
    candidate_family_certified_complete=True,
):
    if reduction_conditions is None:
        reduction_conditions = {}

    config = ExperimentConfig(
        dimension=dimension,
        analytic_rank=analytic_rank,
        rank_is_exact=rank_is_exact,
        lambda_values=lambda_values,
        objective_test=objective_test,
        monotonicity_test=monotonicity_test,
        default_reduction=default_reduction,
        reduction_conditions=reduction_conditions,
        candidate_provider=candidate_provider,
        candidate_family_certified_complete=candidate_family_certified_complete,
        monotonicity_mode=monotonicity_mode,
        gamma_lower_bound=gamma_lower_bound,
        lambda_start=lambda_start,
        use_bad_prime_divisibility=use_bad_prime_divisibility,
        use_known_conductor_cutoff=(known_conductor_upper_bound is not None),
        known_conductor_upper_bound=known_conductor_upper_bound,
        solver=solver,
        output_directory=str(output_directory),
        run_label=str(run_label),
        overwrite_output=overwrite_output,
    )

    detailed = run_experiment(config)
    independent = detailed["independent"]
    common = detailed["common"]
    monotone = detailed["monotone"]

    common_bound = None
    common_integer = None
    if common["status"] == "optimal_reported_by_solver":
        common_bound = exp(common["safe_model_lower_log_bound"])
        common_integer = ceil(common_bound)

    monotone_bound = None
    monotone_integer = None
    if monotone is not None and monotone["status"] == "optimal_reported_by_solver":
        monotone_bound = exp(monotone["safe_model_lower_log_bound"])
        monotone_integer = ceil(monotone_bound)

    independent_bound = exp(independent["global_lower_log_bound"])
    return {
        "independent_conductor_bound": independent_bound,
        "independent_integer_bound": ceil(independent_bound),
        "fixed_factor_conductor_bound": common_bound,
        "fixed_factor_integer_bound": common_integer,
        "monotone_conductor_bound": monotone_bound,
        "monotone_integer_bound": monotone_integer,
        "common_status": common["status"],
        "monotone_status": None if monotone is None else monotone["status"],
        "run_directory": str(detailed["run_dir"].resolve()),
        "summary_file": str((detailed["run_dir"] / "summary.json").resolve()),
    }
