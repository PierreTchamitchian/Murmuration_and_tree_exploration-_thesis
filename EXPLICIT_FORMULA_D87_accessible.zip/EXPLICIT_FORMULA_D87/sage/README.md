# Sage modules: one-line map

The function comments are intentionally placed **before** function definitions. Inside functions, comments appear only at technical mathematical/numerical steps.

| File | What it does |
|---|---|
| `mestre_formula.sage` | Basic fixed-lambda conductor bound with Weil estimates for unknown local coefficients. |
| `lambda_optimization.sage` | Original staged search in lambda; finite-grid check is secondary. |
| `field_data.sage` | Reads trusted LMFDB Sage exports and reconstructs number fields. |
| `batch_bounds.sage` | Runs the basic formula over many fields and writes/resumes a CSV. |
| `prescribed_reduction.sage` | Adds known local reduction information and conductor divisibility. |
| `without_grh.sage` | No-GRH test-function modification. |
| `exact_curve_formula.sage` | Exact truncated formula when local factors are known, especially one elliptic curve over Q. |
| `exact_formula_search.sage` | Loader for the exact local-factor MILP engine. |
| `exact_formula_core.sage` | Test functions, numerical explicit-formula terms and common configuration for that engine. |
| `exact_formula_local_factors.sage` | Generates the structural local-factor candidate family. |
| `exact_formula_precomputation.sage` | Enumerates profiles and precomputes their contributions on the lambda grid. |
| `exact_formula_milp.sage` | Selects one common local profile per prime by MILP. |
| `mestre_convex_relaxation.sage` | LP relaxation plus checked discrete upper selection. |
| `mestre_convex_run_io.sage` | Builds/reuses convex-relaxation inputs from the exact-factor data. |
| `surface_screen_profiles.sage` | All local moment domains for the conductor-by-conductor surface screen. |
| `surface_screen_analytic.sage` | Builds the explicit-formula and sampled-growth rows. |
| `surface_screen_model.sage` | Converts local domains and analytic rows into one compact LP/MILP model. |
| `surface_screen_solver.sage` | LP-first exclusion, exact finite-model checks and bounded integer feasibility. |
| `surface_screen_polynomial_tests.sage` | Optimizes polynomial-convolution test functions by a generalized eigenvalue problem. |
| `surface_screen_workflow.sage` | Scans conductors, saves results and adds optimized test-function cuts. |
| `surface_screen_load.sage` | Single loader for the surface-screen modules. |
| `subfields.sage` | Adds proper nontrivial subfields up to isomorphism. |
