"""Exact projected quadratic Hecke coefficients.

The four definitions below are copied verbatim from the benchmark whose SHA256
is recorded in reference/projection_provenance.json. That benchmark passed on
the user's Sage 10.9 (level 3752, all 4000 characteristic polynomials).
Integration, checkpoint and migration gates are separate from that pilot.
"""
from __future__ import annotations

def exact_int(value):
    """Reject truncation. Called only on exact rational arithmetic."""
    integer = int(value)
    if value != integer:
        raise ArithmeticError(f"Expected an integral coefficient, got {value}")
    return integer


def quadratic_charpoly(x, y, b, c):
    """Norm(X-(x+y*a)), where a^2+b*a+c=0. Coefficients low to high."""
    trace = 2 * x - b * y
    norm = x * x - b * x * y + c * y * y
    return [exact_int(norm), -exact_int(trace), 1]


def projection_groups(vectors):
    """Cover vectors by coordinate positions at which they are nonzero.

    A common starting symbol shares Heilbronn calculations between orbits.
    Renormalizing each eigenfunctional at this coordinate does not change a_p.
    """
    if not vectors:
        return []
    width = len(vectors[0])
    if width == 0 or any(len(v) != width or not any(v) for v in vectors):
        raise ValueError("Expected nonzero eigenvectors of identical length")
    remaining = list(range(len(vectors)))
    groups = []
    while remaining:
        counts = [sum(vectors[j][i] != 0 for j in remaining) for i in range(width)]
        coordinate = max(range(width), key=lambda i: counts[i])
        members = [j for j in remaining if vectors[j][coordinate] != 0]
        if not members:
            raise ArithmeticError("Could not choose a nonzero normalization coordinate")
        groups.append((coordinate, members))
        selected = set(members)
        remaining = [j for j in remaining if j not in selected]
    return groups


class ProjectedQuadraticCoefficients:
    """Exact rational preprojection, Gamma0 / weight 2 / sign +1 only.

    For a normalized eigenfunctional v, Sage's usual calculation is (u_p R)v.
    Write v in the power basis (1,a), precompute the two rational columns R*V,
    and pass that projected matrix to Sage's existing Heilbronn routine.
    Several orbits can be evaluated together using a common starting symbol.

    API checked against Sage 10.9 sources; live Sage validation is mandatory.
    """

    def __init__(self, spaces, report=None):
        from sage.all import QQ, matrix
        from sage.modular.modsym.heilbronn import hecke_images_gamma0_weight2

        if not spaces:
            raise ValueError("No quadratic components to project")
        self.spaces = spaces
        self.ambient = spaces[0].ambient_hecke_module()
        self.level = int(self.ambient.level())
        self.routine = hecke_images_gamma0_weight2
        self.QQ = QQ
        M = self.ambient
        if M.base_ring() != QQ or int(M.weight()) != 2 or int(M.sign()) != 1:
            raise ValueError("Only rational weight-2 sign-+1 modular symbols are supported")
        if not M.character().is_trivial():
            raise ValueError("Nontrivial characters are not supported")
        if not (0 < self.level < 2**31):
            raise ValueError("Level is outside the C-int range of the Sage routine")
        self.fields, duals = [], []
        for S in spaces:
            if S.ambient_hecke_module() != M or int(S.dimension()) != 2 or not S.is_simple():
                raise ValueError("Expected simple quadratic components of the same ambient space")
            v = S.dual_eigenvector(names="a", lift=True)
            F = v.base_ring()
            if int(F.degree()) != 2 or len(v) != int(M.dimension()):
                raise ArithmeticError("Unexpected eigenfield or dual-vector dimension")
            self.fields.append(F)
            duals.append(v)
        R = M.manin_gens_to_basis()
        if R.nrows() != len(M.p1list()) or R.ncols() != int(M.dimension()):
            raise ArithmeticError("Unexpected Manin presentation dimensions")
        self.groups = []
        self.field_polynomials = []
        for F in self.fields:
            f = F.defining_polynomial()
            if f.degree() != 2 or not f.is_monic():
                raise ArithmeticError("Expected a monic quadratic field model")
            self.field_polynomials.append((QQ(f[1]), QQ(f[0])))

        for group_number, (nz, members) in enumerate(projection_groups(duals), 1):
            normalized = []
            for j in members:
                F = self.fields[j]
                scale = duals[j][nz]
                coords = []
                for z in duals[j]:
                    row = list(F(z / scale).list())
                    if len(row) > 2:
                        raise ArithmeticError("Invalid power-basis coordinate length")
                    coords.append(row + [QQ(0)] * (2 - len(row)))
                normalized.append(coords)
            entries = [x for i in range(int(M.dimension()))
                       for column in normalized for x in column[i]]
            V = matrix(QQ, int(M.dimension()), 2 * len(members), entries)
            W = R * V
            symbol = M.manin_generators()[M.manin_basis()[nz]]
            u, v = int(symbol.u), int(symbol.v)
            # Explicit normalization/orientation check using the same low-level API.
            identity = self.routine(u, v, self.level, [1], W.sparse_matrix())
            if identity.nrows() != 1 or identity.ncols() != 2 * len(members):
                raise ArithmeticError("Unexpected shape of projected T_1")
            if any(identity[0, 2*k] != 1 or identity[0, 2*k + 1] != 0
                   for k in range(len(members))):
                raise ArithmeticError("Projected T_1 failed the normalization check")
            self.groups.append((u, v, members, W))
            if report:
                report(f"PROJECTION_GROUP index={group_number} orbits={len(members)} "
                       f"ambient_columns={int(M.dimension())} projected_columns={2*len(members)}")

    def compute(self, indices, batch_size=32, progress=None):
        """Return integral characteristic polynomials, indexed [orbit][prime]."""
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        indices = [int(n) for n in indices]
        if any(n < 1 or n >= 2**31 for n in indices):
            raise ValueError("Hecke indices must be positive C-int values")
        answers = [[] for _ in self.spaces]
        for start in range(0, len(indices), batch_size):
            block = indices[start:start + batch_size]
            for u, v, members, W in self.groups:
                values = self.routine(u, v, self.level, block,
                                      W.sparse_matrix() if max(block) <= 30 else W)
                if values.nrows() != len(block) or values.ncols() != 2 * len(members):
                    raise ArithmeticError("Unexpected projected Hecke image dimensions")
                for k, j in enumerate(members):
                    b, c = self.field_polynomials[j]
                    answers[j].extend(quadratic_charpoly(values[row, 2*k],
                                                        values[row, 2*k+1], b, c)
                                      for row in range(len(block)))
            if progress:
                progress(min(start + batch_size, len(indices)), len(indices))
        if any(len(values) != len(indices) for values in answers):
            raise ArithmeticError("Incomplete projected coefficients")
        return answers
