# Put LMFDB number-field exports here

Notebook `03_weil_bounds_by_field.ipynb` expects, for example:

```text
data/lmfdb/lmfdb_number_fields_degree_05.sage
```

Change `DATA_FILE` in the notebook if your filename is different.
