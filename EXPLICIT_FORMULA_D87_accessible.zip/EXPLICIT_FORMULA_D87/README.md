# Explicit-formula conductor bounds — clean v2

This folder is organized so that a reviewer can identify the purpose of every notebook and every Sage module without reconstructing the algorithm from the code.


## Start in three steps

1. Open the folder with SageMath and run `notebooks/00_quick_checks.ipynb`.
2. Choose the notebook matching the task in the table below. Each notebook states its goal, required files, main parameters and returned objects before the computation.
3. For the original many-number-field experiment and the root-discriminant/bound graph, start directly with `notebooks/03_weil_bounds_by_field.ipynb`.

## Which notebook should I open?

| Task | Notebook |
|---|---|
| Check that the project loads | `00_quick_checks.ipynb` |
| Bound one field with Weil estimates | `01_weil_bound_one_field.ipynb` |
| Bound many fields and plot bound vs. root discriminant | `03_weil_bounds_by_field.ipynb` |
| Use prescribed reduction at selected primes | `04_prescribed_reduction.ipynb` |
| Compare different analytic ranks | `05_rank_dependent_bounds.ipynb` |
| Use the no-GRH variant | `06_bound_without_grh.ipynb` |
| Use exact Euler factors of a known elliptic curve | `07_exact_bound_known_curve.ipynb` |
| Experimental independent local-factor minimization | `08_independent_local_factor_search.ipynb` |
| Add subfields of selected number fields | `09_subfields_of_selected_fields.ipynb` |
| Choose one common set of local factors across a lambda grid | `10_fixed_local_factor_bounds.ipynb` |
| Relax the fixed-factor MILP to a convex LP | `12_convex_local_factor_bounds.ipynb` |
| Eliminate candidate abelian-surface conductors | `13_eliminate_conductors.ipynb` |
| Optimize the test function for fixed local moments | `14_optimize_test_function.ipynb` |
| Inspect all local moment choices used by notebook 13 | `15_local_moment_domains.ipynb` |

## External data

Only notebook 03 (and notebook 09 through its output) normally needs a list of number fields. Put LMFDB Sage exports in:

```text
data/lmfdb/
```

Then change the visible `DATA_FILE` line in notebook 03 if the filename differs. A three-field demo is included under `data/examples/`. See `data/README.md`.

## Main output folders

- `outputs/`: generated CSV, JSON and figures; shipped empty.
- `cache/`: reusable intermediate computations; shipped empty.

## More explanation

Read `README_DETAILED.md` for the mathematical role of each Sage file, solver conventions, assumptions, test-function optimization, output semantics and validation. `REFERENCES.md` collects the external references.

The principal mathematical reference is Pierre Tchamitchian, *Explicit lower bounds on the conductors of elliptic curves and abelian varieties over number fields*, J. Number Theory (2026), arXiv:2410.12922v3.
