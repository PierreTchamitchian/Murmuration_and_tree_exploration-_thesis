"""Read compact reviewer data and aggregate exact integer sums.

No Sage dependency. A quadratic orbit contributes trace/2. Missing levels
are absent, not zero observations. No unweighted average of field averages.
"""
from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COLUMNS = ['field_discriminant', 'root_number', 'prime', 'orbit_count', 'sum_trace']


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def global_prime_indices(limit: int) -> dict[int, int]:
    """Index among ALL rational primes, starting with 2 -> 1."""
    flag = bytearray(b'\x01') * (limit + 1)
    flag[:2] = b'\x00\x00'
    for p in range(2, math.isqrt(limit) + 1):
        if flag[p]:
            flag[p*p::p] = b'\x00' * ((limit - p*p)//p + 1)
    return {p: j + 1 for j, p in enumerate(i for i in range(2, limit+1) if flag[i])}


def pool_fields(blocks: dict) -> dict:
    """Add counts and trace sums, not the means of individual fields."""
    out = defaultdict(lambda: [0, 0])
    for block in blocks.values():
        for key, (total, count) in block.items():
            out[key][0] += total
            out[key][1] += count
    return dict(out)


def means(block: dict, sign: int | None = None, signed: bool = False) -> dict:
    totals, counts = defaultdict(int), defaultdict(int)
    for (eps, p), (total, n) in block.items():
        if sign is None or eps == sign:
            totals[p] += (eps if signed else 1) * total
            counts[p] += 2 * n
    return {p: totals[p]/count for p, count in counts.items() if count > 0}


def load_data(root: Path = ROOT) -> dict:
    meta = json.loads((root/'metadata/manifest.json').read_text(encoding='utf-8'))
    grid = read_csv(root/'data/primes.csv')
    primes = [int(r['prime']) for r in grid]
    indices = global_prime_indices(max(primes))
    require(primes == list(indices), 'Prime grid is not the initial rational-prime grid')
    require(all(int(r['index_global']) == indices[int(r['prime'])] for r in grid),
            'Bad global indices')
    fields = {int(r['field_discriminant']): {k: int(v) for k, v in r.items()}
              for r in read_csv(root/'metadata/fields.csv')}
    blocks = defaultdict(dict)
    for r in read_csv(root/'data/modforms_N5000_10000.csv'):
        D, eps, p, n, total = (int(r[k]) for k in COLUMNS)
        require(D in fields and eps in (-1, 1) and p in indices, 'Invalid aggregate index')
        require(n >= 0 and (n != 0 or total == 0), 'Invalid count or empty-group sum')
        require((eps, p) not in blocks[D], 'Duplicate aggregate')
        require(n <= fields[D]['orbits_minus' if eps == -1 else 'orbits_plus'],
                'Local count exceeds total orbit count')
        blocks[D][eps, p] = (total, n)
    require(set(blocks) == set(fields), 'Missing field')
    expected_keys = {(eps, p) for eps in (-1, 1) for p in primes}
    require(all(set(b) == expected_keys for b in blocks.values()), 'Incomplete aggregate grid')
    require(sum(f['orbits_total'] for f in fields.values()) == meta['orbit_count'], 'Bad total count')
    for D, b in blocks.items():
        for eps in (-1, 1):
            require(b[eps, primes[-1]][1] == fields[D]['orbits_minus' if eps == -1 else 'orbits_plus'],
                    'Last prime (above all levels) should include every orbit')

    curves, comparisons = {}, {}
    for group in ('even', 'odd', 'weighted'):
        table = {}
        for r in read_csv(root/f'data/curves/{group}_Q_all_primes.csv'):
            p, idx, n, s = int(r['p']), int(r['order']), int(r['n_Q']), int(r['sum_Q'])
            require(p in indices and idx == indices[p] and p not in table, 'Bad Q prime/index')
            require(n > 0 and math.isclose(float(r['mean_Q']), s/n, rel_tol=1e-12, abs_tol=1e-12),
                    'Q mean/count mismatch')
            table[p] = (s, n)
        require(set(table) == set(primes), 'Q grid incomplete')
        curves[group] = table
        split = {}
        for r in read_csv(root/f'data/curves/{group}_comparison_split.csv'):
            p = int(r['p'])
            require(p in indices and int(r['order_global']) == indices[p] and p%5 in (1,4),
                    'Bad split prime/global index')
            require(p not in split, 'Duplicate split prime')
            nQ, nK = int(r['n_Q']), int(r['n_K'])
            q, k = float(r['mean_Q']), float(r['mean_K_per_place'])
            require(nK > 0 and nQ == table[p][1] and math.isfinite(k), 'Bad comparison counts')
            require(math.isclose(q, table[p][0]/nQ, rel_tol=1e-12, abs_tol=1e-12), 'Q series mismatch')
            require(math.isclose(float(r['mean_Q_sqrtp']), q/math.sqrt(p), abs_tol=1e-12), 'Q scaling mismatch')
            require(math.isclose(float(r['mean_K_sqrtp']), k/math.sqrt(p), abs_tol=1e-12), 'K scaling mismatch')
            split[p] = (k, nK)
        require(set(split) == {p for p in primes if p % 5 in (1, 4)}, 'Split grid incomplete')
        comparisons[group] = split
    # Check signed averages using actual counts, not half-difference of means.
    for p in primes:
        a, na = curves['even'][p]; b, nb = curves['odd'][p]
        require(curves['weighted'][p] == (a-b, na+nb), 'Q signed aggregation inconsistent')
    for p in comparisons['even']:
        a, na = comparisons['even'][p]; b, nb = comparisons['odd'][p]
        w, nw = comparisons['weighted'][p]
        require(nw == na+nb and math.isclose(w, (na*a-nb*b)/nw, abs_tol=1e-12),
                'K signed aggregation inconsistent')
    return dict(meta=meta, primes=primes, indices=indices, fields=fields,
                blocks=dict(blocks), curves=curves, comparisons=comparisons)


def export_means(data: dict, output: Path) -> int:
    """Export per-field, pooled, signed and unseparated means with exact numerators."""
    output.parent.mkdir(parents=True, exist_ok=True)
    fields = ['field_discriminant', 'group', 'prime', 'index_global', 'orbit_count',
              'embedding_count', 'numerator_trace', 'mean', 'mean_div_sqrt_p']
    nrows = 0
    all_blocks = [('all', pool_fields(data['blocks']))] + list(sorted(data['blocks'].items()))
    with output.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        for D, block in all_blocks:
            for group in ('epsilon_minus', 'epsilon_plus', 'all_signs', 'signed'):
                for p in data['primes']:
                    allowed = (-1,) if group == 'epsilon_minus' else ((1,) if group == 'epsilon_plus' else (-1,1))
                    total = sum((eps if group == 'signed' else 1)*block[eps,p][0] for eps in allowed)
                    n = sum(block[eps,p][1] for eps in allowed)
                    mean = total/(2*n) if n else ''
                    writer.writerow(dict(field_discriminant=D, group=group, prime=p,
                        index_global=data['indices'][p], orbit_count=n, embedding_count=2*n,
                        numerator_trace=total, mean=mean,
                        mean_div_sqrt_p=mean/math.sqrt(p) if n else ''))
                    nrows += 1
    return nrows
