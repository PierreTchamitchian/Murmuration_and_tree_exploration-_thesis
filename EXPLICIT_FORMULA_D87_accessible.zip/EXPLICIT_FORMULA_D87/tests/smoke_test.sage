"""Small Sage checks for the clean v2 project."""

# Run the short stable-formula and exact-known-curve checks.
# Input: PROJECT_ROOT must be the project directory. Output: True or an assertion error.
#
def run_smoke_tests():
    root = PROJECT_ROOT
    load(str(root / "sage" / "mestre_formula.sage"))
    load(str(root / "sage" / "lambda_optimization.sage"))
    load(str(root / "sage" / "exact_curve_formula.sage"))

    assert mestre_test_function(0) == 1
    assert mestre_test_function(2) == 0
    R = PolynomialRing(ZZ, "X_test"); X_test = R.gen()
    assert power_sums_of_roots(X_test^2 - 3*X_test + 2, 4) == [2,3,5,9,17]
    fixed = conductor_bound(QQ, lambda_value=1.0)
    assert fixed["absolute_norm_bound"] > 0
    staged = optimal_bound(QQ, steps=(1,0.1), safety_lambda=10)
    assert staged["search_method"] == "original_staged_search"
    print("All Sage smoke tests passed.")
    return True
