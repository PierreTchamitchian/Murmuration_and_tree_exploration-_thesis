"""Local-factor candidate generation for the exact-formula conductor MILP.

This file enumerates reduction signatures, toric cyclotomic factors, and the
structural over-family of local characteristic polynomials used by the source
notebooks.

Requires: exact_formula_core.sage loaded first.
"""

# Reduction signatures and toric factors


# enumerate triples (g_ab,g_m,g_u) summing to g. Input: dimension g. Output: iterator of triples.
#
def all_reduction_signatures(g):
    g = ZZ(g)
    for gab in range(g+1):
        for gm in range(g-gab+1):
            gu = g-gab-gm
            yield (ZZ(gab), ZZ(gm), ZZ(gu))


# normalize a local reduction condition. Input: string/tuple/dictionary/None. Output: normalized
# condition.
#
def normalize_condition(condition):
    if condition is None:
        return "any"
    if isinstance(condition, str):
        text = condition.strip().lower()
        aliases = {
        }
        return aliases.get(text, text)
    return condition


# test whether a local signature satisfies a condition. Input: condition, signature, dimension.
# Output: Boolean.
#
def condition_allows_signature(condition, signature, g):
    condition = normalize_condition(condition)
    signature = tuple(ZZ(v) for v in signature)
    good_signature = (ZZ(g), ZZ(0), ZZ(0))

    if condition == "any":
        return True
    if condition == "good":
        return signature == good_signature
    if condition == "bad":
        return signature != good_signature
    if condition == "semistable":
        return signature[2] == 0
    if condition == "semistable_bad":
        return signature[2] == 0 and signature[1] > 0
    if condition == "non_semistable":
        return signature[2] > 0
    if isinstance(condition, (tuple, list)) and len(condition) == 3:
        return signature == tuple(ZZ(v) for v in condition)
    if isinstance(condition, dict) and condition.get("kind", "").lower() != "custom":
        kind = condition.get("kind", "any")
        if not condition_allows_signature(kind, signature, g):
            return False
        if condition.get("abelian_dimension") is not None and signature[0] != ZZ(condition["abelian_dimension"]):
            return False
        if condition.get("toric_dimension") is not None and signature[1] != ZZ(condition["toric_dimension"]):
            return False
        if condition.get("unipotent_dimension") is not None and signature[2] != ZZ(condition["unipotent_dimension"]):
            return False
        return True
    return False


# list cyclotomic indices with Euler degree at most d. Input: integer d. Output: tuple of integers.
#
@lru_cache(maxsize=None)
def cyclotomic_indices_with_degree_at_most(d):
    d = ZZ(d)
    if d <= 0:
        return tuple()
    # The inequality phi(n)^2 >= n/2 gives n <= 2d^2 when phi(n) <= d.
    upper = ZZ(2*d*d)
    return tuple(ZZ(n) for n in range(1, upper+1) if euler_phi(n) <= d)


# enumerate toric cyclotomic types of total degree d. Input: d. Output: cached tuple of
# type/polynomial data.
#
@lru_cache(maxsize=None)
def toric_types_of_degree(d):
    d = ZZ(d)
    if d == 0:
        return ((tuple(), tuple([1])),)

    indices = cyclotomic_indices_with_degree_at_most(d)
    results = []

    # Recursively list cyclotomic factor combinations whose total degree is exactly d.
    #
    def recurse(remaining, start, chosen):
        if remaining == 0:
            polynomial = CHI(1)
            for n in chosen:
                polynomial *= CHI(cyclotomic_polynomial(n))
            results.append((tuple(chosen), tuple(ZZ(c) for c in polynomial.list())))
            return
        for position in range(start, len(indices)):
            n = indices[position]
            degree = ZZ(euler_phi(n))
            if degree <= remaining:
                recurse(remaining-degree, position, chosen+[n])

    recurse(d, 0, [])
    return tuple(results)


# generate toric characteristic polynomials of degree d. Input: d. Output: iterator of (indices,
# polynomial).
#
def toric_polynomials_of_degree(d):
    for indices, coefficients in toric_types_of_degree(ZZ(d)):
        yield indices, CHI(list(coefficients))


# Local candidate generation


# generate the structural local-factor over-family at p. Input: prime p, dimension g, reduction
# condition. Output: iterator of candidate dictionaries.
#
def structural_candidate_provider(p, g, condition="any"):
    p = ZZ(p)
    g = ZZ(g)
    condition = normalize_condition(condition)

    if isinstance(condition, dict) and condition.get("kind", "").lower() == "custom":
        convention = condition.get("factor_convention", "characteristic").lower()
        default_signature = condition.get("signature")
        for index, item in enumerate(condition.get("factors", [])):
            if isinstance(item, dict):
                polynomial_data = item.get("polynomial", item.get("factor"))
                signature = item.get("signature", default_signature)
                item_convention = item.get("factor_convention", convention).lower()
                label = item.get("label", "custom_{}".format(index))
                conductor_exp = item.get("conductor_exponent_lower_bound")
            else:
                polynomial_data = item
                signature = default_signature
                item_convention = convention
                label = "custom_{}".format(index)
                conductor_exp = None

            if signature is None:
                raise ValueError("Every custom factor must have a signature.")
            signature = tuple(ZZ(v) for v in signature)
            if sum(signature) != g:
                raise ValueError("Custom signature is incompatible with the dimension.")

            if item_convention == "euler":
                P = euler_to_characteristic(EULER(polynomial_data))
            else:
                P = CHI(polynomial_data)

            is_bad = signature != (g, ZZ(0), ZZ(0))
            if conductor_exp is None:
                conductor_exp = 1 if is_bad else 0
            yield {
                "P": P,
                "signature": signature,
                "toric_indices": tuple(),
                "label": label,
                "conductor_exponent_lower_bound": ZZ(conductor_exp),
            }
        return

    for signature in all_reduction_signatures(g):
        if not condition_allows_signature(condition, signature, g):
            continue
        gab, gm, gu = signature

        if gab == 0:
            abelian_polynomials = [CHI(1)]
        else:
            # Sage enumerates integer polynomials whose roots have absolute value sqrt(p).
            abelian_polynomials = CHI.weil_polynomials(ZZ(2*gab), p, sign=1)

        allowed_toric_indices = None
        if isinstance(condition, dict) and condition.get("toric_cyclotomic_indices") is not None:
            allowed_toric_indices = tuple(sorted(ZZ(v) for v in condition["toric_cyclotomic_indices"]))

        for toric_indices, toric_polynomial in toric_polynomials_of_degree(gm):
            if allowed_toric_indices is not None and tuple(sorted(toric_indices)) != allowed_toric_indices:
                continue
            for Pab in abelian_polynomials:
                P = CHI(Pab)*CHI(toric_polynomial)
                is_bad = signature != (g, ZZ(0), ZZ(0))
                yield {
                    "P": CHI(P),
                    "signature": signature,
                    "toric_indices": tuple(toric_indices),
                    "label": "signature_{}_{}_{}".format(gab, gm, gu),
                    "conductor_exponent_lower_bound": ZZ(1 if is_bad else 0),
                }


# validate and deduplicate local-factor candidates. Input: p and ExperimentConfig. Output: iterator
# of validated candidate dictionaries.
#
def validated_candidates(p, config):
    condition = config.reduction_conditions.get(ZZ(p), config.default_reduction)
    provider = config.candidate_provider or structural_candidate_provider

    try:
        iterator = provider(ZZ(p), ZZ(config.dimension), condition)
    except TypeError:
        iterator = provider(ZZ(p), ZZ(config.dimension))

    count = 0
    seen = set()
    for candidate in iterator:
        count += 1
        if count > config.max_raw_candidates_per_prime:
            raise ValueError(
                "Too many raw candidates at p={}. Increase max_raw_candidates_per_prime "
                "or provide a specialized candidate generator.".format(p)
            )

        P = CHI(candidate["P"])
        if P.leading_coefficient() != 1:
            raise ValueError("Non-monic polynomial at p={}: {}".format(p, P))
        signature = tuple(ZZ(v) for v in candidate["signature"])
        if len(signature) != 3 or sum(signature) != ZZ(config.dimension):
            raise ValueError("Invalid local signature at p={}: {}".format(p, signature))

        toric_indices = tuple(ZZ(v) for v in candidate.get("toric_indices", tuple()))
        conductor_exp = ZZ(candidate.get(
            "conductor_exponent_lower_bound",
            0 if signature == (ZZ(config.dimension), ZZ(0), ZZ(0)) else 1,
        ))
        if conductor_exp < 0:
            raise ValueError("The minimal conductor exponent must be nonnegative.")

        # Remove exact duplicates from a custom candidate provider.
        key = (tuple(P.list()), signature, toric_indices, conductor_exp)
        if key in seen:
            continue
        seen.add(key)

        yield {
            "P": P,
            "signature": signature,
            "toric_indices": toric_indices,
            "label": str(candidate.get("label", "candidate")),
            "conductor_exponent_lower_bound": conductor_exp,
        }
