#!/usr/bin/env python3
"""Recompute every compact integer sum/count from the individual trace matrix.

This checks the aggregation of the supplied traces, not their Sage computation.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from pathlib import Path
import csv
import numpy as np
from murmurations import ROOT, COLUMNS, load_data, read_csv, require


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=None,help='Optional recomputed compact CSV')
    args=parser.parse_args()
    data=load_data()
    catalog=read_csv(ROOT/'data/individual/orbits.csv')
    with np.load(ROOT/'data/individual/traces.npz',allow_pickle=False) as archive:
        require(set(archive.files)=={'traces','primes'},'Unexpected arrays')
        traces=archive['traces'];primes=archive['primes']
    require(traces.dtype.kind=='i' and traces.shape==(len(catalog),len(primes)), 'Bad trace shape/type')
    require(primes.tolist()==data['primes'], 'Prime grid mismatch')
    require(len(catalog)==data['meta']['orbit_count'],'Missing orbit')
    counts=defaultdict(lambda:np.zeros(len(primes),dtype=np.int64))
    sums=defaultdict(lambda:np.zeros(len(primes),dtype=np.int64))
    levels={int(r['level']):r for r in read_csv(ROOT/'metadata/levels.csv')}
    actual=Counter();identifiers=set()
    for i,row in enumerate(catalog):
        require(int(row['trace_row'])==i, 'Nonconsecutive row index')
        require(row['orbit_id'] not in identifiers, 'Duplicate orbit ID')
        identifiers.add(row['orbit_id'])
        N,D,eps=int(row['level']),int(row['field_discriminant']),int(row['root_number'])
        require(N in levels and levels[N]['status']=='complete','Orbit on missing/out-of-range level')
        require(D in data['blocks'] and eps in (-1,1),'Unknown field or sign')
        good=(N%primes)!=0
        sums[D,eps]+=np.where(good,traces[i],0).astype(np.int64)
        counts[D,eps]+=good
        actual[N]+=1
    for N,r in levels.items():
        if r['status']=='complete':require(actual[N]==int(r['orbits']),'Level orbit count differs')
    output=[]
    for D,block in sorted(data['blocks'].items()):
        for eps in (-1,1):
            for j,p in enumerate(data['primes']):
                s,n=int(sums[D,eps][j]),int(counts[D,eps][j])
                require((s,n)==block[eps,p],f'Mismatch D={D}, sign={eps}, p={p}')
                output.append(dict(zip(COLUMNS,[D,eps,p,n,s])))
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        with args.out.open('w',encoding='utf-8',newline='') as h:
            w=csv.DictWriter(h,fieldnames=COLUMNS,lineterminator='\n');w.writeheader();w.writerows(output)
    print(f'EXACT_AGGREGATION_OK orbits={len(catalog)} traces={traces.size} aggregate_rows={len(output)}')


if __name__=='__main__':main()
