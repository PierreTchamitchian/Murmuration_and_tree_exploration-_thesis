"""Subfield completion for fields with conductor bound greater than one."""


# list proper nontrivial subfields of one number field.
# Input: a Sage number field.  Output: a list of Sage number fields.
#
def proper_nontrivial_subfields(number_field):
    degree = number_field.absolute_degree()
    return [
        entry[0]
        for entry in number_field.subfields()
        if 1 < entry[0].absolute_degree() < degree
    ]


# test whether a field is absent up to isomorphism.
# Input: one field and an iterable of fields.  Output: a Boolean.
#
def is_new_isomorphism_class(number_field, known_fields):
    return not any(number_field.is_isomorphic(other) for other in known_fields)


# add all new proper nontrivial subfields up to isomorphism.
# Input: an iterable of Sage number fields.  Output: a result dictionary.
#
def complete_with_subfields(number_fields):
    original = list(number_fields)
    complete = list(original)
    new_subfields = []

    for parent in original:
        for subfield in proper_nontrivial_subfields(parent):
            if is_new_isomorphism_class(subfield, complete):
                complete.append(subfield)
                new_subfields.append({
                    'field': subfield,
                    'polynomial': subfield.absolute_polynomial(),
                    'parent_polynomial': parent.absolute_polynomial(),
                })

    return {
        'original_fields': original,
        'all_fields': complete,
        'new_subfields': new_subfields,
    }
