"""Purpose: load the standalone surface-screen algorithms without altering older names.
Input: run load(...) from the project root or notebooks/ (or define SURFACE_SCREEN_ROOT).
Output: prefixed public functions in this session; algorithms use Python scalar types internally.

The implementation files use ordinary Python-compatible Sage source. Compiling
those .sage files directly deliberately avoids rewriting numeric literals into
Sage Integer/RealLiteral objects at the SciPy/Fraction interface. No .py copies
or generated files are needed. The notebooks remain native Sage notebooks.
"""
from pathlib import Path as _ssl_Path
import hashlib as _ssl_hashlib

_ssl_root = globals().get("SURFACE_SCREEN_ROOT")
if _ssl_root is None:
    _ssl_root = next((p for p in [_ssl_Path.cwd(), *_ssl_Path.cwd().parents]
                     if (p/"sage"/"surface_screen_profiles.sage").exists()), None)
if _ssl_root is None:
    raise FileNotFoundError("Set SURFACE_SCREEN_ROOT to the folder containing sage/surface_screen_profiles.sage")
_ssl_names = ("profiles","analytic","model","solver","polynomial_tests","workflow")
_ssl_sources = [(_ssl_Path(_ssl_root)/"sage"/('surface_screen_'+name+'.sage')) for name in _ssl_names]
_SS_SOURCE_HASH = _ssl_hashlib.sha256(b"".join(p.read_bytes() for p in _ssl_sources)).hexdigest()
_ssl_namespace = {"__builtins__":__import__("builtins"),"_SS_SOURCE_HASH":_SS_SOURCE_HASH}
for _ssl_path in _ssl_sources:
    exec(compile(_ssl_path.read_text(encoding="utf-8"),str(_ssl_path),"exec"),_ssl_namespace)
for _ssl_name,_ssl_object in tuple(_ssl_namespace.items()):
    if not _ssl_name.startswith("_"):
        globals()[_ssl_name] = _ssl_object
