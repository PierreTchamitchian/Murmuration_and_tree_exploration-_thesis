"""Explicit read/validate/copy migration from the known v3, never an in-place bypass."""
from __future__ import annotations
from contextlib import ExitStack
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import time
from common import (ROOT, SCHEMA, VERSION, atomic_json, first_primes, read_json,
                    settings_hash, source_digest, user_processes, validate_label,
                    validate_result, validate_coefficients, validate_quadratic_field)

LEGACY_SOURCES = ("common.py", "sieve.py", "engine.py", "worker.py", "run.py")


def legacy_source_digest(root):
    h = hashlib.sha256()
    for name in LEGACY_SOURCES:
        h.update(name.encode()); h.update((Path(root) / name).read_bytes())
    return h.hexdigest()


def load_legacy(root, label, benchmark_path, manifest_path=None):
    """Read-only evidence checks. This function never imports the legacy engine."""
    root = Path(root).expanduser().resolve()
    validate_label(label)
    if root == ROOT:
        raise ValueError("The source must be a separate v3 installation")
    manifest = read_json(manifest_path or ROOT / "reference/projection_provenance.json")
    digest = legacy_source_digest(root)
    if digest != manifest["legacy_source_digest"]:
        raise ValueError("Unrecognized/modified v3 sources; migration refused")
    for name, expected in manifest["legacy_sources"].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Unexpected legacy source: {name}")
    base = root / "results" / label
    settings = read_json(base / "settings.json")
    if settings_hash(settings) != settings.get("settings_hash") or settings.get("source_digest") != digest:
        raise ValueError("Legacy settings/source fingerprint mismatch")
    if (settings.get("version"), settings.get("schema"), settings.get("field_mode"),
        settings.get("poly"), settings.get("degree"), settings.get("weight"),
        settings.get("character"), settings.get("modular_symbols_sign"),
        settings.get("coefficient_method")) != (
            "3.0.0", 3, "all_quadratic", None, 2, 2, "trivial", 1, "eigenvalues"):
        raise ValueError("Expected the known all-quadratic v3 eigenvalue campaign")
    if settings.get("prime_indices") != first_primes(settings["primes"]):
        raise ValueError("Unexpected legacy prime grid")
    if settings.get("sage_version") != manifest["benchmark_sage_version"]:
        raise ValueError("Legacy Sage version differs from the tested benchmark")
    report = read_json(Path(benchmark_path).expanduser())
    if (report.get("success") is not True or report.get("source_digest") != digest or
        report.get("settings_hash") != settings["settings_hash"] or
        report.get("sage_version") != settings["sage_version"] or
        report.get("label") != label or
        report.get("script_sha256") != manifest["benchmark_script_sha256"] or
        report.get("level") != manifest["pilot_level"] or
        report.get("prime_count") != settings["primes"]):
        raise ValueError("Successful benchmark does not match this v3 campaign/kernel")
    level = report["level"]
    raw_reference = (base / f"{level}.json").read_bytes()
    reference = json.loads(raw_reference)
    validate_result(reference, settings, level)
    reference_sha = hashlib.sha256(raw_reference).hexdigest()
    if (reference_sha != report.get("reference_sha256") or
        report.get("orbits") != len(reference["records"]) or
        report.get("characteristic_polynomials_compared") != len(reference["records"]) * settings["primes"] or
        not reference["records"]):
        raise ValueError("Benchmark reference file or coefficient count no longer matches")
    return {"root": root, "base": base, "label": label, "settings": settings,
            "source_digest": digest, "reference": reference,
            "reference_sha256": reference_sha, "benchmark": report}


def validate_upgrade_gate(info, root=ROOT):
    report = read_json(Path(root) / "tests/projection_upgrade_validation.json")
    if (report.get("success") is not True or report.get("source_digest") != source_digest(root) or
        report.get("legacy_source_digest") != info["source_digest"] or
        report.get("legacy_settings_hash") != info["settings"]["settings_hash"] or
        report.get("reference_sha256") != info["reference_sha256"] or
        report.get("sage_version") != info["settings"]["sage_version"] or
        report.get("level") != info["reference"]["level"] or
        report.get("polynomials_compared") != len(info["reference"]["records"]) * info["settings"]["primes"]):
        raise ValueError("Integrated engine gate is absent/stale; run tests/validate_upgrade.py first")
    return report


def provenance(settings, raw, filename):
    return {"version": settings["version"], "source_digest": settings["source_digest"],
            "settings_hash": settings["settings_hash"], "original_file": filename,
            "original_sha256": hashlib.sha256(raw).hexdigest(),
            "coefficient_method": settings["coefficient_method"]}


def convert_complete(raw, old, new, level):
    obj = json.loads(raw)
    validate_result(obj, old, level)
    if obj.get("sage_version") != old["sage_version"] or obj.get("largest_prime") != old["prime_indices"][-1]:
        raise ValueError("Inconsistent completed Sage version or largest prime")
    obj["imported_from"] = provenance(old, raw, f"{level}.json")
    obj["coefficient_method"] = "eigenvalues"  # Preserve the actual historical method.
    obj["settings_hash"] = new["settings_hash"]
    validate_result(obj, new, level)
    return obj


def convert_partial(raw, old, new, level):
    obj = json.loads(raw)
    if (obj.get("schema"), obj.get("settings_hash"), obj.get("level"),
        obj.get("sage_version")) != (SCHEMA, old["settings_hash"], level, old["sage_version"]):
        raise ValueError("Incompatible v3 partial checkpoint")
    if not isinstance(obj.get("components"), dict):
        raise ValueError("Invalid partial components")
    for key, rec in obj["components"].items():
        if rec.get("component_key") != key:
            raise ValueError("Partial component-key mismatch")
        validate_coefficients(rec, 2, old["primes"], complete=False)
        validate_quadratic_field(rec)
        rec["_v3_prefix_needs_check"] = True
    obj["settings_hash"] = new["settings_hash"]
    obj["imported_from"] = provenance(old, raw, f"{level}.partial.json")
    return obj


def assert_compatible_settings(old, new):
    names = ("schema", "weight", "character", "modular_symbols_sign", "field_mode", "poly", "degree",
             "sage_version", "primes", "prime_indices", "sieve_primes", "verify_first", "checkpoint_every")
    if any(old.get(k) != new.get(k) for k in names):
        raise ValueError("Arithmetic/checkpoint settings differ; not a compatible migration")
    if new.get("coefficient_method") != "projected" or new.get("version") != VERSION:
        raise ValueError("Expected the v4 projected backend")
    if settings_hash(new) != new.get("settings_hash"):
        raise ValueError("Invalid destination settings fingerprint")


def active_legacy(info):
    root, base, label = info["root"], info["base"], info["label"]
    answer = []
    for p in user_processes():
        if p["state"] in ("Z", "X"):
            continue
        args = p["argv"]
        worker = str(root / "worker.py") in args and str(base / "settings.json") in args
        leader = False
        if str(root / "run.py") in args and "--label" in args:
            pos = args.index("--label")
            leader = pos + 1 < len(args) and args[pos + 1] == label
        if worker or leader:
            answer.append(p["pid"])
    return answer


def import_campaign(info, new_settings, destination_root=ROOT, destination_label=None):
    """Locks both launchers, validates every file, and atomically publishes a COPY.

    The source data files are never rewritten, linked to or deleted. A failed
    import cannot publish a partly migrated campaign. Existing destinations are
    refused unless a completed, matching migration manifest already exists.
    """
    assert_compatible_settings(info["settings"], new_settings)
    root = Path(destination_root).resolve()
    label = validate_label(destination_label or info["label"])
    target = root / "results" / label
    root.joinpath("results").mkdir(parents=True, exist_ok=True)
    root.joinpath("logs").mkdir(parents=True, exist_ok=True)
    if root == info["root"] or info["root"] in root.parents:
        raise ValueError("Destination must be outside the legacy installation")
    stage = None
    with ExitStack() as stack:
        # Same order as a launcher: launch lock then campaign lock.
        for path in (info["root"] / "logs" / f".{info['label']}.launch.lock",
                     info["base"] / ".campaign.lock",
                     root / "logs" / f".{label}.launch.lock"):
            lock = stack.enter_context(path.open("a+"))
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError("Campaign/launcher is active; stop it before importing") from None
        if active_legacy(info):
            raise RuntimeError("Legacy workers are still active; wait for their exit before importing")
        if (legacy_source_digest(info["root"]) != info["source_digest"] or
            read_json(info["base"] / "settings.json") != info["settings"]):
            raise ValueError("Legacy sources/settings changed during preflight")
        if target.exists():
            manifest = target / "migration_v3.json"
            if manifest.exists():
                m = read_json(manifest)
                if (m.get("complete") is True and m.get("source_root") == str(info["root"]) and
                    m.get("old_settings_hash") == info["settings"]["settings_hash"] and
                    m.get("new_settings_hash") == new_settings["settings_hash"] and
                    read_json(target / "settings.json") == new_settings):
                    return dict(m, already_imported=True)
            raise FileExistsError("Destination exists and is not this completed migration; no files overwritten")
        complete_files = sorted((p for p in info["base"].glob("*.json") if p.stem.isdigit()),
                                key=lambda p: int(p.stem))
        complete_levels = {int(p.stem) for p in complete_files}
        partial_files = sorted((p for p in info["base"].glob("*.partial.json")
                                if p.name.split(".")[0].isdigit() and
                                int(p.name.split(".")[0]) not in complete_levels),
                               key=lambda p: int(p.name.split(".")[0]))
        paths = complete_files + partial_files
        if any(p.is_symlink() for p in paths):
            raise ValueError("Symbolic checkpoint links are not accepted")
        needed = sum(p.stat().st_size for p in paths)
        if shutil.disk_usage(root / "results").free < needed * 1.3 + 16 * 1024**2:
            raise OSError("Insufficient free disk space for a separate validated result copy")
        stage = Path(tempfile.mkdtemp(prefix=f".{label}.v3-import-", dir=root / "results"))
        stage_lock = stack.enter_context((stage / ".campaign.lock").open("a+"))
        fcntl.flock(stage_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        entries = []
        try:
            atomic_json(stage / "settings.json", new_settings)
            atomic_json(stage / "provenance/v3_settings.json", info["settings"])
            atomic_json(stage / "provenance/projection_benchmark.json", info["benchmark"])
            request = info["base"] / "request.json"
            if request.exists():
                atomic_json(stage / "provenance/v3_request.json", read_json(request))
            for i, p in enumerate(paths, 1):
                level = int(p.name.split(".")[0])
                raw = p.read_bytes()
                partial = p.name.endswith(".partial.json")
                converter = convert_partial if partial else convert_complete
                obj = converter(raw, info["settings"], new_settings, level)
                atomic_json(stage / p.name, obj)
                entries.append({"file": p.name, "source_sha256": hashlib.sha256(raw).hexdigest(),
                                "imported_sha256": hashlib.sha256((stage / p.name).read_bytes()).hexdigest(),
                                "partial": partial})
                if i % 250 == 0:
                    print(f"IMPORT_PROGRESS files={i}/{len(paths)}", flush=True)
            if (legacy_source_digest(info["root"]) != info["source_digest"] or
                read_json(info["base"] / "settings.json") != info["settings"] or active_legacy(info)):
                raise RuntimeError("Legacy installation changed or restarted during import")
            manifest = {"complete": True, "created": time.time(),
                        "source_root": str(info["root"]), "source_label": info["label"],
                        "old_source_digest": info["source_digest"],
                        "old_settings_hash": info["settings"]["settings_hash"],
                        "new_settings_hash": new_settings["settings_hash"],
                        "new_source_digest": new_settings["source_digest"],
                        "completed_levels": len(complete_files), "partial_levels": len(partial_files),
                        "original_error_files_not_imported": sorted(p.name for p in info["base"].glob("*.error.json")),
                        "reference_sha256": info["reference_sha256"], "files": entries}
            atomic_json(stage / "migration_v3.json", manifest)
            if target.exists():
                raise FileExistsError("Destination appeared during import; refusing to overwrite")
            os.rename(stage, target)
            stage = None
            return manifest
        finally:
            if stage is not None:
                shutil.rmtree(stage)
